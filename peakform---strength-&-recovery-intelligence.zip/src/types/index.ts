export type DistrictId = 'ascent' | 'bodymap' | 'river' | 'constellation' | 'logger';

export interface StatItem {
  v: string;
  l: string;
}

export interface BuildingCard {
  id: string;
  districtId: DistrictId;
  title: string;
  tag: string;
  tagColor: 'primary' | 'secondary' | 'success' | 'warning' | 'danger' | 'info';
  iconChar: string;
  subtitle: string;
  stats: StatItem[];
  insight: string;
  comparison: string;
  modalText: string;
  formulaNote?: string;
  dateStr?: string;
}

export interface District {
  id: DistrictId;
  label: string;
  shortName: string;
  icon: string;
  accentColor: string;
  accentSoft: string;
  tagline: string;
  buildings: BuildingCard[];
}

export type MuscleCategory = 'major' | 'longevity' | 'hands' | 'feet';
export type MuscleStatus = 'fatigued' | 'recovering' | 'primed' | 'overdue';

export interface Muscle {
  id: string;
  name: string;
  scientificName: string;
  category: MuscleCategory;
  view: 'anterior' | 'posterior' | 'both';
  hoursSinceTrained: number;
  restCadenceHours: number;
  recoveryPercentage: number;
  status: MuscleStatus;
  fastDecay: number; // e.g. 0.12
  slowDecay: number; // e.g. 0.008
  lastLoadLbs: number;
  recommendedExercises: string[];
  notes: string;
  coordinates: { x: number; y: number; view: 'anterior' | 'posterior' };
}

export interface WorkoutSession {
  id: string;
  date: string;
  name: string;
  split: 'push' | 'pull' | 'legs' | 'longevity';
  durationMin: number;
  volumeLbs: number;
  workDensity: number; // lbs/min
  rpeAvg: number;
  exercises: {
    name: string;
    sets: number;
    reps: number;
    weightLbs: number;
  }[];
  prHit?: string;
  notes: string;
  isPlanned?: boolean;
  isSkipped?: boolean;
}

export interface MonteCarloPath {
  year1: number;
  year2: number;
  year3: number;
  year4: number;
  year5: number;
}
