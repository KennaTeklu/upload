import React, { useEffect } from 'react';
import { WorkoutSession } from '../types';
import { X, Dumbbell, Clock, Flame, Calendar, Award } from 'lucide-react';

interface WorkoutDetailModalProps {
  workout: WorkoutSession | null;
  onClose: () => void;
}

export const WorkoutDetailModal: React.FC<WorkoutDetailModalProps> = ({
  workout,
  onClose,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!workout) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div 
        className="relative w-full max-w-xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8 shadow-2xl text-slate-100"
        role="dialog"
        aria-modal="true"
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs font-semibold text-purple-400 uppercase tracking-wider mb-1">
          <Calendar className="w-4 h-4" />
          <span>{workout.date} · {workout.split} split</span>
        </div>

        <h3 className="text-2xl font-bold text-white font-display">
          {workout.name}
        </h3>

        {workout.prHit && (
          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-300">
            <Award className="w-3.5 h-3.5" />
            <span>PR: {workout.prHit}</span>
          </div>
        )}

        {/* 3 Metric Grid */}
        <div className="grid grid-cols-3 gap-3 my-6">
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
            <div className="text-xs text-slate-400">Total Volume</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums">
              {workout.volumeLbs.toLocaleString()} lbs
            </div>
          </div>
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
            <div className="text-xs text-slate-400">Duration</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums">
              {workout.durationMin} min
            </div>
          </div>
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
            <div className="text-xs text-slate-400">Density</div>
            <div className="text-lg font-bold text-purple-400 font-mono tabular-nums">
              {workout.workDensity} lbs/min
            </div>
          </div>
        </div>

        {/* Exercise List */}
        <div className="space-y-3">
          <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
            Completed Sets & Volume Breakdown
          </h4>
          <div className="space-y-2">
            {workout.exercises.map((ex, idx) => {
              const exVol = ex.sets * ex.reps * ex.weightLbs;
              return (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-slate-950/50 border border-slate-800 rounded-lg text-xs"
                >
                  <div>
                    <div className="text-white font-semibold">{ex.name}</div>
                    <div className="text-slate-400 font-mono">
                      {ex.sets} sets × {ex.reps} reps @ {ex.weightLbs} lbs
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-white font-bold font-mono tabular-nums">
                      {exVol.toLocaleString()} lbs
                    </div>
                    <div className="text-[10px] text-slate-500 uppercase">Tonnage</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {workout.notes && (
          <div className="mt-5 p-3.5 bg-slate-950/40 border border-slate-800 rounded-lg text-xs text-slate-300 leading-relaxed">
            <span className="text-slate-500 font-semibold block mb-1">Session Notes:</span>
            {workout.notes}
          </div>
        )}

        <div className="flex justify-end pt-5">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-900 bg-purple-400 hover:bg-purple-300 rounded-lg transition-colors cursor-pointer"
          >
            Close View
          </button>
        </div>
      </div>
    </div>
  );
};
