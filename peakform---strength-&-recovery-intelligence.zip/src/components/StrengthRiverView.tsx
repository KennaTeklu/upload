import React, { useState } from 'react';
import { BuildingCard } from '../types';
import { Waves, TrendingUp, Anchor, Scale, ChevronRight, Zap, Clock, Box } from 'lucide-react';
import { ThreeDistrictWidget } from './ThreeDistrictWidget';

interface StrengthRiverViewProps {
  cards: BuildingCard[];
  onSelectCard: (card: BuildingCard) => void;
  totalVolume: number;
}

export const StrengthRiverView: React.FC<StrengthRiverViewProps> = ({
  cards,
  onSelectCard,
  totalVolume,
}) => {
  const [show3dRibbon, setShow3dRibbon] = useState<boolean>(true);
  const [selectedMilestone, setSelectedMilestone] = useState<number>(2); // Default to The Rapid

  // Milestones along the river flow
  const riverMilestones = [
    {
      id: 0,
      name: 'The Source',
      date: 'Mar 14, 2026',
      tonnage: 1200,
      cumulative: 1200,
      density: '42.8 lbs/min',
      duration: '28 min',
      desc: 'First workout trickle. 45 lbs bar + 25-lb plates. The inception of the flow.'
    },
    {
      id: 1,
      name: 'First Tributary',
      date: 'Apr 02, 2026',
      tonnage: 5800,
      cumulative: 38400,
      density: '152.6 lbs/min',
      duration: '38 min',
      desc: 'Bench PR day (135 lbs). Volume doubles; work density triples as conditioning takes hold.'
    },
    {
      id: 2,
      name: 'The Rapid',
      date: 'May 20, 2026',
      tonnage: 32000,
      cumulative: 184000,
      density: '185.5 lbs/min',
      duration: '4 sessions / wk',
      desc: 'White-water peak PR week. Every set pushed to RPE 9-10 followed by a wave deload.'
    },
    {
      id: 3,
      name: 'Big Tributary',
      date: 'Jun 08, 2026',
      tonnage: 11400,
      cumulative: 265000,
      density: '219.2 lbs/min',
      duration: '52 min',
      desc: 'Squat PR surge (245 lbs). Largest single-session tributary in platform history.'
    },
    {
      id: 4,
      name: 'Today (Active Flow)',
      date: 'Sep 26, 2026',
      tonnage: 9480,
      cumulative: totalVolume,
      density: '201.7 lbs/min',
      duration: '47 min',
      desc: 'Push hypertrophy session. 425,000 lbs moved over 87 workouts and 26 weeks.'
    },
    {
      id: 5,
      name: 'The Ocean',
      date: 'By 2031 (5-Yr)',
      tonnage: 1800000,
      cumulative: 1800000,
      density: '240.0 lbs/min',
      duration: '260 weeks',
      desc: 'The infinite sea. 1.8M lbs projected. Diminishing returns cap with +3% yearly capacity.'
    }
  ];

  const activeM = riverMilestones[selectedMilestone];

  // Equivalents calculations
  const pianos = Math.round(totalVolume / 3400); // 3,400 lbs grand piano
  const sedans = (totalVolume / 3600).toFixed(1); // 3,600 lbs car
  const smartCars = (totalVolume / 1800).toFixed(1); // 1,800 lbs smart car

  return (
    <div className="space-y-10">
      
      {/* Editorial Header */}
      <div>
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-semibold mb-2">
          <span>STRENGTH RIVER</span>
          <span aria-hidden="true">·</span>
          <span>425,000 LBS LIFETIME TONNAGE</span>
          <span aria-hidden="true">·</span>
          <span>WORK CAPACITY ACCUMULATION</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display text-balance">
          The Cumulative Flow of Work Capacity
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-400 max-w-3xl leading-relaxed">
          Every set is a drop in the river. Track how your density (lbs/min) and weekly volume 
          expand as cardiovascular and structural work capacity compounds over 26 weeks.
        </p>
      </div>

      {/* Main River Visualizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8">
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <Waves className="w-4 h-4 text-cyan-400" />
              <span>Current River Volume (26 Weeks)</span>
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-white mt-1 font-mono tabular-nums">
              {totalVolume.toLocaleString()} lbs
              <span className="text-sm font-normal text-slate-400 ml-2">accumulated iron</span>
            </div>
            <div className="text-xs text-slate-400 mt-1">
              <span>87 workouts logged</span>
              <span className="mx-2">·</span>
              <span>26 weeks active</span>
              <span className="mx-2">·</span>
              <span>Peak week: <strong className="text-slate-200 font-mono">32,000 lbs</strong></span>
            </div>
          </div>

          {/* Physical Equivalents Bar */}
          <div className="grid grid-cols-3 gap-3 bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
            <div className="text-center px-2">
              <div className="text-xs text-slate-400">Grand Pianos</div>
              <div className="text-lg font-bold text-cyan-400 font-mono tabular-nums">{pianos}</div>
              <div className="text-[10px] text-slate-500">~3,400 lbs ea</div>
            </div>
            <div className="text-center px-2 border-x border-slate-800/80">
              <div className="text-xs text-slate-400">Sedans</div>
              <div className="text-lg font-bold text-blue-400 font-mono tabular-nums">{sedans}</div>
              <div className="text-[10px] text-slate-500">~3,600 lbs ea</div>
            </div>
            <div className="text-center px-2">
              <div className="text-xs text-slate-400">Smart Cars</div>
              <div className="text-lg font-bold text-indigo-400 font-mono tabular-nums">{smartCars}</div>
              <div className="text-[10px] text-slate-500">~1,800 lbs ea</div>
            </div>
          </div>
        </div>

        {/* 3D Telemetry Flow Ribbon */}
        <div className="pt-4 pb-2 flex items-center justify-between border-b border-slate-800/80">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Box className="w-4 h-4 text-cyan-400" />
            <span>3D Volumetric Flow Ribbon & Tonnage Density</span>
          </div>
          <button
            onClick={() => setShow3dRibbon(!show3dRibbon)}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-medium cursor-pointer"
          >
            {show3dRibbon ? 'Hide 3D Ribbon' : 'Show 3D Ribbon'}
          </button>
        </div>

        {show3dRibbon && (
          <div className="pt-3 pb-2">
            <ThreeDistrictWidget districtId="river" heightPx={220} />
          </div>
        )}

        {/* Visual River Stream (SVG widening corridor) */}
        <div className="py-6">
          <div className="relative w-full overflow-hidden">
            <svg viewBox="0 0 600 160" className="w-full h-44 sm:h-52">
              <defs>
                <linearGradient id="riverGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#0891b2" stopOpacity="0.3" />
                  <stop offset="35%" stopColor="#06b6d4" stopOpacity="0.6" />
                  <stop offset="70%" stopColor="#3b82f6" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity="0.95" />
                </linearGradient>
              </defs>

              {/* River corridor (starts narrow at 12px, widens to 110px) */}
              <path
                d="M 30 76 Q 150 72, 300 60 T 570 25 L 570 135 Q 450 100, 300 100 T 30 84 Z"
                fill="url(#riverGrad)"
              />

              {/* River flow ripples */}
              <path
                d="M 50 80 Q 180 75, 300 80 T 550 80"
                fill="none"
                stroke="rgba(255,255,255,0.4)"
                strokeWidth="1.5"
                strokeDasharray="6 4"
              />

              {/* Milestone Markers along the stream */}
              {[
                { cx: 40, cy: 80, idx: 0 },
                { cx: 140, cy: 78, idx: 1 },
                { cx: 280, cy: 75, idx: 2 },
                { cx: 390, cy: 76, idx: 3 },
                { cx: 480, cy: 78, idx: 4 },
                { cx: 560, cy: 80, idx: 5 }
              ].map((m) => {
                const isSelected = selectedMilestone === m.idx;
                return (
                  <g
                    key={m.idx}
                    onClick={() => setSelectedMilestone(m.idx)}
                    className="cursor-pointer group"
                  >
                    <circle
                      cx={m.cx}
                      cy={m.cy}
                      r={isSelected ? 9 : 6}
                      fill={isSelected ? '#06b6d4' : '#0f172a'}
                      stroke={isSelected ? '#ffffff' : '#06b6d4'}
                      strokeWidth={isSelected ? 3 : 2}
                      className="transition-all"
                    />
                    <text
                      x={m.cx}
                      y={m.cy > 80 ? m.cy + 22 : m.cy - 16}
                      textAnchor="middle"
                      fill={isSelected ? '#ffffff' : '#94a3b8'}
                      fontSize="9"
                      fontWeight={isSelected ? 'bold' : 'normal'}
                      fontFamily="Plus Jakarta Sans"
                    >
                      {riverMilestones[m.idx].name}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Milestone Detail Inspector */}
        <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
            <div>
              <div className="text-xs text-cyan-400 font-semibold uppercase tracking-wider">
                Milestone Inspection · {activeM.date}
              </div>
              <h3 className="text-xl font-bold text-white font-display">
                {activeM.name}
              </h3>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="text-slate-300">
                <span className="text-slate-500">Volume: </span>
                <strong className="text-white">{activeM.tonnage.toLocaleString()} lbs</strong>
              </div>
              <div className="text-slate-300">
                <span className="text-slate-500">Density: </span>
                <strong className="text-cyan-400">{activeM.density}</strong>
              </div>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 mt-3 leading-relaxed">
            {activeM.desc}
          </p>
        </div>

      </div>

      {/* Strength River Milestone Cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight font-display">
              River Stages & Work Capacity Density
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              From the initial Day 1 trickle to the 5-year ocean of 1.8M lbs.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card) => (
            <div
              key={card.id}
              onClick={() => onSelectCard(card)}
              className="group bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-xl p-5 transition-all duration-200 flex flex-col justify-between cursor-pointer hover:shadow-lg hover:shadow-cyan-500/5"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-cyan-400 tracking-wide uppercase">
                    {card.tag}
                  </span>
                  <span className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-xs font-mono font-bold text-slate-300">
                    {card.iconChar}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors font-display">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 mb-4 line-clamp-1">
                  {card.subtitle}
                </p>

                <div className="grid grid-cols-3 gap-2 mb-4 bg-slate-950/60 border border-slate-800/80 rounded-lg p-2.5">
                  {card.stats.slice(0, 3).map((st, sIdx) => (
                    <div key={sIdx} className="text-center">
                      <div className="text-sm font-bold text-white font-mono tabular-nums">
                        {st.v}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-0.5 truncate">
                        {st.l}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {card.insight}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-cyan-400 font-semibold group-hover:text-cyan-300">
                <span>View Full Analysis</span>
                <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
