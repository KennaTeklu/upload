import React, { useEffect } from 'react';
import { BuildingCard } from '../types';
import { X, ArrowRight, BarChart3, ShieldCheck, Zap } from 'lucide-react';

interface CardDetailModalProps {
  card: BuildingCard | null;
  onClose: () => void;
}

export const CardDetailModal: React.FC<CardDetailModalProps> = ({ card, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!card) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8 shadow-2xl text-slate-100"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tag */}
        <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 mb-2">
          <span>{card.tag}</span>
        </div>

        <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-1 font-display">
          {card.title}
        </h3>
        <p className="text-sm text-slate-400 mb-6">
          {card.subtitle}
        </p>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {card.stats.map((s, idx) => (
            <div key={idx} className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
              <div className="text-xl sm:text-2xl font-bold text-blue-400 font-mono tabular-nums">
                {s.v}
              </div>
              <div className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-medium">
                {s.l}
              </div>
            </div>
          ))}
        </div>

        {/* Narrative Body */}
        <div className="prose prose-invert max-w-none text-slate-300 text-sm sm:text-base leading-relaxed mb-6 space-y-3">
          <p>{card.modalText}</p>
        </div>

        {/* Algorithm Insight Card */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
            <Zap className="w-4 h-4" />
            <span>ALGORITHM & PHYSIOLOGY INSIGHT</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {card.insight}
          </p>
          {card.formulaNote && (
            <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs font-mono text-slate-400">
              <span className="text-slate-500">Formula: </span>
              {card.formulaNote}
            </div>
          )}
        </div>

        {/* Normative Comparison */}
        <div className="bg-slate-950/40 border border-slate-800/60 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-1">
            <BarChart3 className="w-4 h-4" />
            <span>NORMATIVE BENCHMARK</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300">
            {card.comparison}
          </p>
        </div>

        {/* Modal Footer Actions */}
        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-900 bg-blue-400 hover:bg-blue-300 rounded-lg transition-colors cursor-pointer"
          >
            Dismiss View
          </button>
        </div>
      </div>
    </div>
  );
};
