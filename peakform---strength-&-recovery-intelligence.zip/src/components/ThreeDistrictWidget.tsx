import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { DistrictId } from '../types';

interface ThreeDistrictWidgetProps {
  districtId: DistrictId;
  heightPx?: number;
}

export const ThreeDistrictWidget: React.FC<ThreeDistrictWidgetProps> = ({
  districtId,
  heightPx = 280,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = heightPx;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060913);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);

    // Common ambient & directional lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(10, 20, 15);
    scene.add(dirLight);

    let animGroup = new THREE.Group();
    scene.add(animGroup);

    // Build specific 3D visual based on district
    if (districtId === 'ascent') {
      camera.position.set(0, 10, 18);
      camera.lookAt(0, 2, 0);

      // 3D Mountain Ridge with 7 glowing milestones
      const grid = new THREE.GridHelper(24, 12, 0x3b82f6, 0x1e293b);
      grid.position.y = -2;
      animGroup.add(grid);

      // Ascending stepped mountain terrain
      for (let i = 0; i < 7; i++) {
        const h = 1.2 + i * 1.1;
        const geo = new THREE.BoxGeometry(1.6, h, 1.6);
        const mat = new THREE.MeshStandardMaterial({
          color: i === 6 ? 0xf59e0b : 0x3b82f6,
          roughness: 0.2,
          metalness: 0.5,
        });
        const m = new THREE.Mesh(geo, mat);
        m.position.set(-6 + i * 2, -2 + h / 2, -3 + i * 0.8);
        animGroup.add(m);

        // Glowing apex beacon
        const beaconGeo = new THREE.SphereGeometry(0.3, 16, 16);
        const beaconMat = new THREE.MeshBasicMaterial({ color: i === 6 ? 0xffffff : 0x60a5fa });
        const beacon = new THREE.Mesh(beaconGeo, beaconMat);
        beacon.position.set(-6 + i * 2, -2 + h + 0.4, -3 + i * 0.8);
        animGroup.add(beacon);
      }

      // Connecting energy beam
      const curvePoints = [];
      for (let i = 0; i < 7; i++) {
        const h = 1.2 + i * 1.1;
        curvePoints.push(new THREE.Vector3(-6 + i * 2, -2 + h + 0.4, -3 + i * 0.8));
      }
      const curve = new THREE.CatmullRomCurve3(curvePoints);
      const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.08, 8, false);
      const tubeMat = new THREE.MeshBasicMaterial({ color: 0x60a5fa, transparent: true, opacity: 0.8 });
      const tube = new THREE.Mesh(tubeGeo, tubeMat);
      animGroup.add(tube);
    } else if (districtId === 'bodymap') {
      camera.position.set(0, 0, 16);
      camera.lookAt(0, 0, 0);

      // 3D Anatomical Fiber Mannequin Wireframe
      const torsoGeo = new THREE.CylinderGeometry(2.5, 1.8, 6, 16, 8, true);
      const torsoMat = new THREE.MeshBasicMaterial({
        color: 0xef4444,
        wireframe: true,
        transparent: true,
        opacity: 0.6,
      });
      const torso = new THREE.Mesh(torsoGeo, torsoMat);
      animGroup.add(torso);

      // Floating pulsating muscle nodes
      const nodeColors = [0xef4444, 0xf59e0b, 0x10b981, 0xef4444, 0x10b981];
      const nodePositions = [
        [-1.8, 2, 1.2], // left chest
        [1.8, 2, 1.2],  // right chest
        [-2.2, 0.5, 0], // left arm
        [2.2, 0.5, 0],  // right arm
        [0, -1.5, 1.2], // abs
      ];

      nodePositions.forEach((pos, idx) => {
        const sphereGeo = new THREE.SphereGeometry(0.4, 16, 16);
        const sphereMat = new THREE.MeshBasicMaterial({
          color: nodeColors[idx % nodeColors.length],
        });
        const sphere = new THREE.Mesh(sphereGeo, sphereMat);
        sphere.position.set(pos[0], pos[1], pos[2]);
        animGroup.add(sphere);
      });
    } else if (districtId === 'river') {
      camera.position.set(0, 8, 16);
      camera.lookAt(0, 0, 0);

      // 3D Flowing River Ribbon
      const points = [];
      for (let i = -10; i <= 10; i++) {
        points.push(new THREE.Vector3(i * 1.2, Math.sin(i * 0.5) * 1.2, Math.cos(i * 0.4) * 2));
      }
      const curve = new THREE.CatmullRomCurve3(points);
      const ribbonGeo = new THREE.TubeGeometry(curve, 64, 1.2, 12, false);
      const ribbonMat = new THREE.MeshStandardMaterial({
        color: 0x06b6d4,
        roughness: 0.1,
        metalness: 0.6,
        wireframe: false,
        transparent: true,
        opacity: 0.85,
      });
      const ribbon = new THREE.Mesh(ribbonGeo, ribbonMat);
      animGroup.add(ribbon);

      // Floating particles along river
      const partCount = 150;
      const partGeo = new THREE.BufferGeometry();
      const partPos = new Float32Array(partCount * 3);
      for (let i = 0; i < partCount; i++) {
        const t = Math.random();
        const p = curve.getPoint(t);
        partPos[i * 3] = p.x + (Math.random() - 0.5) * 1.5;
        partPos[i * 3 + 1] = p.y + (Math.random() - 0.5) * 1.5;
        partPos[i * 3 + 2] = p.z + (Math.random() - 0.5) * 1.5;
      }
      partGeo.setAttribute('position', new THREE.BufferAttribute(partPos, 3));
      const partMat = new THREE.PointsMaterial({ color: 0x67e8f9, size: 0.35 });
      const particles = new THREE.Points(partGeo, partMat);
      animGroup.add(particles);
    } else {
      // Constellation 3D Galaxy Sphere
      camera.position.set(0, 6, 16);
      camera.lookAt(0, 0, 0);

      const starCount = 200;
      const starGeo = new THREE.BufferGeometry();
      const starPos = new Float32Array(starCount * 3);
      const starColors = new Float32Array(starCount * 3);
      const colors = [0xef4444, 0x6366f1, 0x10b981, 0x06b6d4];

      for (let i = 0; i < starCount; i++) {
        const phi = Math.random() * Math.PI * 2;
        const rad = 2 + Math.random() * 8;
        const y = (Math.random() - 0.5) * 4;
        starPos[i * 3] = Math.cos(phi) * rad;
        starPos[i * 3 + 1] = y;
        starPos[i * 3 + 2] = Math.sin(phi) * rad;

        const col = new THREE.Color(colors[i % colors.length]);
        starColors[i * 3] = col.r;
        starColors[i * 3 + 1] = col.g;
        starColors[i * 3 + 2] = col.b;
      }

      starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
      starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
      const starMat = new THREE.PointsMaterial({
        size: 0.5,
        vertexColors: true,
      });
      const stars = new THREE.Points(starGeo, starMat);
      animGroup.add(stars);

      // Rings
      const ringGeo = new THREE.RingGeometry(5, 5.2, 32);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xa855f7, side: THREE.DoubleSide, transparent: true, opacity: 0.4 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 2.5;
      animGroup.add(ring);
    }

    // Render loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Gentle rotation
      animGroup.rotation.y = elapsed * 0.35;
      if (districtId === 'bodymap') {
        animGroup.rotation.x = Math.sin(elapsed * 0.5) * 0.1;
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      camera.aspect = w / height;
      camera.updateProjectionMatrix();
      renderer.setSize(w, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [districtId, heightPx]);

  return (
    <div className="relative w-full rounded-xl overflow-hidden border border-slate-800/80 shadow-md">
      <div ref={mountRef} className="w-full h-full" style={{ height: `${heightPx}px` }} />
      <div className="absolute top-2.5 right-3 text-[10px] font-mono text-slate-500 uppercase tracking-wider flex items-center gap-1.5 pointer-events-none">
        <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
        <span>3D Spatial Telemetry</span>
      </div>
    </div>
  );
};
