import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import * as THREE from 'three';
import { BuildingCard, DistrictId, Muscle } from '../types';
import { DISTRICTS_DATA } from '../data/mockData';
import { CardVisualizer } from './CardVisualizer';
import {
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Zap,
  BarChart3,
  Dumbbell,
  Compass,
  ArrowRight,
  TrendingUp,
  Activity,
  Waves,
  Box,
  Flame,
  Maximize2,
  Minimize2,
  Lock,
  Unlock,
  Eye,
  EyeOff
} from 'lucide-react';

// --- High-Resolution 2D Canvas Texture Generator for 3D Wall Faces ---
function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number = 4
): number {
  const words = text.split(' ');
  let line = '';
  let curY = y;
  let lineCount = 0;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxWidth && n > 0) {
      ctx.fillText(line.trim(), x, curY);
      line = words[n] + ' ';
      curY += lineHeight;
      lineCount++;
      if (lineCount >= maxLines - 1 && n < words.length - 1) {
        let remaining = words.slice(n).join(' ');
        while (ctx.measureText(remaining + '...').width > maxWidth && remaining.length > 0) {
          remaining = remaining.slice(0, -1);
        }
        ctx.fillText(remaining + '...', x, curY);
        return curY + lineHeight;
      }
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, curY);
  return curY + lineHeight;
}

function drawDomainVisual(
  ctx: CanvasRenderingContext2D,
  card: BuildingCard,
  x: number,
  y: number,
  w: number,
  h: number,
  accent: string
) {
  // Chart Container
  ctx.fillStyle = 'rgba(7, 12, 24, 0.92)';
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = 'rgba(59, 130, 246, 0.35)';
  ctx.lineWidth = 2;
  ctx.strokeRect(x, y, w, h);

  // Subtle interior grid
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
  ctx.lineWidth = 1;
  for (let gx = x + 40; gx < x + w; gx += 50) {
    ctx.beginPath();
    ctx.moveTo(gx, y);
    ctx.lineTo(gx, y + h);
    ctx.stroke();
  }
  for (let gy = y + 40; gy < y + h; gy += 50) {
    ctx.beginPath();
    ctx.moveTo(x, gy);
    ctx.lineTo(x + w, gy);
    ctx.stroke();
  }

  if (card.districtId === 'ascent') {
    // Monte Carlo Normal Distribution Bell Curve
    ctx.fillStyle = accent;
    ctx.font = 'bold 20px monospace';
    ctx.fillText('MONTE CARLO PROBABILISTIC LOAD TRAJECTORY', x + 24, y + 36);

    ctx.save();
    ctx.beginPath();
    const baselineY = y + h - 45;
    ctx.moveTo(x + 25, baselineY);

    const points: [number, number][] = [];
    const steps = 60;
    for (let i = 0; i <= steps; i++) {
      const px = x + 25 + (i / steps) * (w - 50);
      const norm = (i - steps * 0.48) / (steps * 0.22);
      const py = baselineY - Math.exp(-0.5 * norm * norm) * (h - 95);
      points.push([px, py]);
      ctx.lineTo(px, py);
    }
    ctx.lineTo(x + w - 25, baselineY);
    ctx.closePath();

    const grad = ctx.createLinearGradient(0, y, 0, baselineY);
    grad.addColorStop(0, accent);
    grad.addColorStop(1, 'rgba(15, 23, 42, 0.08)');
    ctx.fillStyle = grad;
    ctx.globalAlpha = 0.65;
    ctx.fill();
    ctx.globalAlpha = 1.0;

    ctx.strokeStyle = accent;
    ctx.lineWidth = 4;
    ctx.beginPath();
    points.forEach(([px, py], pIdx) => {
      if (pIdx === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();

    // Milestones
    const milestones = [
      { pct: 0.22, label: '385 LBS (BASE)', color: '#94a3b8' },
      { pct: 0.54, label: '775 LBS (TESTED)', color: '#38bdf8' },
      { pct: 0.86, label: '1,180 LBS (CEILING)', color: '#c084fc' },
    ];
    milestones.forEach((m) => {
      const mx = x + 25 + m.pct * (w - 50);
      ctx.setLineDash([5, 5]);
      ctx.strokeStyle = m.color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(mx, y + 50);
      ctx.lineTo(mx, baselineY);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = m.color;
      ctx.beginPath();
      ctx.arc(mx, baselineY - 4, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.font = 'bold 16px monospace';
      ctx.fillText(m.label, mx - 45, y + 62);
    });
    ctx.restore();

  } else if (card.districtId === 'bodymap') {
    // Anatomical Biomechanical Recovery Matrix
    ctx.fillStyle = accent;
    ctx.font = 'bold 20px monospace';
    ctx.fillText('BIOMECHANICAL FATIGUE & RECOVERY MATRIX', x + 24, y + 36);

    // Left: High-tech wireframe human torso silhouette
    const cx = x + 120;
    const cy = y + h / 2 + 10;
    ctx.strokeStyle = accent;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy - 80, 20, 0, Math.PI * 2); // Head
    ctx.moveTo(cx, cy - 60);
    ctx.lineTo(cx, cy + 50); // Spine
    ctx.moveTo(cx - 45, cy - 44);
    ctx.lineTo(cx + 45, cy - 44); // Shoulders
    ctx.lineTo(cx + 34, cy + 36); // Ribs
    ctx.lineTo(cx - 34, cy + 36);
    ctx.closePath();
    ctx.stroke();

    // Right: 4 Muscle Fatigue Level Gauges
    const gauges = [
      { name: 'Pectoralis Major', pct: 0.88, stat: '88% RECOVERED', col: '#10b981' },
      { name: 'Latissimus Dorsi', pct: 0.42, stat: '42% ACUTE LOAD', col: '#f59e0b' },
      { name: 'Quadriceps Femoris', pct: 0.15, stat: '15% DEEP FATIGUE', col: '#ef4444' },
      { name: 'Deltoids & Traps', pct: 0.94, stat: '94% PRIMED', col: '#06b6d4' },
    ];
    const gx = x + 250;
    const gw = w - 280;
    gauges.forEach((g, gIdx) => {
      const gy = y + 54 + gIdx * 56;
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 18px -apple-system, sans-serif';
      ctx.fillText(g.name, gx, gy);

      ctx.fillStyle = g.col;
      ctx.font = 'bold 16px monospace';
      ctx.fillText(g.stat, gx + gw - ctx.measureText(g.stat).width, gy);

      // Track
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      ctx.fillRect(gx, gy + 10, gw, 12);
      // Fill
      ctx.fillStyle = g.col;
      ctx.fillRect(gx, gy + 10, gw * g.pct, 12);
    });

  } else if (card.districtId === 'river') {
    // Strength River Waves (Volume & Periodization)
    ctx.fillStyle = accent;
    ctx.font = 'bold 20px monospace';
    ctx.fillText('STRENGTH RIVER PERIODIZATION ACCUMULATION', x + 24, y + 36);

    const baselineY = y + h - 30;
    ctx.save();
    // 2 Layered Flowing Waves
    const waveGrad1 = ctx.createLinearGradient(0, y + 50, 0, baselineY);
    waveGrad1.addColorStop(0, '#10b981');
    waveGrad1.addColorStop(1, 'rgba(16, 185, 129, 0.05)');

    ctx.fillStyle = waveGrad1;
    ctx.globalAlpha = 0.5;
    ctx.beginPath();
    ctx.moveTo(x + 15, baselineY);
    for (let i = 0; i <= 50; i++) {
      const wx = x + 15 + (i / 50) * (w - 30);
      const wy = baselineY - 50 - Math.sin((i / 50) * Math.PI * 2.5) * 55;
      ctx.lineTo(wx, wy);
    }
    ctx.lineTo(x + w - 15, baselineY);
    ctx.closePath();
    ctx.fill();

    const waveGrad2 = ctx.createLinearGradient(0, y + 50, 0, baselineY);
    waveGrad2.addColorStop(0, '#3b82f6');
    waveGrad2.addColorStop(1, 'rgba(59, 130, 246, 0.05)');

    ctx.fillStyle = waveGrad2;
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.moveTo(x + 15, baselineY);
    for (let i = 0; i <= 50; i++) {
      const wx = x + 15 + (i / 50) * (w - 30);
      const wy = baselineY - 75 - Math.sin((i / 50) * Math.PI * 2.1 + 0.8) * 65;
      ctx.lineTo(wx, wy);
    }
    ctx.lineTo(x + w - 15, baselineY);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1.0;

    // Peak tonnage pill
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(x + w / 2 - 160, y + 50, 320, 34);
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2;
    ctx.strokeRect(x + w / 2 - 160, y + 50, 320, 34);
    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 16px monospace';
    ctx.fillText('425,000 LBS TOTAL RIVER TONNAGE', x + w / 2 - 138, y + 73);
    ctx.restore();

  } else {
    // Constellation: Neural CNS & Workout Star Map
    ctx.fillStyle = accent;
    ctx.font = 'bold 20px monospace';
    ctx.fillText('CNS MOTOR UNIT NEURAL CONSTELLATION', x + 24, y + 36);

    const nodes = [
      { nx: 0.16, ny: 0.42 },
      { nx: 0.32, ny: 0.74 },
      { nx: 0.48, ny: 0.36 },
      { nx: 0.66, ny: 0.66 },
      { nx: 0.84, ny: 0.44 },
      { nx: 0.38, ny: 0.54 },
      { nx: 0.62, ny: 0.40 },
    ];

    ctx.save();
    ctx.strokeStyle = 'rgba(168, 85, 247, 0.45)';
    ctx.lineWidth = 2;
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        if (Math.abs(nodes[i].nx - nodes[j].nx) < 0.34) {
          ctx.beginPath();
          ctx.moveTo(x + nodes[i].nx * w, y + 40 + nodes[i].ny * (h - 65));
          ctx.lineTo(x + nodes[j].nx * w, y + 40 + nodes[j].ny * (h - 65));
          ctx.stroke();
        }
      }
    }

    nodes.forEach((n, idx) => {
      const nx = x + n.nx * w;
      const ny = y + 40 + n.ny * (h - 65);
      ctx.fillStyle = idx === 2 ? '#c084fc' : '#a855f7';
      ctx.beginPath();
      ctx.arc(nx, ny, idx === 2 ? 9 : 7, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    });

    ctx.fillStyle = '#a855f7';
    ctx.font = 'bold 16px monospace';
    ctx.fillText('CNS RECOVERY READINESS: 94% (RESTED)', x + 24, y + h - 16);
    ctx.restore();
  }
}

function createCardCanvasTexture(
  card: BuildingCard & { districtName: string; districtColor: string },
  cardIndex: number,
  totalCards: number
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  // High-Density 1200 x 1600 Canvas for Razor-Sharp 3D Rendering
  canvas.width = 1200;
  canvas.height = 1600;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  const w = 1200;
  const h = 1600;
  const accent = card.districtColor || '#3b82f6';

  // 1. Deep architectural slate background
  const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
  bgGrad.addColorStop(0, '#0a1228');
  bgGrad.addColorStop(0.3, '#060c1c');
  bgGrad.addColorStop(0.8, '#040814');
  bgGrad.addColorStop(1, '#02050c');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, w, h);

  // Blueprint grid
  ctx.strokeStyle = 'rgba(59, 130, 246, 0.09)';
  ctx.lineWidth = 1.5;
  const gridSize = 50;
  for (let gx = 0; gx <= w; gx += gridSize) {
    ctx.beginPath();
    ctx.moveTo(gx, 0);
    ctx.lineTo(gx, h);
    ctx.stroke();
  }
  for (let gy = 0; gy <= h; gy += gridSize) {
    ctx.beginPath();
    ctx.moveTo(0, gy);
    ctx.lineTo(w, gy);
    ctx.stroke();
  }

  // 2. High-Tech Outer Border with Chamfered Sci-Fi Corners
  const pad = 28;
  const chamfer = 40;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(pad + chamfer, pad);
  ctx.lineTo(w - pad - chamfer, pad);
  ctx.lineTo(w - pad, pad + chamfer);
  ctx.lineTo(w - pad, h - pad - chamfer);
  ctx.lineTo(w - pad - chamfer, h - pad);
  ctx.lineTo(pad + chamfer, h - pad);
  ctx.lineTo(pad, h - pad - chamfer);
  ctx.lineTo(pad, pad + chamfer);
  ctx.closePath();

  ctx.strokeStyle = accent;
  ctx.lineWidth = 8;
  ctx.shadowColor = accent;
  ctx.shadowBlur = 28;
  ctx.stroke();
  ctx.restore();

  // Tech Corner Brackets
  const drawCornerBracket = (cx: number, cy: number, dx: number, dy: number) => {
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(cx, cy + dy * 36);
    ctx.lineTo(cx, cy);
    ctx.lineTo(cx + dx * 36, cy);
    ctx.stroke();
  };
  drawCornerBracket(pad + 18, pad + 18, 1, 1);
  drawCornerBracket(w - pad - 18, pad + 18, -1, 1);
  drawCornerBracket(pad + 18, h - pad - 18, 1, -1);
  drawCornerBracket(w - pad - 18, h - pad - 18, -1, -1);

  // 3. Header Bar: Large District Name & Index Counter
  ctx.fillStyle = accent;
  ctx.fillRect(64, 64, 14, 48);

  ctx.fillStyle = '#ffffff';
  ctx.font = '900 36px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.fillText(card.districtName.toUpperCase(), 92, 102);

  // Card index counter (right-aligned, large mono)
  ctx.fillStyle = accent;
  ctx.font = '900 36px monospace';
  const indexStr = `#${String(cardIndex + 1).padStart(2, '0')} / ${totalCards}`;
  const idxWidth = ctx.measureText(indexStr).width;
  ctx.fillText(indexStr, w - 70 - idxWidth, 102);

  // Tag chip
  ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
  const distNameWidth = ctx.measureText(card.districtName.toUpperCase()).width;
  ctx.fillRect(92 + distNameWidth + 24, 70, ctx.measureText(card.tag).width + 28, 38);
  ctx.fillStyle = '#cbd5e1';
  ctx.font = 'bold 18px monospace';
  ctx.fillText(card.tag, 92 + distNameWidth + 38, 96);

  // Divider rule
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.3)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(64, 136);
  ctx.lineTo(w - 64, 136);
  ctx.stroke();

  // 4. Massive Hero Card Title & Technical Subtitle
  ctx.fillStyle = '#ffffff';
  ctx.font = '900 58px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
  ctx.shadowBlur = 12;
  const nextY = wrapText(ctx, card.title, 64, 205, w - 128, 68, 2);
  ctx.shadowBlur = 0;

  ctx.fillStyle = '#94a3b8';
  ctx.font = '600 26px monospace';
  ctx.fillText(card.subtitle, 64, nextY + 12);

  // 5. Central High-Tech Visualizer Area
  const vizX = 64;
  const vizY = nextY + 36;
  const vizW = w - 128;
  const vizH = 360;
  drawDomainVisual(ctx, card, vizX, vizY, vizW, vizH, accent);

  // 6. Large Telemetry Stat Metric Boxes (Giant Numbers!)
  const statsY = vizY + vizH + 26;
  const statsCount = Math.min(4, Math.max(1, card.stats.length));
  const statBoxW = (vizW - (statsCount - 1) * 12) / statsCount;
  const statBoxH = 130;

  card.stats.slice(0, statsCount).forEach((st, sIdx) => {
    const sx = vizX + sIdx * (statBoxW + 12);
    // Stat Box background
    ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
    ctx.fillRect(sx, statsY, statBoxW, statBoxH);
    ctx.strokeStyle = 'rgba(59, 130, 246, 0.35)';
    ctx.lineWidth = 2;
    ctx.strokeRect(sx, statsY, statBoxW, statBoxH);

    // Large Stat Value
    ctx.fillStyle = accent;
    ctx.font = '900 52px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(st.v, sx + statBoxW / 2, statsY + 65);

    // Stat Label
    ctx.fillStyle = '#94a3b8';
    ctx.font = '700 20px -apple-system, BlinkMacSystemFont, sans-serif';
    ctx.fillText(st.l.toUpperCase(), sx + statBoxW / 2, statsY + 104);
  });
  ctx.textAlign = 'left';

  // 7. Biological Insight & Benchmark Takeaway Box
  const insY = statsY + statBoxH + 24;
  const insH = 260;
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  ctx.fillRect(vizX, insY, vizW, insH);
  ctx.strokeStyle = 'rgba(245, 158, 11, 0.5)';
  ctx.lineWidth = 2;
  ctx.strokeRect(vizX, insY, vizW, insH);

  // Left vertical amber highlight
  ctx.fillStyle = '#f59e0b';
  ctx.fillRect(vizX, insY, 10, insH);

  // Insight Title
  ctx.fillStyle = '#f59e0b';
  ctx.font = '900 22px monospace';
  ctx.fillText('⚡ BIOLOGICAL ADAPTATION & PHYSIOLOGICAL PROTOCOL', vizX + 32, insY + 42);

  // Insight Body Text (Large & Legible!)
  ctx.fillStyle = '#f1f5f9';
  ctx.font = '600 26px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  const insNextY = wrapText(ctx, card.insight, vizX + 32, insY + 84, vizW - 64, 38, 3);

  // Secondary Benchmark / Comparison Note
  if (card.comparison && insNextY < insY + insH - 30) {
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 22px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
    wrapText(ctx, `Benchmark: ${card.comparison}`, vizX + 32, insNextY + 10, vizW - 64, 32, 2);
  }

  // 8. Bottom Action Banner: Click 3D Wall
  const ctaY = h - 120;
  ctx.fillStyle = accent;
  ctx.fillRect(vizX, ctaY, vizW, 64);

  ctx.fillStyle = '#020617';
  ctx.font = '900 26px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('⬡  CLICK WALL OR PRESS ENTER TO INSPECT 3D MODEL  ⬡', w / 2, ctaY + 41);
  ctx.textAlign = 'left';

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  return texture;
}

interface ProminentCityViewerProps {
  onOpenCardModal: (card: BuildingCard) => void;
  activeDistrictId: DistrictId;
  onSelectDistrict: (id: DistrictId) => void;
  muscles?: Muscle[];
  onStimulateMuscle?: (id: string) => void;
}

export const ProminentCityViewer: React.FC<ProminentCityViewerProps> = ({
  onOpenCardModal,
  activeDistrictId,
  onSelectDistrict,
  muscles = [],
  onStimulateMuscle,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const viewerContainerRef = useRef<HTMLDivElement>(null);

  // All 26 cards sequentially
  const allCards = useMemo(() => {
    const list: (BuildingCard & { districtName: string; districtColor: string; districtIndex: number })[] = [];
    DISTRICTS_DATA.forEach((d, dIdx) => {
      d.buildings.forEach((b) => {
        list.push({
          ...b,
          districtName: d.label,
          districtColor: d.accentColor,
          districtIndex: dIdx,
        });
      });
    });
    return list;
  }, []);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const activeCard = allCards[currentIndex];

  // Continuous scroll progress: 0 to 25.
  // Each integer i is perfectly centered in front of card i.
  const scrollProgRef = useRef<number>(0);
  const targetProgRef = useRef<number>(0);

  // Dwell Resistance & Magnetic Snapping Engine
  // Threshold of accumulated wheel delta needed to dislodge from a card and advance
  const DWELL_THRESHOLD = 180;
  const dwellDeltaRef = useRef<number>(0);
  const dwellTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [dwellPct, setDwellPct] = useState<number>(0);
  const [isLockedOnCard, setIsLockedOnCard] = useState<boolean>(true);
  const [isCardCollapsed, setIsCardCollapsed] = useState<boolean>(false);
  const [isCinematicMode, setIsCinematicMode] = useState<boolean>(false);
  const [hoveredScrubIndex, setHoveredScrubIndex] = useState<number | null>(null);

  // Proximity to nearest card: 1.0 = right in front of the card, <0.4 = traveling between buildings
  const [cardProximity, setCardProximity] = useState<number>(1.0);
  const [nearestIndex, setNearestIndex] = useState<number>(0);

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  
  // Waypoint positions in 3D world space for each card
  const waypoints = useMemo(() => {
    const points: { cardPos: THREE.Vector3; camPos: THREE.Vector3; lookAt: THREE.Vector3 }[] = [];
    const total = allCards.length;

    for (let i = 0; i < total; i++) {
      const segmentT = total > 1 ? i / (total - 1) : 0;
      
      // S-curve highway through the 4 districts of the metropolis
      const x = Math.sin(segmentT * Math.PI * 2.8) * 16;
      const y = -1 + (i / Math.max(1, total)) * 14;
      const z = 24 - i * 18;

      // 3D Card Wall positioned along the highway plaza, majestic and facing the viewer
      const cardPos = new THREE.Vector3(x - 0.2, y + 1.8, z);
      // Camera positioned closer and framed squarely on the card wall for maximum text legibility
      const camPos = new THREE.Vector3(x + 0.45, y + 1.8, z + 7.4);
      // Camera looks directly at the card wall
      const lookAt = new THREE.Vector3(x - 0.2, y + 1.8, z);

      points.push({ cardPos, camPos, lookAt });
    }
    return points;
  }, [allCards.length]);

  // Update active district based on nearestIndex
  useEffect(() => {
    const curCard = allCards[nearestIndex];
    if (curCard && curCard.districtId !== activeDistrictId) {
      onSelectDistrict(curCard.districtId);
    }
  }, [nearestIndex, allCards, activeDistrictId, onSelectDistrict]);

  // Jump to district if triggered from outside
  useEffect(() => {
    const firstIdx = allCards.findIndex((c) => c.districtId === activeDistrictId);
    if (firstIdx !== -1 && Math.abs(targetProgRef.current - firstIdx) > 0.8) {
      targetProgRef.current = firstIdx;
    }
  }, [activeDistrictId, allCards]);

  // Three.js Scene Setup
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x040714);
    scene.fog = new THREE.FogExp2(0x040714, 0.015);

    const camera = new THREE.PerspectiveCamera(52, width / height, 0.1, 400);
    cameraRef.current = camera;
    
    // Initial camera at waypoint 0
    if (waypoints.length > 0) {
      camera.position.copy(waypoints[0].camPos);
      camera.lookAt(waypoints[0].lookAt);
    }

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    container.appendChild(renderer.domElement);

    // Ambient & Directional Lighting
    const ambientLight = new THREE.AmbientLight(0x7588a8, 0.9);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.4);
    mainLight.position.set(30, 60, 40);
    scene.add(mainLight);

    // City Ground Grid (Dark architectural floor)
    const groundGrid = new THREE.GridHelper(300, 60, 0x1e293b, 0x080e1a);
    groundGrid.position.y = -5.5;
    scene.add(groundGrid);

    // ----------------------------------------------------
    // Build 3D Architectural City: Towers & Tablets
    // ----------------------------------------------------
    const cityGroup = new THREE.Group();
    scene.add(cityGroup);

    // 1. Skyscraper Towers lining both sides of the boulevard
    const towerMats = [
      new THREE.MeshStandardMaterial({ color: 0x081020, roughness: 0.3, metalness: 0.85 }),
      new THREE.MeshStandardMaterial({ color: 0x0d1527, roughness: 0.4, metalness: 0.75 }),
      new THREE.MeshStandardMaterial({ color: 0x050a14, roughness: 0.2, metalness: 0.9 }),
      new THREE.MeshStandardMaterial({ color: 0x111c34, roughness: 0.35, metalness: 0.8 }),
    ];

    const windowColors = [0x38bdf8, 0x60a5fa, 0x818cf8, 0x34d399, 0xf59e0b];

    for (let k = 0; k < 80; k++) {
      const z = 35 - k * 6.0;
      const isRight = k % 2 === 0;
      const segmentProgress = k / 80;
      const curveX = Math.sin(segmentProgress * Math.PI * 2.8) * 16;
      // Flanking boulevard clearance: left towers and right towers
      const x = isRight ? (curveX + 9 + Math.random() * 18) : (curveX - 16 - Math.random() * 20);
      const bh = 14 + Math.random() * 38;
      const bw = 5 + Math.random() * 6;
      const bd = 5 + Math.random() * 6;
      const yBase = -5.5 + segmentProgress * 14;

      const geo = new THREE.BoxGeometry(bw, bh, bd);
      const mat = towerMats[k % towerMats.length];
      const tower = new THREE.Mesh(geo, mat);
      tower.position.set(x, yBase + bh / 2, z);
      cityGroup.add(tower);

      // Vertical illuminated architectural light bands on the towers facing the boulevard
      const stripGeo = new THREE.BoxGeometry(0.14, bh * 0.72, 0.14);
      const stripMat = new THREE.MeshBasicMaterial({
        color: windowColors[k % windowColors.length],
        transparent: true,
        opacity: 0.6,
      });
      const strip = new THREE.Mesh(stripGeo, stripMat);
      strip.position.set(
        isRight ? x - bw / 2 - 0.08 : x + bw / 2 + 0.08,
        yBase + bh / 2,
        z
      );
      cityGroup.add(strip);
    }

    // 2. Monolithic 3D Architectural Digital Display Walls at each waypoint
    const cardMeshes: THREE.Mesh[] = [];
    const edgeLinesArray: THREE.LineSegments[] = [];
    const texturesToDispose: THREE.CanvasTexture[] = [];

    const wallWidth = 6.6;
    const wallHeight = 8.8;
    const wallDepth = 0.4;
    const slabGeo = new THREE.BoxGeometry(wallWidth, wallHeight, wallDepth);
    const slabMat = new THREE.MeshStandardMaterial({
      color: 0x060c18,
      metalness: 0.9,
      roughness: 0.2,
    });
    const edgeGeo = new THREE.EdgesGeometry(slabGeo);
    const pedGeo = new THREE.BoxGeometry(wallWidth + 0.8, 0.9, 2.2);
    const pedMat = new THREE.MeshStandardMaterial({
      color: 0x030712,
      metalness: 0.95,
      roughness: 0.3,
    });

    const maxAniso = renderer.capabilities.getMaxAnisotropy();

    waypoints.forEach((wp, idx) => {
      const card = allCards[idx];
      const cardColor = card?.districtColor || '#3b82f6';
      const colorHex = parseInt(cardColor.replace('#', '0x')) || 0x3b82f6;

      // Group holding the entire architectural display wall
      const wallGroup = new THREE.Group();
      wallGroup.position.set(wp.cardPos.x, wp.cardPos.y, wp.cardPos.z);

      // Rotate wall to face camera approaching at this waypoint
      const angleY = Math.atan2(wp.camPos.x - wp.cardPos.x, wp.camPos.z - wp.cardPos.z);
      wallGroup.rotation.y = angleY;

      // 1. Titanium Architectural Backing Slab
      const slab = new THREE.Mesh(slabGeo, slabMat);
      wallGroup.add(slab);

      // 2. Glowing Neon Edge Outline around the wall
      const edgeMat = new THREE.LineBasicMaterial({
        color: colorHex,
        transparent: true,
        opacity: 0.65,
      });
      const edgeLines = new THREE.LineSegments(edgeGeo, edgeMat);
      wallGroup.add(edgeLines);
      edgeLinesArray.push(edgeLines);

      // 3. High-Resolution Digital Billboard Canvas Texture on the Wall Front Face
      const texture = createCardCanvasTexture(card, idx, allCards.length);
      texture.anisotropy = maxAniso;
      texturesToDispose.push(texture);

      const displayGeo = new THREE.PlaneGeometry(wallWidth - 0.1, wallHeight - 0.1);
      const displayMat = new THREE.MeshBasicMaterial({
        map: texture,
        side: THREE.FrontSide,
        toneMapped: false,
      });
      const displayPlane = new THREE.Mesh(displayGeo, displayMat);
      displayPlane.position.set(0, 0, wallDepth / 2 + 0.015);
      displayPlane.userData = { card, index: idx };
      wallGroup.add(displayPlane);
      cardMeshes.push(displayPlane);

      // 4. Heavy architectural foundation pedestal
      const pedestal = new THREE.Mesh(pedGeo, pedMat);
      pedestal.position.set(0, -wallHeight / 2 - 0.45, 0);
      wallGroup.add(pedestal);

      cityGroup.add(wallGroup);
    });

    // 3. Connecting Fly-Through Waypoint Guideline (The Highway)
    const curvePoints = waypoints.map((w) => w.camPos);
    const highwayCurve = new THREE.CatmullRomCurve3(curvePoints);
    const highwayGeo = new THREE.TubeGeometry(highwayCurve, 128, 0.05, 6, false);
    const highwayMat = new THREE.MeshBasicMaterial({ color: 0x2563eb, transparent: true, opacity: 0.4 });
    const highway = new THREE.Mesh(highwayGeo, highwayMat);
    scene.add(highway);

    // Animation & Render Loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);

      // Smooth damped lerp toward target scroll progress
      scrollProgRef.current += (targetProgRef.current - scrollProgRef.current) * 0.085;

      const p = Math.max(0, Math.min(waypoints.length - 1, scrollProgRef.current));
      const i0 = Math.floor(p);
      const i1 = Math.min(waypoints.length - 1, i0 + 1);
      const frac = p - i0;

      // Distance from exact card center
      const nearest = Math.round(p);
      const distFromNearest = Math.abs(p - nearest);
      const targetDistFromNearest = Math.abs(targetProgRef.current - Math.round(targetProgRef.current));
      
      // Proximity score: 1.0 when perfectly stopped at card, drops as user scrolls away
      const prox = Math.max(0, 1 - distFromNearest * 2.2);
      setCardProximity(prox);
      setNearestIndex(nearest);

      // Re-engage dwell lock when camera arrives close to destination integer waypoint
      if (distFromNearest < 0.035 && targetDistFromNearest < 0.035) {
        setIsLockedOnCard(true);
      }

      // Pulse neon rim of active card wall
      const time = clock.getElapsedTime();
      edgeLinesArray.forEach((edges, eIdx) => {
        const mat = edges.material as THREE.LineBasicMaterial;
        if (eIdx === nearest) {
          mat.opacity = 0.85 + Math.sin(time * 3.5) * 0.15;
        } else {
          mat.opacity = 0.4;
        }
      });

      // Interpolate camera along the highway
      const wp0 = waypoints[i0];
      const wp1 = waypoints[i1];

      // Smooth step interpolation
      const smoothFrac = THREE.MathUtils.smoothstep(frac, 0, 1);
      camera.position.lerpVectors(wp0.camPos, wp1.camPos, smoothFrac);

      const lookTarget = new THREE.Vector3().lerpVectors(wp0.lookAt, wp1.lookAt, smoothFrac);
      camera.lookAt(lookTarget);

      renderer.render(scene, camera);
    };

    animate();

    // Raycasting for direct click and hover on 3D card walls
    const pointerStart = { x: 0, y: 0, time: 0 };
    const raycaster = new THREE.Raycaster();
    const mouseVec = new THREE.Vector2();

    const onPointerDown = (e: MouseEvent) => {
      pointerStart.x = e.clientX;
      pointerStart.y = e.clientY;
      pointerStart.time = Date.now();
    };

    const onPointerUp = (e: MouseEvent) => {
      const dx = e.clientX - pointerStart.x;
      const dy = e.clientY - pointerStart.y;
      const dt = Date.now() - pointerStart.time;

      if (Math.hypot(dx, dy) < 8 && dt < 450) {
        const rect = container.getBoundingClientRect();
        mouseVec.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
        mouseVec.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

        raycaster.setFromCamera(mouseVec, camera);
        const hits = raycaster.intersectObjects(cardMeshes, false);

        if (hits.length > 0) {
          const targetCard = hits[0].object.userData?.card as BuildingCard | undefined;
          const targetIdx = hits[0].object.userData?.index as number | undefined;
          if (targetCard) {
            if (targetIdx !== undefined && targetIdx !== nearestIndex) {
              targetProgRef.current = targetIdx;
            } else {
              onOpenCardModal(targetCard);
            }
          }
        }
      }
    };

    const onPointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseVec.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseVec.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouseVec, camera);
      const hits = raycaster.intersectObjects(cardMeshes, false);
      container.style.cursor = hits.length > 0 ? 'pointer' : 'default';
    };

    container.addEventListener('mousedown', onPointerDown);
    container.addEventListener('mouseup', onPointerUp);
    container.addEventListener('mousemove', onPointerMove);

    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousedown', onPointerDown);
      container.removeEventListener('mouseup', onPointerUp);
      container.removeEventListener('mousemove', onPointerMove);
      texturesToDispose.forEach((t) => t.dispose());
      if (dwellTimerRef.current) {
        clearTimeout(dwellTimerRef.current);
      }
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [allCards, waypoints]);

  // Non-passive wheel event listener attached directly to DOM container
  // Guarantees 100% prevention of outer window scrolling collision
  useEffect(() => {
    const container = viewerContainerRef.current;
    if (!container) return;

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      e.stopPropagation();

      if (dwellTimerRef.current) {
        clearTimeout(dwellTimerRef.current);
      }

      const currentSnapped = Math.round(targetProgRef.current);
      const distToCenter = Math.abs(scrollProgRef.current - currentSnapped);

      if (distToCenter < 0.08) {
        dwellDeltaRef.current += e.deltaY;
        const absDelta = Math.abs(dwellDeltaRef.current);
        const pct = Math.min(100, Math.round((absDelta / DWELL_THRESHOLD) * 100));
        setDwellPct(pct);

        const elastic = (dwellDeltaRef.current / DWELL_THRESHOLD) * 0.035;
        targetProgRef.current = Math.max(0, Math.min(allCards.length - 1, currentSnapped + elastic));

        if (absDelta >= DWELL_THRESHOLD) {
          const dir = dwellDeltaRef.current > 0 ? 1 : -1;
          const nextIdx = Math.max(0, Math.min(allCards.length - 1, currentSnapped + dir));
          targetProgRef.current = nextIdx;
          dwellDeltaRef.current = 0;
          setDwellPct(0);
          setIsLockedOnCard(false);
        } else {
          dwellTimerRef.current = setTimeout(() => {
            dwellDeltaRef.current = 0;
            setDwellPct(0);
            targetProgRef.current = currentSnapped;
          }, 360);
        }
      } else {
        const delta = e.deltaY * 0.002;
        targetProgRef.current = Math.max(0, Math.min(allCards.length - 1, targetProgRef.current + delta));
      }
    };

    container.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      container.removeEventListener('wheel', onWheel);
    };
  }, [allCards.length]);

  // Touch Drag on mobile with magnetic threshold
  const touchStartY = useRef<number>(0);
  const touchDeltaAcc = useRef<number>(0);
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    touchDeltaAcc.current = 0;
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    const diff = touchStartY.current - e.touches[0].clientY;
    touchDeltaAcc.current += diff;
    touchStartY.current = e.touches[0].clientY;

    if (Math.abs(touchDeltaAcc.current) > 50) {
      const dir = touchDeltaAcc.current > 0 ? 1 : -1;
      const current = Math.round(targetProgRef.current);
      const next = Math.max(0, Math.min(allCards.length - 1, current + dir));
      targetProgRef.current = next;
      touchDeltaAcc.current = 0;
      setIsLockedOnCard(false);
    }
  };

  // Keyboard Navigation: Arrow Up/Down or Left/Right steps between cards with clean snap
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowRight' || e.key === 'KeyS' || e.key === 'KeyD') {
        goToNext();
      } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft' || e.key === 'KeyW' || e.key === 'KeyA') {
        goToPrev();
      } else if (e.key === 'c' || e.key === 'C') {
        setIsCinematicMode((prev) => !prev);
      } else if (e.key === 'm' || e.key === 'M') {
        setIsCardCollapsed((prev) => !prev);
      } else if (e.key === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        const curCard = allCards[nearestIndex];
        if (curCard) onOpenCardModal(curCard);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [allCards, nearestIndex, onOpenCardModal]);

  const goToNext = () => {
    dwellDeltaRef.current = 0;
    setDwellPct(0);
    const next = Math.min(allCards.length - 1, Math.round(targetProgRef.current) + 1);
    targetProgRef.current = next;
    setIsLockedOnCard(false);
  };

  const goToPrev = () => {
    dwellDeltaRef.current = 0;
    setDwellPct(0);
    const prev = Math.max(0, Math.round(targetProgRef.current) - 1);
    targetProgRef.current = prev;
    setIsLockedOnCard(false);
  };

  const jumpToIndex = (idx: number) => {
    dwellDeltaRef.current = 0;
    setDwellPct(0);
    targetProgRef.current = idx;
    setIsLockedOnCard(false);
  };

  const jumpToDistrict = (dId: DistrictId) => {
    dwellDeltaRef.current = 0;
    setDwellPct(0);
    const idx = allCards.findIndex((c) => c.districtId === dId);
    if (idx !== -1) {
      targetProgRef.current = idx;
      setIsLockedOnCard(false);
      onSelectDistrict(dId);
    }
  };

  const currentDisplayCard = allCards[nearestIndex] || allCards[0];

  const getBadgeStyle = (tagColor: BuildingCard['tagColor']) => {
    switch (tagColor) {
      case 'primary':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/30';
      case 'success':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'warning':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/30';
      case 'danger':
        return 'bg-red-500/10 text-red-400 border-red-500/30';
      case 'info':
        return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
      default:
        return 'bg-purple-500/10 text-purple-400 border-purple-500/30';
    }
  };

  return (
    <div
      ref={viewerContainerRef}
      className="relative w-full h-full min-h-0 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col justify-between select-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
    >
      
      {/* 3D WebGL Fly-Through Canvas */}
      <div ref={mountRef} className="absolute inset-0 pointer-events-none z-0" />

      {/* Subtle Atmospheric Vignette - keeps 3D metropolis vibrant and unblocked */}
      <div
        className="absolute inset-0 pointer-events-none z-10 transition-opacity duration-300"
        style={{
          background: 'radial-gradient(circle at 40% 50%, transparent 45%, rgba(4,7,20,0.45) 100%)',
          opacity: 0.4,
        }}
      />

      {/* ----------------- Top Floating Glass HUD ----------------- */}
      <div className="absolute top-2 sm:top-2.5 left-2 sm:left-4 right-2 sm:right-4 z-30 pointer-events-none flex items-center justify-between gap-2">
        
        {/* District & Card Telemetry Badge */}
        <div className="pointer-events-auto flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950/85 backdrop-blur-md border border-slate-800/80 text-xs shadow-xl">
          <div className="flex items-center gap-1.5 font-semibold text-white">
            <span
              className="w-2.5 h-2.5 rounded-full flex-shrink-0 animate-pulse"
              style={{ backgroundColor: currentDisplayCard.districtColor }}
            />
            <span className="truncate max-w-[120px] sm:max-w-none">{currentDisplayCard.districtName}</span>
          </div>

          <span className="text-slate-600">·</span>

          <span className="font-mono text-slate-300 font-bold whitespace-nowrap">
            {nearestIndex + 1} / {allCards.length}
          </span>

          <span className="text-slate-600">·</span>

          {/* Dwell Lock Status */}
          <div className="flex items-center gap-1.5">
            {isLockedOnCard ? (
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <Lock className="w-3 h-3 flex-shrink-0" />
                <span className="hidden sm:inline">Locked on Wall</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-blue-400 font-medium">
                <Compass className="w-3 h-3 flex-shrink-0 animate-spin" style={{ animationDuration: '6s' }} />
                <span className="hidden sm:inline">Cruising Avenue</span>
              </span>
            )}
            {isLockedOnCard && dwellPct > 0 && (
              <div className="w-10 sm:w-14 h-1.5 bg-slate-800 rounded-full overflow-hidden flex-shrink-0" title="Dwell break progress">
                <div
                  className="h-full bg-emerald-400 transition-all duration-75"
                  style={{ width: `${dwellPct}%` }}
                />
              </div>
            )}
          </div>
        </div>

        {/* View Controls: Inspect Model & Cinematic Toggle */}
        <div className="pointer-events-auto flex items-center gap-1.5 p-1 rounded-xl bg-slate-950/85 backdrop-blur-md border border-slate-800/80 shadow-xl">
          <button
            onClick={() => onOpenCardModal(currentDisplayCard)}
            className="flex items-center gap-1 px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all hover:scale-102 cursor-pointer"
            title="Open Deep-Dive Model Inspection"
          >
            <span>Inspect Model</span>
            <ArrowRight className="w-3 h-3" />
          </button>

          <button
            onClick={() => setIsCinematicMode(!isCinematicMode)}
            className={`flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              isCinematicMode
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
            title="Toggle Cinematic Mode (Press 'C')"
          >
            {isCinematicMode ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        </div>

      </div>

      {/* Floating Tactical Hint When Locked on 3D Wall */}
      {isLockedOnCard && !isCinematicMode && (
        <div className="absolute bottom-11 sm:bottom-12 left-1/2 -translate-x-1/2 z-20 pointer-events-auto flex items-center gap-2 px-3 sm:px-4 py-1.5 rounded-full bg-slate-950/90 backdrop-blur-md border border-blue-500/30 text-xs shadow-2xl animate-in fade-in duration-200">
          <Sparkles className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
          <span className="text-slate-300 font-medium">Click the 3D wall to deep-dive</span>
          <span className="text-slate-600">·</span>
          <button
            onClick={() => onOpenCardModal(currentDisplayCard)}
            className="text-blue-400 hover:text-blue-300 font-semibold cursor-pointer whitespace-nowrap"
          >
            Inspect →
          </button>
        </div>
      )}

      {/* ----------------- Bottom Minimal Architectural Timeline Scrubber ----------------- */}
      <div className="absolute bottom-1.5 sm:bottom-2 left-3 sm:left-6 right-3 sm:right-6 z-30 pointer-events-auto flex items-center gap-2">
        {/* Prev Arrow */}
        <button
          onClick={goToPrev}
          disabled={nearestIndex === 0}
          className="p-1 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-800/80 text-slate-400 hover:text-white disabled:opacity-20 cursor-pointer transition-colors flex-shrink-0"
          title="Previous Card (Up Arrow)"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
        </button>

        {/* 26-Segment Micro Progress Line */}
        <div className="relative flex-1 flex items-center gap-0.5 sm:gap-1 py-1 px-1.5 bg-slate-950/70 backdrop-blur-md border border-slate-800/70 rounded-full shadow-lg">
          {allCards.map((c, idx) => {
            const isSelected = idx === nearestIndex;
            return (
              <button
                key={c.id}
                onClick={() => jumpToIndex(idx)}
                onMouseEnter={() => setHoveredScrubIndex(idx)}
                onMouseLeave={() => setHoveredScrubIndex(null)}
                className={`relative flex-1 h-1.5 sm:h-2 rounded-full transition-all duration-150 cursor-pointer ${
                  isSelected
                    ? 'h-2 sm:h-2.5 scale-y-125 shadow-sm shadow-blue-500/50'
                    : 'opacity-40 hover:opacity-100 hover:h-2'
                }`}
                style={{
                  backgroundColor: c.districtColor || '#3b82f6',
                }}
                title={`${idx + 1}. ${c.title}`}
              />
            );
          })}

          {/* Hover Tooltip */}
          {hoveredScrubIndex !== null && (
            <div
              className="absolute bottom-6 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-700 text-white text-[11px] font-medium shadow-xl pointer-events-none transform -translate-x-1/2 whitespace-nowrap z-40 font-mono"
              style={{
                left: `${((hoveredScrubIndex + 0.5) / allCards.length) * 100}%`,
              }}
            >
              <span className="text-blue-400 font-bold mr-1">#{hoveredScrubIndex + 1}</span>
              {allCards[hoveredScrubIndex]?.title}
            </div>
          )}
        </div>

        {/* Next Arrow */}
        <button
          onClick={goToNext}
          disabled={nearestIndex === allCards.length - 1}
          className="p-1 rounded-md bg-slate-950/80 backdrop-blur-md border border-slate-800/80 text-slate-400 hover:text-white disabled:opacity-20 cursor-pointer transition-colors flex-shrink-0"
          title="Next Card (Down Arrow)"
        >
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

    </div>
  );
};
