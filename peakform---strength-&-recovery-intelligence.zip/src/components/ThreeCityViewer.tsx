import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { BuildingCard, DistrictId } from '../types';
import { DISTRICTS_DATA } from '../data/mockData';
import {
  Compass,
  Maximize2,
  Minimize2,
  RotateCcw,
  Sparkles,
  ChevronRight,
  Eye,
  Info,
  Layers,
  Zap,
} from 'lucide-react';

interface ThreeCityViewerProps {
  onSelectCard: (card: BuildingCard) => void;
  activeDistrictId: DistrictId;
  onSelectDistrict: (id: DistrictId) => void;
}

interface Card3DNode {
  card: BuildingCard;
  districtId: DistrictId;
  group: THREE.Group;
  mesh: THREE.Mesh;
  borderMesh: THREE.LineSegments;
  position: THREE.Vector3;
  targetPos: THREE.Vector3;
  colorHex: number;
}

export const ThreeCityViewer: React.FC<ThreeCityViewerProps> = ({
  onSelectCard,
  activeDistrictId,
  onSelectDistrict,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [hoveredCard, setHoveredCard] = useState<BuildingCard | null>(null);
  const [selectedNode, setSelectedNode] = useState<BuildingCard | null>(null);
  const [cameraSpeed, setCameraSpeed] = useState<number>(1);
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(true);

  // District anchor focal points in 3D world space
  const districtFoci: Record<DistrictId, { cam: THREE.Vector3; target: THREE.Vector3 }> = useMemo(() => ({
    ascent: {
      cam: new THREE.Vector3(-25, 28, 42),
      target: new THREE.Vector3(-28, 12, -5),
    },
    bodymap: {
      cam: new THREE.Vector3(38, 22, 38),
      target: new THREE.Vector3(26, 6, -2),
    },
    river: {
      cam: new THREE.Vector3(-36, -18, 32),
      target: new THREE.Vector3(-24, -22, -10),
    },
    constellation: {
      cam: new THREE.Vector3(32, -16, 40),
      target: new THREE.Vector3(28, -20, 2),
    },
    logger: {
      cam: new THREE.Vector3(0, 35, 50),
      target: new THREE.Vector3(0, 0, 0),
    }
  }), []);

  // Refs for three.js state
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cardNodesRef = useRef<Card3DNode[]>([]);
  const targetCamPos = useRef<THREE.Vector3>(new THREE.Vector3(-25, 28, 42));
  const targetLookAt = useRef<THREE.Vector3>(new THREE.Vector3(-28, 12, -5));
  const currentLookAt = useRef<THREE.Vector3>(new THREE.Vector3(-28, 12, -5));

  // Mouse drag & interaction refs
  const isDragging = useRef<boolean>(false);
  const prevMouse = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const raycaster = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseVec = useRef<THREE.Vector2>(new THREE.Vector2());

  // Fly to district when activeDistrictId changes
  useEffect(() => {
    const focus = districtFoci[activeDistrictId] || districtFoci.ascent;
    targetCamPos.current.copy(focus.cam);
    targetLookAt.current.copy(focus.target);
  }, [activeDistrictId, districtFoci]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x050812);
    scene.fog = new THREE.FogExp2(0x050812, 0.015);

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 300);
    cameraRef.current = camera;
    camera.position.set(-25, 28, 42);
    camera.lookAt(-28, 12, -5);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    container.appendChild(renderer.domElement);

    // 4. Lighting
    const ambientLight = new THREE.AmbientLight(0x88a0d0, 0.7);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(30, 40, 30);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x3b82f6, 0.6);
    dirLight2.position.set(-30, -20, -20);
    scene.add(dirLight2);

    // District accent point lights
    const lights = [
      { color: 0x3b82f6, pos: [-28, 18, 0] }, // Ascent blue
      { color: 0xef4444, pos: [26, 12, 0] },  // Body Map red
      { color: 0x06b6d4, pos: [-24, -18, 0] }, // River cyan
      { color: 0xa855f7, pos: [28, -16, 0] }, // Constellation purple
    ];
    lights.forEach((l) => {
      const pl = new THREE.PointLight(l.color, 2.5, 45, 1.8);
      pl.position.set(l.pos[0], l.pos[1], l.pos[2]);
      scene.add(pl);
    });

    // 5. Starfield Dust
    const starCount = 600;
    const starGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);
    const palette = [0x3b82f6, 0x06b6d4, 0xef4444, 0x8b5cf6, 0xffffff];

    for (let i = 0; i < starCount; i++) {
      const r = 40 + Math.random() * 80;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      starPos[i * 3 + 2] = r * Math.cos(phi);

      const col = new THREE.Color(palette[Math.floor(Math.random() * palette.length)]);
      starColors[i * 3] = col.r;
      starColors[i * 3 + 1] = col.g;
      starColors[i * 3 + 2] = col.b;
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const starMat = new THREE.PointsMaterial({
      size: 0.8,
      vertexColors: true,
      transparent: true,
      opacity: 0.8,
    });
    const starField = new THREE.Points(starGeo, starMat);
    scene.add(starField);

    // 6. District Floor Grids (Architectural City Pedestals)
    const createDistrictPedestal = (cx: number, cy: number, cz: number, colorHex: number, label: string) => {
      const group = new THREE.Group();
      group.position.set(cx, cy, cz);

      // Grid helper
      const grid = new THREE.GridHelper(28, 14, colorHex, 0x1e293b);
      grid.position.y = -0.5;
      group.add(grid);

      // Pedestal glow ring
      const ringGeo = new THREE.RingGeometry(12, 14, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color: colorHex,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.25,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.y = -0.48;
      group.add(ring);

      scene.add(group);
      return group;
    };

    createDistrictPedestal(-28, 6, 0, 0x3b82f6, 'Ascent');
    createDistrictPedestal(26, 0, 0, 0xef4444, 'Body Map');
    createDistrictPedestal(-24, -26, 0, 0x06b6d4, 'River');
    createDistrictPedestal(28, -24, 0, 0xa855f7, 'Constellation');

    // 7. Generate 3D Interactive Card Monoliths for all 26 buildings
    const cardNodes: Card3DNode[] = [];
    const colorMap: Record<DistrictId, number> = {
      ascent: 0x3b82f6,
      bodymap: 0xef4444,
      river: 0x06b6d4,
      constellation: 0xa855f7,
      logger: 0x3b82f6,
    };

    // Helper: draw crisp card face texture
    const createCardTexture = (card: BuildingCard, districtColor: string) => {
      const canvas = document.createElement('canvas');
      canvas.width = 384;
      canvas.height = 480;
      const ctx = canvas.getContext('2d');
      if (!ctx) return new THREE.CanvasTexture(canvas);

      // Background glass card
      ctx.fillStyle = '#090d18';
      ctx.fillRect(0, 0, 384, 480);

      // Accent border
      ctx.strokeStyle = districtColor;
      ctx.lineWidth = 6;
      ctx.strokeRect(6, 6, 372, 468);

      // Top Tag
      ctx.fillStyle = districtColor;
      ctx.font = 'bold 15px sans-serif';
      ctx.fillText(card.tag.toUpperCase(), 24, 42);

      // Title
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText(card.title, 24, 85);

      // Subtitle
      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px sans-serif';
      ctx.fillText(card.subtitle || '', 24, 115);

      // Divider line
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(24, 135);
      ctx.lineTo(360, 135);
      ctx.stroke();

      // Stats 3-box row
      const statW = 100;
      card.stats.slice(0, 3).forEach((st, idx) => {
        const x = 24 + idx * (statW + 8);
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(x, 150, statW, 70);
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 1;
        ctx.strokeRect(x, 150, statW, 70);

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 22px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(st.v, x + statW / 2, 185);

        ctx.fillStyle = '#94a3b8';
        ctx.font = 'bold 10px sans-serif';
        ctx.fillText(st.l.toUpperCase(), x + statW / 2, 205);
        ctx.textAlign = 'left';
      });

      // Insight snippet
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '14px sans-serif';
      const snippet = card.insight.length > 120 ? card.insight.slice(0, 120) + '...' : card.insight;
      
      // Multi-line wrap
      const words = snippet.split(' ');
      let line = '';
      let y = 260;
      for (const w of words) {
        const testLine = line + w + ' ';
        if (ctx.measureText(testLine).width > 330) {
          ctx.fillText(line, 24, y);
          line = w + ' ';
          y += 22;
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line, 24, y);

      // Bottom CTA bar
      ctx.fillStyle = districtColor;
      ctx.fillRect(24, 420, 336, 36);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('CLICK TO OPEN FULL ANALYSIS', 192, 444);

      const tex = new THREE.CanvasTexture(canvas);
      tex.minFilter = THREE.LinearFilter;
      tex.magFilter = THREE.LinearFilter;
      return tex;
    };

    // Calculate layout coordinates for each building
    DISTRICTS_DATA.forEach((district) => {
      const dColor = colorMap[district.id];
      const buildings = district.buildings;

      buildings.forEach((building, bIdx) => {
        let x = 0;
        let y = 0;
        let z = 0;

        if (district.id === 'ascent') {
          // Ascending staircase / mountain slope
          x = -36 + (bIdx % 3) * 8 + Math.sin(bIdx) * 3;
          y = 8 + bIdx * 3.8;
          z = -10 + bIdx * 3.5;
        } else if (district.id === 'bodymap') {
          // Circular cylinder chamber
          const ang = (bIdx / buildings.length) * Math.PI * 2;
          x = 26 + Math.cos(ang) * 11;
          y = 3 + bIdx * 2.5;
          z = Math.sin(ang) * 11;
        } else if (district.id === 'river') {
          // Flowing sinuous ribbon
          x = -38 + bIdx * 6;
          y = -26 + Math.sin(bIdx * 0.8) * 4;
          z = -12 + (bIdx % 2) * 5;
        } else {
          // Spiral galaxy cluster
          const phi = (bIdx / buildings.length) * Math.PI * 2.5;
          const rad = 6 + bIdx * 1.5;
          x = 28 + Math.cos(phi) * rad;
          y = -22 + (bIdx - 4) * 2;
          z = Math.sin(phi) * rad;
        }

        const group = new THREE.Group();
        group.position.set(x, y, z);

        // 3D Card Slab Geometry
        const cardW = 4.8;
        const cardH = 6.0;
        const cardD = 0.25;
        const slabGeo = new THREE.BoxGeometry(cardW, cardH, cardD);

        // Materials: front face has canvas texture, sides have dark glossy glass
        const frontTex = createCardTexture(building, district.accentColor);
        const frontMat = new THREE.MeshStandardMaterial({
          map: frontTex,
          roughness: 0.3,
          metalness: 0.1,
        });
        const edgeMat = new THREE.MeshStandardMaterial({
          color: 0x0f172a,
          roughness: 0.5,
          metalness: 0.8,
        });

        // Box material order: right, left, top, bottom, front, back
        const mats = [edgeMat, edgeMat, edgeMat, edgeMat, frontMat, edgeMat];
        const mesh = new THREE.Mesh(slabGeo, mats);
        mesh.userData = { card: building, districtId: district.id };
        group.add(mesh);

        // Glowing Wireframe Edge Border
        const wireGeo = new THREE.EdgesGeometry(slabGeo);
        const wireMat = new THREE.LineBasicMaterial({
          color: dColor,
          linewidth: 1.5,
          transparent: true,
          opacity: 0.6,
        });
        const borderMesh = new THREE.LineSegments(wireGeo, wireMat);
        group.add(borderMesh);

        // Ambient pedestal stem below the card
        const stemGeo = new THREE.CylinderGeometry(0.08, 0.08, 4, 8);
        const stemMat = new THREE.MeshBasicMaterial({ color: 0x1e293b, transparent: true, opacity: 0.5 });
        const stem = new THREE.Mesh(stemGeo, stemMat);
        stem.position.y = -4;
        group.add(stem);

        scene.add(group);

        cardNodes.push({
          card: building,
          districtId: district.id,
          group,
          mesh,
          borderMesh,
          position: new THREE.Vector3(x, y, z),
          targetPos: new THREE.Vector3(x, y, z),
          colorHex: dColor,
        });
      });
    });

    cardNodesRef.current = cardNodes;

    // 8. Animation & Render Loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const dt = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Smooth camera position interpolation
      camera.position.lerp(targetCamPos.current, 0.05 * cameraSpeed);

      // Smooth lookAt target interpolation
      currentLookAt.current.lerp(targetLookAt.current, 0.05 * cameraSpeed);
      camera.lookAt(currentLookAt.current);

      // Auto-rotation of the starfield and subtle card floating
      starField.rotation.y = elapsed * 0.02;

      cardNodes.forEach((node, idx) => {
        // Subtle floating bob
        node.group.position.y = node.targetPos.y + Math.sin(elapsed * 1.5 + idx * 0.4) * 0.3;

        // Face slightly toward camera on Y axis
        const toCam = camera.position.clone().sub(node.group.position);
        node.group.rotation.y = Math.atan2(toCam.x, toCam.z);
      });

      // Subtle slow orbit if auto-rotating and not interacting
      if (isAutoRotating && !isDragging.current) {
        targetCamPos.current.x += Math.sin(elapsed * 0.2) * 0.04;
      }

      renderer.render(scene, camera);
    };

    animate();

    // 9. Window Resize Handling
    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Clean up
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [cameraSpeed, isAutoRotating]);

  // Mouse & Touch Controls
  const handlePointerDown = (e: React.PointerEvent) => {
    isDragging.current = true;
    prevMouse.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const container = mountRef.current;
    if (!container || !cameraRef.current) return;

    // Raycast for hover
    const rect = container.getBoundingClientRect();
    mouseVec.current.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
    mouseVec.current.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

    raycaster.current.setFromCamera(mouseVec.current, cameraRef.current);
    const meshes = cardNodesRef.current.map((n) => n.mesh);
    const hits = raycaster.current.intersectObjects(meshes);

    if (hits.length > 0) {
      const hitMesh = hits[0].object as THREE.Mesh;
      const hitNode = cardNodesRef.current.find((n) => n.mesh === hitMesh);
      if (hitNode) {
        setHoveredCard(hitNode.card);
        container.style.cursor = 'pointer';
        // Pulse border
        hitNode.borderMesh.scale.set(1.08, 1.08, 1.08);
      }
    } else {
      setHoveredCard(null);
      container.style.cursor = isDragging.current ? 'grabbing' : 'grab';
      cardNodesRef.current.forEach((n) => n.borderMesh.scale.set(1, 1, 1));
    }

    // Drag Orbit Camera
    if (!isDragging.current) return;
    const dx = e.clientX - prevMouse.current.x;
    const dy = e.clientY - prevMouse.current.y;
    prevMouse.current = { x: e.clientX, y: e.clientY };

    // Orbit around lookAt center
    const offset = targetCamPos.current.clone().sub(targetLookAt.current);
    const radius = offset.length();

    let theta = Math.atan2(offset.x, offset.z);
    let phi = Math.acos(Math.max(-1, Math.min(1, offset.y / radius)));

    theta -= dx * 0.006;
    phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, phi + dy * 0.006));

    targetCamPos.current.x = targetLookAt.current.x + radius * Math.sin(phi) * Math.sin(theta);
    targetCamPos.current.y = targetLookAt.current.y + radius * Math.cos(phi);
    targetCamPos.current.z = targetLookAt.current.z + radius * Math.sin(phi) * Math.cos(theta);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDragging.current = false;
  };

  const handleClick = (e: React.MouseEvent) => {
    const container = mountRef.current;
    if (!container || !cameraRef.current) return;

    const rect = container.getBoundingClientRect();
    mouseVec.current.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
    mouseVec.current.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

    raycaster.current.setFromCamera(mouseVec.current, cameraRef.current);
    const meshes = cardNodesRef.current.map((n) => n.mesh);
    const hits = raycaster.current.intersectObjects(meshes);

    if (hits.length > 0) {
      const hitMesh = hits[0].object as THREE.Mesh;
      const hitNode = cardNodesRef.current.find((n) => n.mesh === hitMesh);
      if (hitNode) {
        setSelectedNode(hitNode.card);
        // Fly camera directly in front of this 3D card
        const cardPos = hitNode.group.position;
        targetLookAt.current.copy(cardPos);
        targetCamPos.current.set(cardPos.x, cardPos.y + 1, cardPos.z + 9);
        onSelectCard(hitNode.card);
      }
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const forward = targetLookAt.current.clone().sub(targetCamPos.current).normalize();
    const zoomDelta = e.deltaY * 0.03;
    const newPos = targetCamPos.current.clone().addScaledVector(forward, -zoomDelta);

    // Limit zoom distance
    const dist = newPos.distanceTo(targetLookAt.current);
    if (dist > 8 && dist < 120) {
      targetCamPos.current.copy(newPos);
    }
  };

  const resetCamera = () => {
    const focus = districtFoci[activeDistrictId] || districtFoci.ascent;
    targetCamPos.current.copy(focus.cam);
    targetLookAt.current.copy(focus.target);
  };

  return (
    <div className="relative w-full h-[620px] sm:h-[700px] bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
      
      {/* 3D WebGL Canvas Mount */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing touch-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onClick={handleClick}
        onWheel={handleWheel}
      />

      {/* Top Floating HUD: District Navigator Pills */}
      <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        
        {/* District Switcher Buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 backdrop-blur-md border border-slate-800 rounded-xl pointer-events-auto shadow-lg">
          {[
            { id: 'ascent', label: 'The Ascent', color: 'text-blue-400' },
            { id: 'bodymap', label: 'Body Map', color: 'text-red-400' },
            { id: 'river', label: 'Strength River', color: 'text-cyan-400' },
            { id: 'constellation', label: 'Constellation', color: 'text-purple-400' },
          ].map((d) => (
            <button
              key={d.id}
              onClick={() => onSelectDistrict(d.id as DistrictId)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                activeDistrictId === d.id
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>

        {/* View Controls & Reset Camera */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`p-2 rounded-lg border text-xs font-semibold backdrop-blur-md transition-colors cursor-pointer ${
              isAutoRotating
                ? 'bg-blue-600/20 border-blue-500/40 text-blue-300'
                : 'bg-slate-900/90 border-slate-800 text-slate-400 hover:text-white'
            }`}
            title="Toggle Cinematic Orbit"
          >
            <Sparkles className="w-4 h-4" />
          </button>
          <button
            onClick={resetCamera}
            className="p-2 bg-slate-900/90 backdrop-blur-md border border-slate-800 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Reset Camera View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Bottom Floating Card Teaser / Inspector Banner */}
      {hoveredCard && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-11/12 max-w-lg bg-slate-900/95 backdrop-blur-md border border-blue-500/40 rounded-xl p-4 shadow-2xl pointer-events-auto animate-in fade-in slide-in-from-bottom-2 duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">
              {hoveredCard.tag}
            </span>
            <span className="text-[10px] text-slate-400">Click card in 3D to open modal</span>
          </div>
          <h4 className="text-base font-bold text-white mt-0.5 font-display">
            {hoveredCard.title}
          </h4>
          <p className="text-xs text-slate-300 line-clamp-1 mt-1">
            {hoveredCard.subtitle}
          </p>
          <div className="flex items-center gap-4 mt-2 pt-2 border-t border-slate-800 text-xs font-mono text-slate-300">
            {hoveredCard.stats.slice(0, 3).map((s, idx) => (
              <div key={idx}>
                <span className="text-slate-500 text-[10px] uppercase block">{s.l}</span>
                <strong className="text-white">{s.v}</strong>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Navigation Helper Pill */}
      <div className="absolute bottom-4 left-4 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/80 backdrop-blur-sm border border-slate-800/80 text-[11px] text-slate-400 pointer-events-none">
        <Compass className="w-3.5 h-3.5 text-blue-400" />
        <span>Drag to orbit · Scroll to dolly · Click any 3D card to inspect</span>
      </div>

    </div>
  );
};
