import React, { useState } from 'react';
import { WorkoutSession } from '../types';
import { X, Plus, Trash2, Dumbbell, Sparkles, Check } from 'lucide-react';

interface WorkoutLoggerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveWorkout: (workout: Omit<WorkoutSession, 'id'>) => void;
}

export const WorkoutLoggerModal: React.FC<WorkoutLoggerModalProps> = ({
  isOpen,
  onClose,
  onSaveWorkout,
}) => {
  const [split, setSplit] = useState<'push' | 'pull' | 'legs' | 'longevity'>('pull');
  const [name, setName] = useState('Heavy Pull & Lat Supercompensation');
  const [durationMin, setDurationMin] = useState(48);
  const [rpeAvg, setRpeAvg] = useState(8.5);
  const [notes, setNotes] = useState('Focused on strict scapular retraction and controlled eccentric phase.');

  const [exercises, setExercises] = useState([
    { name: 'Barbell Row', sets: 4, reps: 8, weightLbs: 165 },
    { name: 'Weighted Pull-Up', sets: 4, reps: 6, weightLbs: 195 },
    { name: 'Face Pulls', sets: 4, reps: 15, weightLbs: 45 },
    { name: 'Incline Dumbbell Curl', sets: 3, reps: 10, weightLbs: 32 }
  ]);

  if (!isOpen) return null;

  // Calculate live volume
  const totalVolume = exercises.reduce(
    (acc, ex) => acc + ex.sets * ex.reps * ex.weightLbs,
    0
  );

  const workDensity = durationMin > 0 ? (totalVolume / durationMin).toFixed(1) : '0';

  const handleAddExercise = () => {
    setExercises([
      ...exercises,
      { name: 'Accessory Movement', sets: 3, reps: 10, weightLbs: 50 }
    ]);
  };

  const handleRemoveExercise = (idx: number) => {
    setExercises(exercises.filter((_, i) => i !== idx));
  };

  const handleExerciseChange = (idx: number, field: string, value: any) => {
    const updated = [...exercises];
    updated[idx] = { ...updated[idx], [field]: value };
    setExercises(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveWorkout({
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      name,
      split,
      durationMin: Number(durationMin),
      volumeLbs: totalVolume,
      workDensity: Number(workDensity),
      rpeAvg: Number(rpeAvg),
      exercises,
      notes,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8 shadow-2xl text-slate-100"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">
          <Dumbbell className="w-4 h-4" />
          <span>Active Workout Logger</span>
        </div>
        <h3 className="text-2xl font-bold text-white font-display">
          Log Training Session
        </h3>
        <p className="text-xs text-slate-400 mb-6">
          Record sets, reps, and load. This will recalculate your recovery states, volume river, and streak.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Split Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Training Split
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'push', label: 'Push' },
                { id: 'pull', label: 'Pull' },
                { id: 'legs', label: 'Legs' },
                { id: 'longevity', label: 'Longevity' }
              ].map((s) => (
                <button
                  type="button"
                  key={s.id}
                  onClick={() => {
                    setSplit(s.id as any);
                    if (s.id === 'pull') setName('Heavy Pull & Lat Supercompensation');
                    else if (s.id === 'push') setName('Push Strength & Triceps Hypertrophy');
                    else if (s.id === 'legs') setName('Squat Depth & Posterior Chain');
                    else setName('Longevity & Rotator Cuff Reset');
                  }}
                  className={`py-2 text-xs font-semibold rounded-lg border transition-colors cursor-pointer capitalize ${
                    split === s.id
                      ? 'bg-blue-600 border-blue-500 text-white shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Session Name & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Workout Title
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Duration (min)
              </label>
              <input
                type="number"
                min="5"
                max="240"
                value={durationMin}
                onChange={(e) => setDurationMin(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-blue-500"
                required
              />
            </div>
          </div>

          {/* Live Volume Summary Banner */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400 font-medium">Accumulated Tonnage</div>
              <div className="text-xl font-bold text-blue-400 font-mono tabular-nums">
                {totalVolume.toLocaleString()} lbs
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400 font-medium">Work Density</div>
              <div className="text-sm font-semibold text-slate-200 font-mono tabular-nums">
                {workDensity} lbs/min
              </div>
            </div>
          </div>

          {/* Exercise Builder */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Working Sets & Movements
              </label>
              <button
                type="button"
                onClick={handleAddExercise}
                className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 font-semibold cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Movement</span>
              </button>
            </div>

            <div className="space-y-2">
              {exercises.map((ex, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-2 p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-lg"
                >
                  <input
                    type="text"
                    value={ex.name}
                    onChange={(e) => handleExerciseChange(idx, 'name', e.target.value)}
                    className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded text-xs text-white"
                    placeholder="Exercise name"
                    required
                  />
                  <div className="flex items-center gap-1.5 w-20">
                    <input
                      type="number"
                      min="1"
                      value={ex.sets}
                      onChange={(e) => handleExerciseChange(idx, 'sets', Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-slate-900 border border-slate-800 rounded text-xs text-white font-mono text-center"
                      title="Sets"
                      required
                    />
                    <span className="text-slate-500 text-xs">×</span>
                  </div>
                  <div className="flex items-center gap-1.5 w-20">
                    <input
                      type="number"
                      min="1"
                      value={ex.reps}
                      onChange={(e) => handleExerciseChange(idx, 'reps', Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-slate-900 border border-slate-800 rounded text-xs text-white font-mono text-center"
                      title="Reps"
                      required
                    />
                    <span className="text-slate-500 text-xs">@</span>
                  </div>
                  <div className="w-24">
                    <input
                      type="number"
                      min="0"
                      step="5"
                      value={ex.weightLbs}
                      onChange={(e) => handleExerciseChange(idx, 'weightLbs', Number(e.target.value))}
                      className="w-full px-2 py-1.5 bg-slate-900 border border-slate-800 rounded text-xs text-white font-mono text-center"
                      title="Weight in lbs"
                      required
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">lbs</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveExercise(idx)}
                    className="p-1.5 text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Notes & RPE */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Session Notes & Biomechanics
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Average RPE
              </label>
              <input
                type="number"
                min="5"
                max="10"
                step="0.5"
                value={rpeAvg}
                onChange={(e) => setRpeAvg(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm shadow-blue-600/30 transition-colors cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Log & Sync to Ledger</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
