import React, { useState } from 'react';
import { Muscle, MuscleCategory, BuildingCard } from '../types';
import { Activity, Clock, Zap, CheckCircle2, AlertTriangle, ChevronRight, RotateCcw, Dumbbell, Box } from 'lucide-react';
import { ThreeDistrictWidget } from './ThreeDistrictWidget';

interface BodyMapViewProps {
  muscles: Muscle[];
  cards: BuildingCard[];
  onSelectCard: (card: BuildingCard) => void;
  onQuickStimulateMuscle: (muscleId: string) => void;
}

export const BodyMapView: React.FC<BodyMapViewProps> = ({
  muscles,
  cards,
  onSelectCard,
  onQuickStimulateMuscle,
}) => {
  const [displayType, setDisplayType] = useState<'2d' | '3d'>('2d');
  const [activeView, setActiveView] = useState<'anterior' | 'posterior'>('anterior');
  const [selectedCategory, setSelectedCategory] = useState<MuscleCategory | 'all'>('all');
  const [selectedMuscleId, setSelectedMuscleId] = useState<string>(muscles[0]?.id || 'chest-pectoralis-major');

  // Filtered list
  const filteredMuscles = muscles.filter((m) => {
    const matchesCategory = selectedCategory === 'all' || m.category === selectedCategory;
    const matchesView = m.view === activeView || m.view === 'both';
    return matchesCategory && matchesView;
  });

  const selectedMuscle = muscles.find((m) => m.id === selectedMuscleId) || muscles[0];

  // Helper status color styling
  const getStatusColor = (status: Muscle['status']) => {
    switch (status) {
      case 'fatigued':
        return {
          bg: 'bg-red-500/10',
          border: 'border-red-500/30',
          text: 'text-red-400',
          dot: '#ef4444',
          label: 'Fatigued (<40%)'
        };
      case 'recovering':
        return {
          bg: 'bg-amber-500/10',
          border: 'border-amber-500/30',
          text: 'text-amber-400',
          dot: '#f59e0b',
          label: 'Growth Window (40-75%)'
        };
      case 'primed':
        return {
          bg: 'bg-emerald-500/10',
          border: 'border-emerald-500/30',
          text: 'text-emerald-400',
          dot: '#10b981',
          label: 'Supercompensation Peak'
        };
      case 'overdue':
        return {
          bg: 'bg-rose-500/20',
          border: 'border-rose-500/40',
          text: 'text-rose-400',
          dot: '#f43f5e',
          label: 'Overdue / Atrophy Risk'
        };
    }
  };

  return (
    <div className="space-y-10">
      
      {/* Editorial Header */}
      <div>
        <div className="flex items-center gap-2 text-xs text-red-400 font-semibold mb-2">
          <span>BODY MAP & RECOVERY MATRIX</span>
          <span aria-hidden="true">·</span>
          <span>47 MUSCLES TRACKED</span>
          <span aria-hidden="true">·</span>
          <span>TWO-COMPARTMENT FATIGUE DECAY</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display text-balance">
          Real-Time Musculoskeletal Recovery Engine
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-400 max-w-3xl leading-relaxed">
          Dynamic biological decay tracking across fast-twitch motor units and myotendinous tissue.
          Red signifies acute fatigue; emerald signals supercompensation growth windows.
        </p>
      </div>

      {/* Main Interactive Anatomy Viewer Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Interactive Anatomical Silhouette Viewer (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col items-center">
          
          {/* View Mode Toggle: 2D vs 3D */}
          <div className="w-full flex items-center justify-between mb-3 pb-3 border-b border-slate-800/80">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Box className="w-3.5 h-3.5 text-red-400" />
              <span>Anatomy Engine</span>
            </span>
            <div className="flex items-center p-0.5 bg-slate-950 border border-slate-800 rounded-lg">
              <button
                onClick={() => setDisplayType('2d')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  displayType === '2d' ? 'bg-red-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                2D Silhouette
              </button>
              <button
                onClick={() => setDisplayType('3d')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                  displayType === '3d' ? 'bg-red-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                3D Fiber Wireframe
              </button>
            </div>
          </div>

          {displayType === '3d' ? (
            <div className="w-full max-w-[320px]">
              <ThreeDistrictWidget districtId="bodymap" heightPx={480} />
              <p className="text-[11px] text-slate-500 text-center mt-3">
                Rotating 3D anatomical fiber core with pulsating metabolic node indicators.
              </p>
            </div>
          ) : (
            <>
              {/* Aspect Toggle */}
              <div className="w-full flex items-center justify-between mb-4">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Anatomical Aspect
                </span>
                <div className="flex items-center p-1 bg-slate-950 border border-slate-800 rounded-lg">
                  <button
                    onClick={() => setActiveView('anterior')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      activeView === 'anterior'
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Anterior (Front)
                  </button>
                  <button
                    onClick={() => setActiveView('posterior')}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                      activeView === 'posterior'
                        ? 'bg-blue-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Posterior (Back)
                  </button>
                </div>
              </div>

              {/* Interactive Silhouette Map */}
              <div className="relative w-full max-w-[280px] h-[480px] bg-slate-950/60 border border-slate-800/80 rounded-xl flex items-center justify-center overflow-hidden">
                
                {/* Anatomical Outline SVG */}
                <svg viewBox="0 0 200 400" className="w-full h-full p-4 opacity-40">
                  {/* Head */}
                  <circle cx="100" cy="40" r="18" fill="none" stroke="#64748b" strokeWidth="2" />
                  {/* Torso */}
                  <path
                    d="M 75 70 L 125 70 L 115 170 L 85 170 Z"
                    fill="none"
                    stroke="#64748b"
                    strokeWidth="2"
                  />
                  {/* Arms */}
                  <path
                    d="M 75 70 L 50 140 L 40 210"
                    fill="none"
                    stroke="#64748b"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 125 70 L 150 140 L 160 210"
                    fill="none"
                    stroke="#64748b"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  {/* Legs */}
                  <path
                    d="M 88 170 L 80 280 L 76 380"
                    fill="none"
                    stroke="#64748b"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                  <path
                    d="M 112 170 L 120 280 L 124 380"
                    fill="none"
                    stroke="#64748b"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>

                {/* Interactive Muscle Nodes positioned proportionally */}
                {filteredMuscles.map((muscle) => {
                  const statusStyle = getStatusColor(muscle.status);
                  const isSelected = muscle.id === selectedMuscleId;
                  
                  // Remap coordinates (0-100) to pixel bounds
                  const leftPercent = muscle.coordinates.x;
                  const topPercent = muscle.coordinates.y;

                  return (
                    <button
                      key={muscle.id}
                      onClick={() => setSelectedMuscleId(muscle.id)}
                      style={{ left: `${leftPercent}%`, top: `${topPercent}%` }}
                      title={`${muscle.name} - ${muscle.recoveryPercentage}%`}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 group p-1 transition-transform cursor-pointer ${
                        isSelected ? 'scale-125 z-20' : 'hover:scale-110 z-10'
                      }`}
                    >
                      <span className="relative flex h-4 w-4">
                        {isSelected && (
                          <span
                            className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
                            style={{ backgroundColor: statusStyle.dot }}
                          />
                        )}
                        <span
                          className="relative inline-flex rounded-full h-4 w-4 border-2 border-slate-900 shadow-md transition-all"
                          style={{ backgroundColor: statusStyle.dot }}
                        />
                      </span>
                    </button>
                  );
                })}

                {/* Floating legend overlay */}
                <div className="absolute bottom-3 left-3 right-3 bg-slate-900/90 backdrop-blur-sm border border-slate-800 rounded-lg p-2 text-[10px] text-slate-400 grid grid-cols-2 gap-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    <span>Fatigued (0-40%)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>Growth (40-75%)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>Primed (75-100%)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500" />
                    <span>Overdue (Atrophy)</span>
                  </div>
                </div>

              </div>

              <p className="text-[11px] text-slate-500 text-center mt-3">
                Click any anatomical point to inspect real-time recovery metrics.
              </p>
            </>
          )}

        </div>

        {/* Right Column: Muscle Inspector & Category Filters (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'all', label: 'All 47 Muscles' },
              { id: 'major', label: 'Major Movers' },
              { id: 'longevity', label: 'Longevity & Posture' },
              { id: 'hands', label: 'Grip & Forearms' },
              { id: 'feet', label: 'Feet & Ankles' }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-blue-600 text-white font-semibold shadow-sm'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Active Muscle Inspector Card */}
          {selectedMuscle && (
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 relative">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 uppercase tracking-wider mb-1">
                    <span>{selectedMuscle.category} Muscle</span>
                    <span aria-hidden="true">·</span>
                    <span className="italic">{selectedMuscle.scientificName}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white font-display">
                    {selectedMuscle.name}
                  </h3>
                </div>

                <div className="flex items-center gap-3">
                  <div className={`px-3 py-1 rounded-md border text-xs font-semibold ${getStatusColor(selectedMuscle.status).bg} ${getStatusColor(selectedMuscle.status).border} ${getStatusColor(selectedMuscle.status).text}`}>
                    {getStatusColor(selectedMuscle.status).label}
                  </div>

                  <button
                    onClick={() => onQuickStimulateMuscle(selectedMuscle.id)}
                    className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors cursor-pointer"
                    title="Simulate training this muscle to reset its fatigue curve"
                  >
                    <Dumbbell className="w-3.5 h-3.5" />
                    <span>Stimulate</span>
                  </button>
                </div>
              </div>

              {/* Progress & Recovery Metrics */}
              <div className="mt-5 space-y-4">
                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1.5 font-medium">
                    <span>Supercompensation Readiness</span>
                    <span className="font-mono text-white font-bold tabular-nums">
                      {selectedMuscle.recoveryPercentage}%
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${selectedMuscle.recoveryPercentage}%`,
                        backgroundColor: getStatusColor(selectedMuscle.status).dot
                      }}
                    />
                  </div>
                </div>

                {/* 4-Stat Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                  <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
                    <div className="text-xs text-slate-400">Elapsed</div>
                    <div className="text-lg font-bold text-white font-mono tabular-nums">
                      {selectedMuscle.hoursSinceTrained}h
                    </div>
                    <div className="text-[10px] text-slate-500">since load</div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
                    <div className="text-xs text-slate-400">Cadence</div>
                    <div className="text-lg font-bold text-white font-mono tabular-nums">
                      {selectedMuscle.restCadenceHours}h
                    </div>
                    <div className="text-[10px] text-slate-500">ideal rest</div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
                    <div className="text-xs text-slate-400">Fast Decay</div>
                    <div className="text-lg font-bold text-blue-400 font-mono tabular-nums">
                      {selectedMuscle.fastDecay}
                    </div>
                    <div className="text-[10px] text-slate-500">fast-twitch k_1</div>
                  </div>

                  <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 text-center">
                    <div className="text-xs text-slate-400">Slow Decay</div>
                    <div className="text-lg font-bold text-indigo-400 font-mono tabular-nums">
                      {selectedMuscle.slowDecay}
                    </div>
                    <div className="text-[10px] text-slate-500">tendon k_2</div>
                  </div>
                </div>

                {/* Narrative Observations */}
                <div className="bg-slate-950/40 border border-slate-800/60 rounded-lg p-3.5 text-xs sm:text-sm text-slate-300 leading-relaxed">
                  <p>{selectedMuscle.notes}</p>
                </div>

                {/* Prescribed Exercises */}
                <div>
                  <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                    Recommended High-Yield Exercises
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedMuscle.recommendedExercises.map((ex, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded bg-slate-950 border border-slate-800 text-xs text-slate-300 font-medium"
                      >
                        {ex}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* Quick List of Overdue or Primed Muscles */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              Visible Muscles in View ({filteredMuscles.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
              {filteredMuscles.map((m) => {
                const isSelected = m.id === selectedMuscleId;
                const statusStyle = getStatusColor(m.status);
                return (
                  <button
                    key={m.id}
                    onClick={() => setSelectedMuscleId(m.id)}
                    className={`flex items-center justify-between p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 border-blue-500 text-white'
                        : 'bg-slate-950/40 border-slate-800/80 text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="truncate pr-2">
                      <div className="text-xs font-semibold truncate">{m.name}</div>
                      <div className="text-[10px] text-slate-400">{m.hoursSinceTrained}h ago</div>
                    </div>
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: statusStyle.dot }}
                    />
                  </button>
                );
              })}
            </div>
          </div>

        </div>

      </div>

      {/* Body Map Milestone Cards */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight font-display">
              Recovery Dynamics & Systemic Load
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Explore how today’s training ripples across your entire biomechanical chain.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card) => (
            <div
              key={card.id}
              onClick={() => onSelectCard(card)}
              className="group bg-slate-900 border border-slate-800 hover:border-red-500/50 rounded-xl p-5 transition-all duration-200 flex flex-col justify-between cursor-pointer hover:shadow-lg hover:shadow-red-500/5"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-red-400 tracking-wide uppercase">
                    {card.tag}
                  </span>
                  <span className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-xs font-mono font-bold text-slate-300">
                    {card.iconChar}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-red-300 transition-colors font-display">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 mb-4 line-clamp-1">
                  {card.subtitle}
                </p>

                <div className="grid grid-cols-3 gap-2 mb-4 bg-slate-950/60 border border-slate-800/80 rounded-lg p-2.5">
                  {card.stats.slice(0, 3).map((st, sIdx) => (
                    <div key={sIdx} className="text-center">
                      <div className="text-sm font-bold text-white font-mono tabular-nums">
                        {st.v}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-0.5 truncate">
                        {st.l}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {card.insight}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-red-400 font-semibold group-hover:text-red-300">
                <span>View Full Analysis</span>
                <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
