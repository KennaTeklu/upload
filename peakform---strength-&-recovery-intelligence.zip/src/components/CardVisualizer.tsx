import React, { useState } from 'react';
import { BuildingCard, Muscle } from '../types';
import {
  Activity,
  Zap,
  TrendingUp,
  Waves,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sliders,
  Flame,
  Layers,
  HeartPulse
} from 'lucide-react';

interface CardVisualizerProps {
  card: BuildingCard;
  muscles: Muscle[];
  onStimulateMuscle?: (muscleId: string) => void;
}

export const CardVisualizer: React.FC<CardVisualizerProps> = ({
  card,
  muscles,
  onStimulateMuscle,
}) => {
  // Monte Carlo sandbox state for Ascent cards
  const [bodyweight, setBodyweight] = useState<number>(165);
  const [sessionsPerWeek, setSessionsPerWeek] = useState<number>(4);
  const [geneticCeiling, setGeneticCeiling] = useState<number>(1.1);

  // River scrubber state
  const [selectedWeek, setSelectedWeek] = useState<number>(26);

  // Constellation filter state
  const [activeCluster, setActiveCluster] = useState<'all' | 'push' | 'pull' | 'legs' | 'longevity'>('all');

  // Anatomy layer toggle
  const [anatomyView, setAnatomyView] = useState<'striations' | 'heatmap' | 'innervation'>('heatmap');
  const [stimulatedSuccess, setStimulatedSuccess] = useState<string | null>(null);

  // Trigger stimulation with visual feedback
  const handleStimulate = (muscleId: string, label: string) => {
    if (onStimulateMuscle) {
      onStimulateMuscle(muscleId);
      setStimulatedSuccess(`Stimulated ${label}! Fatigue reset to acute adaptation phase.`);
      setTimeout(() => setStimulatedSuccess(null), 3000);
    }
  };

  // -------------------------------------------------------------
  // 1. BODY MAP: REALISTIC ANATOMICAL VISUALIZATIONS
  // -------------------------------------------------------------
  if (card.districtId === 'bodymap') {
    // Specific muscle detection based on card ID
    const isPecs = card.id === 'bm-today' || card.id.includes('pec');
    const isLats = card.id === 'bm-acute' || card.id.includes('lat') || card.id === 'bm-ripple';
    const isQuads = card.id === 'bm-ready' || card.id.includes('quad');
    const isCalves = card.id === 'bm-neglected' || card.id.includes('calv');
    const isCNS = card.id === 'bm-cns' || card.id.includes('cns');

    return (
      <div className="w-full flex flex-col gap-1.5 bg-slate-950/90 border border-slate-800/90 rounded-xl p-2">
        
        {/* Anatomy Header & Layer Switcher */}
        <div className="flex items-center justify-between gap-1.5 border-b border-slate-800/70 pb-1">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-300">
            <Activity className="w-3 h-3 text-red-400" />
            <span className="font-mono uppercase tracking-wider text-[10px] text-slate-400">
              Anatomy · Vector
            </span>
          </div>

          <div className="flex items-center gap-0.5 text-[9px] font-medium bg-slate-900 border border-slate-800 p-0.5 rounded-lg">
            <button
              onClick={() => setAnatomyView('heatmap')}
              className={`px-1.5 py-0.5 rounded transition-colors cursor-pointer ${
                anatomyView === 'heatmap' ? 'bg-red-500/20 text-red-300 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Heatmap
            </button>
            <button
              onClick={() => setAnatomyView('striations')}
              className={`px-1.5 py-0.5 rounded transition-colors cursor-pointer ${
                anatomyView === 'striations' ? 'bg-blue-500/20 text-blue-300 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Striations
            </button>
            <button
              onClick={() => setAnatomyView('innervation')}
              className={`px-1.5 py-0.5 rounded transition-colors cursor-pointer ${
                anatomyView === 'innervation' ? 'bg-amber-500/20 text-amber-300 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Innervation
            </button>
          </div>
        </div>

        {/* Anatomical Graphic Viewport */}
        <div className="relative w-full h-24 sm:h-28 bg-gradient-to-b from-slate-950 via-slate-900/60 to-slate-950 border border-slate-800/80 rounded-lg flex items-center justify-center overflow-hidden p-1">
          
          {/* Subtle anatomical measurement grid */}
          <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:12px_12px] opacity-40 pointer-events-none" />

          {/* Realistic SVG Anatomical Drawing */}
          {isPecs && (
            <svg viewBox="0 0 320 160" className="w-full h-full max-w-[280px]">
              <defs>
                <linearGradient id="pecFatigueGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity="0.85" />
                  <stop offset="50%" stopColor="#b91c1c" stopOpacity="0.95" />
                  <stop offset="100%" stopColor="#7f1d1d" stopOpacity="0.9" />
                </linearGradient>
                <pattern id="striationPat" width="6" height="6" patternTransform="rotate(25 0 0)" patternUnits="userSpaceOnUse">
                  <line x1="0" y1="0" x2="0" y2="6" stroke="#fca5a5" strokeWidth="1.2" opacity="0.4" />
                </pattern>
              </defs>

              {/* Sternal Landmark */}
              <rect x="156" y="24" width="8" height="112" rx="3" fill="#334155" stroke="#475569" strokeWidth="1" />
              <text x="160" y="20" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">STERNUM</text>

              {/* Clavicle Bars */}
              <path d="M 40 28 Q 100 22 156 26" fill="none" stroke="#64748b" strokeWidth="3.5" strokeLinecap="round" />
              <path d="M 280 28 Q 220 22 164 26" fill="none" stroke="#64748b" strokeWidth="3.5" strokeLinecap="round" />
              <text x="75" y="18" fill="#64748b" fontSize="8" fontFamily="monospace">CLAVICLE</text>

              {/* Left Pectoralis Major - Clavicular & Sternal Heads */}
              <path
                d="M 156 28 Q 110 32 60 48 Q 50 75 70 100 Q 110 128 156 120 Z"
                fill={anatomyView === 'heatmap' ? 'url(#pecFatigueGrad)' : '#1e293b'}
                stroke="#ef4444"
                strokeWidth="1.5"
              />
              {anatomyView === 'striations' && (
                <path
                  d="M 156 28 Q 110 32 60 48 Q 50 75 70 100 Q 110 128 156 120 Z"
                  fill="url(#striationPat)"
                  opacity="0.9"
                />
              )}

              {/* Right Pectoralis Major */}
              <path
                d="M 164 28 Q 210 32 260 48 Q 270 75 250 100 Q 210 128 164 120 Z"
                fill={anatomyView === 'heatmap' ? 'url(#pecFatigueGrad)' : '#1e293b'}
                stroke="#ef4444"
                strokeWidth="1.5"
              />
              {anatomyView === 'striations' && (
                <path
                  d="M 164 28 Q 210 32 260 48 Q 270 75 250 100 Q 210 128 164 120 Z"
                  fill="url(#striationPat)"
                  opacity="0.9"
                />
              )}

              {/* Humeral Insertion Tendon */}
              <circle cx="58" cy="50" r="4.5" fill="#f87171" stroke="#fff" strokeWidth="1" />
              <line x1="58" y1="50" x2="30" y2="70" stroke="#f87171" strokeWidth="1" strokeDasharray="2,2" />
              <text x="25" y="82" fill="#fca5a5" fontSize="8" fontFamily="monospace">HUMERAL INSERTION</text>

              {/* Acute Microtrauma Strain Callout */}
              {anatomyView === 'heatmap' && (
                <g>
                  <circle cx="118" cy="74" r="14" fill="#ef4444" opacity="0.35" className="animate-pulse" />
                  <circle cx="118" cy="74" r="5" fill="#f87171" />
                  <text x="118" y="100" fill="#fca5a5" fontSize="7.5" textAnchor="middle" fontFamily="monospace">
                    ACUTE INFLAMMATION: 15% RECOVERED
                  </text>
                </g>
              )}

              {anatomyView === 'innervation' && (
                <g>
                  <path d="M 156 40 Q 120 55 90 70" fill="none" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="3,3" />
                  <path d="M 164 40 Q 200 55 230 70" fill="none" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="3,3" />
                  <text x="160" y="148" fill="#fcd34d" fontSize="8" textAnchor="middle" fontFamily="monospace">
                    MEDIAL & LATERAL PECTORAL NERVES (C5-T1)
                  </text>
                </g>
              )}
            </svg>
          )}

          {isLats && (
            <svg viewBox="0 0 320 160" className="w-full h-full max-w-[280px]">
              <defs>
                <linearGradient id="latAmberGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#d97706" stopOpacity="0.75" />
                </linearGradient>
              </defs>

              {/* Vertebral Column T7-L5 */}
              <line x1="160" y1="15" x2="160" y2="145" stroke="#475569" strokeWidth="3" strokeDasharray="4,2" />
              <text x="160" y="12" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">VERTEBRAL COLUMN (T7-L5)</text>

              {/* Scapulae */}
              <polygon points="90,30 115,35 95,75" fill="#334155" stroke="#475569" strokeWidth="1" />
              <polygon points="230,30 205,35 225,75" fill="#334155" stroke="#475569" strokeWidth="1" />
              <text x="82" y="26" fill="#64748b" fontSize="8" fontFamily="monospace">SCAPULA</text>

              {/* Latissimus Dorsi Muscle Fans */}
              <path
                d="M 160 35 Q 110 50 65 25 Q 90 90 120 135 L 160 140 Z"
                fill="url(#latAmberGrad)"
                stroke="#f59e0b"
                strokeWidth="1.5"
              />
              <path
                d="M 160 35 Q 210 50 255 25 Q 230 90 200 135 L 160 140 Z"
                fill="url(#latAmberGrad)"
                stroke="#f59e0b"
                strokeWidth="1.5"
              />

              {/* Thoracolumbar Fascia Base */}
              <polygon points="140,140 180,140 160,110" fill="#38bdf8" opacity="0.4" stroke="#0284c7" strokeWidth="1" />
              <text x="160" y="152" fill="#38bdf8" fontSize="7.5" textAnchor="middle" fontFamily="monospace">
                THORACOLUMBAR FASCIA APEX
              </text>

              {/* Supercompensation Indicator */}
              <circle cx="210" cy="65" r="9" fill="#f59e0b" opacity="0.3" className="animate-ping" />
              <circle cx="210" cy="65" r="4" fill="#fbbf24" />
              <text x="220" y="68" fill="#fef3c7" fontSize="8" fontFamily="monospace">
                65% SUPERCOMPENSATION
              </text>
            </svg>
          )}

          {isQuads && (
            <svg viewBox="0 0 320 160" className="w-full h-full max-w-[280px]">
              <defs>
                <linearGradient id="quadGreenGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#059669" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Pelvis & AIIS Origin */}
              <path d="M 80 15 Q 160 10 240 15" fill="none" stroke="#475569" strokeWidth="4" />
              <text x="160" y="12" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">PELVIC GIRDLE (AIIS)</text>

              {/* Left Quad Group */}
              {/* Vastus Lateralis */}
              <path d="M 105 25 Q 85 70 105 125 Q 120 130 125 125 Q 120 70 115 25 Z" fill="#047857" stroke="#10b981" strokeWidth="1" />
              {/* Rectus Femoris (Center) */}
              <path d="M 120 20 Q 110 65 125 125 Q 135 125 140 65 Q 130 20 120 20 Z" fill="url(#quadGreenGrad)" stroke="#34d399" strokeWidth="1.5" />
              {/* Vastus Medialis (Teardrop) */}
              <path d="M 130 65 Q 150 95 138 125 Q 130 128 128 115 Z" fill="#10b981" stroke="#34d399" strokeWidth="1" />

              {/* Right Quad Group */}
              {/* Vastus Medialis */}
              <path d="M 190 65 Q 170 95 182 125 Q 190 128 192 115 Z" fill="#10b981" stroke="#34d399" strokeWidth="1" />
              {/* Rectus Femoris */}
              <path d="M 200 20 Q 210 65 195 125 Q 185 125 180 65 Q 190 20 200 20 Z" fill="url(#quadGreenGrad)" stroke="#34d399" strokeWidth="1.5" />
              {/* Vastus Lateralis */}
              <path d="M 215 25 Q 235 70 215 125 Q 200 130 195 125 Q 200 70 205 25 Z" fill="#047857" stroke="#10b981" strokeWidth="1" />

              {/* Patella & Tendon */}
              <circle cx="132" cy="133" r="5" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1" />
              <circle cx="188" cy="133" r="5" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1" />
              <rect x="130" y="138" width="4" height="14" fill="#64748b" />
              <rect x="186" y="138" width="4" height="14" fill="#64748b" />
              <text x="160" y="152" fill="#10b981" fontSize="8" textAnchor="middle" fontFamily="monospace">
                PATELLAR TENDON · 100% READY FOR MAX LOADING
              </text>
            </svg>
          )}

          {isCalves && (
            <svg viewBox="0 0 320 160" className="w-full h-full max-w-[280px]">
              <defs>
                <linearGradient id="calfRedGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#dc2626" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#991b1b" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Femoral Condyles */}
              <path d="M 100 20 Q 160 15 220 20" fill="none" stroke="#475569" strokeWidth="3" />
              <text x="160" y="14" fill="#64748b" fontSize="8" textAnchor="middle" fontFamily="monospace">
                FEMORAL CONDYLES ORIGIN
              </text>

              {/* Gastrocnemius Medial & Lateral Heads */}
              <path d="M 120 22 Q 100 55 125 90 Q 138 90 135 55 Z" fill="url(#calfRedGrad)" stroke="#ef4444" strokeWidth="1.2" />
              <path d="M 140 22 Q 160 55 135 90 Q 125 90 125 55 Z" fill="url(#calfRedGrad)" stroke="#ef4444" strokeWidth="1.2" />

              <path d="M 180 22 Q 160 55 185 90 Q 198 90 195 55 Z" fill="url(#calfRedGrad)" stroke="#ef4444" strokeWidth="1.2" />
              <path d="M 200 22 Q 220 55 195 90 Q 185 90 185 55 Z" fill="url(#calfRedGrad)" stroke="#ef4444" strokeWidth="1.2" />

              {/* Deep Soleus Bed */}
              <path d="M 115 50 Q 95 85 125 110 L 138 110 Q 155 85 145 50 Z" fill="#7f1d1d" opacity="0.6" />
              <path d="M 175 50 Q 155 85 185 110 L 198 110 Q 215 85 205 50 Z" fill="#7f1d1d" opacity="0.6" />

              {/* Achilles Tendon & Calcaneus */}
              <rect x="127" y="110" width="7" height="32" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1" />
              <rect x="187" y="110" width="7" height="32" fill="#f8fafc" stroke="#94a3b8" strokeWidth="1" />
              <circle cx="130" cy="146" r="4.5" fill="#64748b" />
              <circle cx="190" cy="146" r="4.5" fill="#64748b" />

              <text x="160" y="152" fill="#ef4444" fontSize="8" textAnchor="middle" fontFamily="monospace" fontWeight="bold">
                ACHILLES TENDON · 12 DAYS DELINQUENT · ATROPHY THRESHOLD
              </text>
            </svg>
          )}

          {isCNS && (
            <svg viewBox="0 0 320 160" className="w-full h-full max-w-[280px]">
              {/* Brainstem & Cerebellum */}
              <path d="M 148 15 Q 160 8 172 15 Q 178 30 160 38 Q 142 30 148 15 Z" fill="#3b82f6" stroke="#60a5fa" strokeWidth="1.5" />
              <text x="160" y="24" fill="#ffffff" fontSize="7" textAnchor="middle" fontFamily="monospace">MOTOR CORTEX</text>

              {/* Spinal Cord Tract */}
              <line x1="160" y1="38" x2="160" y2="135" stroke="#60a5fa" strokeWidth="4" />
              <line x1="160" y1="38" x2="160" y2="135" stroke="#93c5fd" strokeWidth="1.5" strokeDasharray="3,2" />

              {/* Spinal Nerve Pairs & Sympathetic Ganglia */}
              {[48, 62, 76, 90, 104, 118].map((y, idx) => (
                <g key={idx}>
                  <line x1="160" y1={y} x2="130" y2={y + 5} stroke="#38bdf8" strokeWidth="1.2" />
                  <circle cx="130" cy={y + 5} r="3" fill="#0284c7" />
                  <line x1="160" y1={y} x2="190" y2={y + 5} stroke="#38bdf8" strokeWidth="1.2" />
                  <circle cx="190" cy={y + 5} r="3" fill="#0284c7" />
                </g>
              ))}

              {/* Real-time ECG / HRV Waveform */}
              <path
                d="M 50 140 L 70 140 L 75 125 L 82 152 L 88 115 L 94 148 L 98 140 L 270 140"
                fill="none"
                stroke="#10b981"
                strokeWidth="1.5"
              />
              <text x="160" y="152" fill="#10b981" fontSize="8" textAnchor="middle" fontFamily="monospace">
                AUTONOMIC TONE · HRV rMSSD 68ms (94% PRIMED)
              </text>
            </svg>
          )}

        </div>

        {/* Biomechanical Telemetry & Direct Real Stimulate Control */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/80">
          <div className="flex items-center gap-2 text-[11px] font-mono text-slate-400">
            <span className="text-slate-300">Fiber:</span>
            <span className="text-blue-400">
              {isPecs ? '60% Type IIx / 40% Type I' : isLats ? '55% Type IIx / 45% Type I' : isQuads ? '50% Type IIx / 50% Type I' : isCalves ? '18% Type IIx / 82% Type I' : 'Neural Rate Coding 96%'}
            </span>
          </div>

          {/* Interactive Trigger Button */}
          {isPecs && (
            <button
              onClick={() => handleStimulate('chest-mid', 'Chest Incline Bench')}
              className="px-2.5 py-1 bg-red-600/30 hover:bg-red-600 border border-red-500/50 hover:border-red-400 text-red-200 hover:text-white rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <Flame className="w-3 h-3 text-red-400" />
              <span>Stimulate Set (+3 Sets)</span>
            </button>
          )}

          {isLats && (
            <button
              onClick={() => handleStimulate('back-lats', 'Lat Pulls')}
              className="px-2.5 py-1 bg-amber-600/30 hover:bg-amber-600 border border-amber-500/50 hover:border-amber-400 text-amber-200 hover:text-white rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <Zap className="w-3 h-3 text-amber-400" />
              <span>Stimulate Heavy Pull (+4 Sets)</span>
            </button>
          )}

          {isQuads && (
            <button
              onClick={() => handleStimulate('quads-rectus', 'Heavy Squat')}
              className="px-2.5 py-1 bg-emerald-600/30 hover:bg-emerald-600 border border-emerald-500/50 hover:border-emerald-400 text-emerald-200 hover:text-white rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Simulate 315 lb Squat Set</span>
            </button>
          )}

          {isCalves && (
            <button
              onClick={() => handleStimulate('calves-gastroc', 'Calf Raises')}
              className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 shadow-md shadow-red-600/30"
            >
              <AlertTriangle className="w-3 h-3 text-amber-300" />
              <span>Clear Delinquency (Log 4 Sets)</span>
            </button>
          )}

          {isCNS && (
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
              <HeartPulse className="w-3.5 h-3.5" />
              <span>Autonomic Ready for Max Neural Strain</span>
            </div>
          )}
        </div>

        {stimulatedSuccess && (
          <div className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2.5 py-1 rounded-md animate-fadeIn">
            {stimulatedSuccess}
          </div>
        )}

      </div>
    );
  }

  // -------------------------------------------------------------
  // 2. THE ASCENT: INTERACTIVE MONTE CARLO SIMULATION SANDBOX
  // -------------------------------------------------------------
  if (card.districtId === 'ascent') {
    // Dynamic trajectory calculations based on live sliders
    const bwFactor = bodyweight / 165;
    const freqFactor = 0.8 + (sessionsPerWeek / 4) * 0.2;
    const geneticFactor = geneticCeiling;

    const baseBench = Math.round(185 * bwFactor * freqFactor);
    const projBench = Math.round(315 * bwFactor * freqFactor * geneticFactor);
    const baseSquat = Math.round(255 * bwFactor * freqFactor);
    const projSquat = Math.round(425 * bwFactor * freqFactor * geneticFactor);
    const baseDead = Math.round(335 * bwFactor * freqFactor);
    const projDead = Math.round(540 * bwFactor * freqFactor * geneticFactor);
    const projTotal = projBench + projSquat + projDead;

    return (
      <div className="w-full flex flex-col gap-1.5 bg-slate-950/90 border border-slate-800/90 rounded-xl p-2">
        <div className="flex items-center justify-between border-b border-slate-800/70 pb-1">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-blue-400">
            <TrendingUp className="w-3 h-3" />
            <span className="font-mono uppercase tracking-wider text-[10px]">
              5-Year Trajectory
            </span>
          </div>
          <span className="text-[10px] font-mono text-slate-300">
            Yr 5 Total: <strong className="text-white font-bold">{projTotal} lbs</strong>
          </span>
        </div>

        {/* Live SVG Area Curve */}
        <div className="relative w-full h-20 bg-slate-900/80 rounded-lg p-1.5 overflow-hidden border border-slate-800/80">
          <svg viewBox="0 0 300 80" className="w-full h-full">
            <defs>
              <linearGradient id="ascentGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
              </linearGradient>
            </defs>
            {/* Grid Lines */}
            <line x1="0" y1="20" x2="300" y2="20" stroke="#1e293b" strokeDasharray="3,3" />
            <line x1="0" y1="45" x2="300" y2="45" stroke="#1e293b" strokeDasharray="3,3" />
            <line x1="0" y1="70" x2="300" y2="70" stroke="#1e293b" strokeDasharray="3,3" />

            {/* Area Fill */}
            <path
              d={`M 15 70 Q 100 ${70 - (baseSquat / 450) * 40} 285 ${75 - (projTotal / 1400) * 65} L 285 75 L 15 75 Z`}
              fill="url(#ascentGrad)"
            />

            {/* Projection Stroke */}
            <path
              d={`M 15 70 Q 100 ${70 - (baseSquat / 450) * 40} 285 ${75 - (projTotal / 1400) * 65}`}
              fill="none"
              stroke="#60a5fa"
              strokeWidth="2.5"
            />

            {/* Start Marker */}
            <circle cx="15" cy="70" r="3.5" fill="#3b82f6" stroke="#fff" strokeWidth="1" />
            <text x="18" y="62" fill="#94a3b8" fontSize="7.5" fontFamily="monospace">Day 0: 775 lb</text>

            {/* Target 5-Year Apex */}
            <circle cx="285" cy={75 - (projTotal / 1400) * 65} r="4.5" fill="#f59e0b" stroke="#fff" strokeWidth="1" />
            <text x="282" y={62 - (projTotal / 1400) * 65} fill="#fbbf24" fontSize="8" textAnchor="end" fontFamily="monospace" fontWeight="bold">
              Yr 5: {projTotal} lb
            </text>
          </svg>
        </div>

        {/* Live Interactive Sliders directly on the card */}
        <div className="grid grid-cols-3 gap-1.5 pt-0.5 border-t border-slate-800/80 text-[9px] font-mono">
          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>BW</span>
              <span className="text-white font-bold">{bodyweight}lb</span>
            </div>
            <input
              type="range"
              min="135"
              max="225"
              step="5"
              value={bodyweight}
              onChange={(e) => setBodyweight(Number(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded accent-blue-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>Freq</span>
              <span className="text-white font-bold">{sessionsPerWeek}x</span>
            </div>
            <input
              type="range"
              min="2"
              max="6"
              step="1"
              value={sessionsPerWeek}
              onChange={(e) => setSessionsPerWeek(Number(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded accent-blue-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-0.5">
              <span>Ceiling</span>
              <span className="text-white font-bold">{geneticCeiling.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.95"
              max="1.25"
              step="0.05"
              value={geneticCeiling}
              onChange={(e) => setGeneticCeiling(Number(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded accent-blue-500 cursor-pointer"
            />
          </div>
        </div>

      </div>
    );
  }

  // -------------------------------------------------------------
  // 3. STRENGTH RIVER: INTERACTIVE VOLUMETRIC STREAM
  // -------------------------------------------------------------
  if (card.districtId === 'river') {
    const weeklyVolume = 12000 + selectedWeek * 480;
    const cumulativeTonnage = Math.round((selectedWeek / 26) * 425000);

    return (
      <div className="w-full flex flex-col gap-1.5 bg-slate-950/90 border border-slate-800/90 rounded-xl p-2">
        <div className="flex items-center justify-between border-b border-slate-800/70 pb-1">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-cyan-400">
            <Waves className="w-3 h-3" />
            <span className="font-mono uppercase tracking-wider text-[10px]">
              Tonnage · Wk {selectedWeek}/26
            </span>
          </div>
          <span className="text-[10px] font-mono text-cyan-300">
            Total: <strong className="text-white">{cumulativeTonnage.toLocaleString()} lbs</strong>
          </span>
        </div>

        {/* 26-Week SVG Stream */}
        <div className="relative w-full h-16 bg-slate-900/80 rounded-lg p-1 overflow-hidden border border-slate-800/80">
          <svg viewBox="0 0 260 70" className="w-full h-full">
            <defs>
              <linearGradient id="riverGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#0891b2" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.9" />
              </linearGradient>
            </defs>

            {/* Dynamic Volume Bars */}
            {Array.from({ length: 26 }).map((_, i) => {
              const weekNum = i + 1;
              const h = 15 + Math.sin(i * 0.4) * 8 + i * 1.5;
              const isSelected = weekNum === selectedWeek;
              return (
                <rect
                  key={i}
                  x={i * 10 + 2}
                  y={65 - h}
                  width="6.5"
                  height={h}
                  rx="1"
                  fill={isSelected ? '#38bdf8' : i < selectedWeek ? '#0891b2' : '#1e293b'}
                  className="transition-colors cursor-pointer hover:fill-cyan-300"
                  onClick={() => setSelectedWeek(weekNum)}
                />
              );
            })}
          </svg>
        </div>

        {/* Week Scrubber */}
        <div className="flex items-center gap-2 text-[9px] font-mono text-slate-400">
          <span>Scrub:</span>
          <input
            type="range"
            min="1"
            max="26"
            value={selectedWeek}
            onChange={(e) => setSelectedWeek(Number(e.target.value))}
            className="flex-1 h-1 bg-slate-800 rounded accent-cyan-400 cursor-pointer"
          />
          <span className="text-white font-bold min-w-[45px] text-right">
            {weeklyVolume.toLocaleString()}lb
          </span>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // 4. THE CONSTELLATION: INTERACTIVE GALACTIC WORKOUT STAR CLUSTER
  // -------------------------------------------------------------
  if (card.districtId === 'constellation') {
    return (
      <div className="w-full flex flex-col gap-1.5 bg-slate-950/90 border border-slate-800/90 rounded-xl p-2">
        <div className="flex items-center justify-between border-b border-slate-800/70 pb-1">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-purple-400">
            <Sparkles className="w-3 h-3" />
            <span className="font-mono uppercase tracking-wider text-[10px]">
              87-Star Galaxy
            </span>
          </div>

          {/* Cluster filter tabs */}
          <div className="flex items-center gap-0.5 text-[9px] font-medium bg-slate-900 border border-slate-800 p-0.5 rounded-lg">
            {(['all', 'push', 'pull', 'legs', 'longevity'] as const).map((cluster) => (
              <button
                key={cluster}
                onClick={() => setActiveCluster(cluster)}
                className={`px-1 py-0.5 rounded uppercase font-mono transition-colors cursor-pointer ${
                  activeCluster === cluster ? 'bg-purple-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                {cluster}
              </button>
            ))}
          </div>
        </div>

        {/* Star Map SVG Galaxy Canvas */}
        <div className="relative w-full h-18 bg-slate-950 rounded-lg p-1 overflow-hidden border border-slate-800/80 flex items-center justify-center">
          <svg viewBox="0 0 300 90" className="w-full h-full">
            {/* Background Galactic Dust */}
            <circle cx="150" cy="45" r="40" fill="#a855f7" opacity="0.08" filter="blur(8px)" />

            {/* 87 Stars plotted in orbital clusters */}
            {Array.from({ length: 65 }).map((_, i) => {
              const clusterType = i % 4 === 0 ? 'push' : i % 4 === 1 ? 'pull' : i % 4 === 2 ? 'legs' : 'longevity';
              const match = activeCluster === 'all' || activeCluster === clusterType;
              const angle = (i / 65) * Math.PI * 2;
              const r = 25 + Math.sin(i * 3) * 18;
              const cx = 150 + Math.cos(angle) * r * 2.2;
              const cy = 45 + Math.sin(angle) * r * 0.9;
              const color =
                clusterType === 'push'
                  ? '#f87171'
                  : clusterType === 'pull'
                  ? '#60a5fa'
                  : clusterType === 'legs'
                  ? '#34d399'
                  : '#c084fc';

              return (
                <circle
                  key={i}
                  cx={cx}
                  cy={cy}
                  r={i === 64 ? 4 : match ? 2.5 : 1}
                  fill={color}
                  opacity={match ? 0.9 : 0.2}
                  className={i === 64 ? 'animate-pulse' : ''}
                />
              );
            })}

            {/* Special Highlight: The Shooting Star (Tomorrow's prescription) */}
            <circle cx="260" cy="30" r="5" fill="#facc15" stroke="#ffffff" strokeWidth="1.5" className="animate-ping" />
            <circle cx="260" cy="30" r="4" fill="#facc15" />
            <text x="250" y="20" fill="#fde047" fontSize="7.5" textAnchor="end" fontFamily="monospace">
              SHOOTING STAR: TOMORROW'S PULL RX
            </text>
          </svg>
        </div>

        <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-0.5">
          <span>87 Workouts Star Logged</span>
          <span className="text-purple-300">Push: 30 · Pull: 26 · Legs: 22 · Mobility: 9</span>
        </div>
      </div>
    );
  }

  return null;
};
