import React from 'react';
import { DistrictId } from '../types';
import { Flame, Plus, Dumbbell, Box, LayoutGrid, ChevronUp } from 'lucide-react';

interface NavbarProps {
  activeTab: DistrictId;
  onSelectTab: (tab: DistrictId) => void;
  streakDays: number;
  onOpenLogger: () => void;
  viewMode: '3d' | 'studio';
  onToggleViewMode: (mode: '3d' | 'studio') => void;
  isHeaderCollapsed?: boolean;
  onToggleHeaderCollapsed?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  streakDays,
  onOpenLogger,
  viewMode,
  onToggleViewMode,
  isHeaderCollapsed,
  onToggleHeaderCollapsed,
}) => {
  const navItems: { id: DistrictId; label: string }[] = [
    { id: 'ascent', label: 'The Ascent' },
    { id: 'bodymap', label: 'Body Map' },
    { id: 'river', label: 'Strength River' },
    { id: 'constellation', label: 'Constellation' },
  ];

  if (viewMode === '3d' && isHeaderCollapsed) {
    return (
      <div className="absolute top-1.5 left-1/2 -translate-x-1/2 z-50 pointer-events-auto">
        <button
          onClick={onToggleHeaderCollapsed}
          className="flex items-center gap-1.5 px-2.5 py-0.5 text-[10px] font-medium text-slate-400 hover:text-white bg-slate-950/80 hover:bg-slate-900 border border-slate-800 rounded-full shadow-lg backdrop-blur-md transition-all cursor-pointer"
          title="Show Navigation Header"
        >
          <Dumbbell className="w-3 h-3 text-blue-400" />
          <span>Show Nav</span>
        </button>
      </div>
    );
  }

  return (
    <header className={`sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 ${
      viewMode === '3d' ? 'h-9' : 'h-10'
    }`}>
      <div className="max-w-7xl mx-auto h-full px-2.5 sm:px-4 flex items-center justify-between gap-2">
        
        {/* Left: Brand title & logo */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelectTab('ascent')}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-bold tracking-tight text-white font-display hover:text-blue-400 transition-colors cursor-pointer"
          >
            <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center text-white shadow-xs">
              <Dumbbell className="w-3 h-3" />
            </div>
            <span>PeakForm</span>
          </button>
        </div>

        {/* Center: Mode switcher */}
        <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded-md">
          <button
            onClick={() => onToggleViewMode('3d')}
            className={`flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium rounded transition-all cursor-pointer ${
              viewMode === '3d'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Box className="w-3 h-3" />
            <span>3D Spatial</span>
          </button>
          <button
            onClick={() => onToggleViewMode('studio')}
            className={`flex items-center gap-1 px-2 py-0.5 text-[11px] font-medium rounded transition-all cursor-pointer ${
              viewMode === 'studio'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <LayoutGrid className="w-3 h-3" />
            <span>Studio</span>
          </button>
        </div>

        {/* In Studio mode: Navigation links */}
        {viewMode === 'studio' && (
          <nav className="hidden md:flex items-center gap-4 text-xs font-medium">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`transition-colors whitespace-nowrap cursor-pointer py-0.5 relative ${
                    isActive
                      ? 'text-blue-400 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-blue-500 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>
        )}

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Streak indicator */}
          <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[10px] sm:text-[11px] font-semibold tabular-nums">
            <Flame className="w-3 h-3 fill-amber-500 text-amber-500" />
            <span>{streakDays}d</span>
          </div>

          {/* Athlete pill (unboxed metadata style) */}
          <div className="hidden lg:flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="text-slate-300 font-medium">Alex</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>165 lbs</span>
          </div>

          {/* Primary CTA: Log Workout */}
          <button
            onClick={onOpenLogger}
            className="flex items-center gap-1 px-2.5 py-0.5 sm:py-1 text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded shadow-xs transition-colors whitespace-nowrap cursor-pointer"
          >
            <Plus className="w-3 h-3" />
            <span>Log</span>
          </button>

          {/* 3D Mode: Collapse header button */}
          {viewMode === '3d' && onToggleHeaderCollapsed && (
            <button
              onClick={onToggleHeaderCollapsed}
              className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-850 rounded transition-colors cursor-pointer"
              title="Collapse Header (Maximize 3D Viewport)"
            >
              <ChevronUp className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>

      {/* Mobile nav row - only shown in 2D Studio mode */}
      {viewMode === 'studio' && (
        <div className="md:hidden flex items-center justify-around border-t border-slate-800/80 px-2 py-1 text-[11px] font-medium bg-slate-950/90">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`px-2 py-0.5 rounded transition-colors ${
                activeTab === item.id
                  ? 'text-blue-400 font-bold bg-blue-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
};
