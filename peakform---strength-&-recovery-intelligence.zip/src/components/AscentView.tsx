import React, { useState, useMemo } from 'react';
import { BuildingCard } from '../types';
import { TrendingUp, Award, Activity, Compass, ChevronRight, Sliders, Info, Zap, Box } from 'lucide-react';
import { ThreeDistrictWidget } from './ThreeDistrictWidget';

interface AscentViewProps {
  cards: BuildingCard[];
  onSelectCard: (card: BuildingCard) => void;
}

export const AscentView: React.FC<AscentViewProps> = ({ cards, onSelectCard }) => {
  const [show3dTelemetry, setShow3dTelemetry] = useState<boolean>(true);
  // Monte Carlo simulation sandbox controls
  const [bodyweight, setBodyweight] = useState<number>(165);
  const [cadenceDays, setCadenceDays] = useState<number>(4);
  const [geneticFactor, setGeneticFactor] = useState<number>(3.5); // e.g. 3.5x BW ceiling

  // Dynamic simulation projection calculation
  const simulation = useMemo(() => {
    const baseline = 385; // Mar 2026 baseline
    const ceiling = bodyweight * geneticFactor * 3; // total SBD ceiling
    
    // Yearly projections computed with logarithmic diminishing returns
    const rateMultiplier = (cadenceDays / 4) * (bodyweight / 165);
    
    const year1 = Math.round(baseline + (ceiling - baseline) * 0.32 * rateMultiplier);
    const year2 = Math.round(baseline + (ceiling - baseline) * 0.55 * rateMultiplier);
    const year3 = Math.round(baseline + (ceiling - baseline) * 0.72 * rateMultiplier);
    const year4 = Math.round(baseline + (ceiling - baseline) * 0.84 * rateMultiplier);
    const year5 = Math.round(baseline + (ceiling - baseline) * 0.92 * rateMultiplier);

    const p10_year5 = Math.round(year5 * 0.85);
    const p90_year5 = Math.round(year5 * 1.15);

    // Projected individual lifts at year 5 median
    const bench5 = Math.round(year5 * 0.28);
    const squat5 = Math.round(year5 * 0.35);
    const deadlift5 = Math.round(year5 * 0.37);

    return {
      baseline,
      ceiling: Math.round(ceiling),
      year1,
      year2,
      year3,
      year4,
      year5,
      p10_year5,
      p90_year5,
      bench5,
      squat5,
      deadlift5,
      gainTotal: year5 - baseline,
      gainMultiple: (year5 / baseline).toFixed(2)
    };
  }, [bodyweight, cadenceDays, geneticFactor]);

  // Points for chart rendering
  const years = [
    { label: 'Baseline', value: simulation.baseline, year: '2026' },
    { label: 'Year 1', value: simulation.year1, year: '2027' },
    { label: 'Year 2', value: simulation.year2, year: '2028' },
    { label: 'Year 3', value: simulation.year3, year: '2029' },
    { label: 'Year 4', value: simulation.year4, year: '2030' },
    { label: 'Year 5', value: simulation.year5, year: '2031' }
  ];

  const maxVal = Math.max(1450, simulation.p90_year5);
  const minVal = 300;

  const getY = (val: number) => {
    const range = maxVal - minVal;
    return 190 - ((val - minVal) / range) * 150;
  };

  const polylinePoints = years
    .map((y, idx) => `${40 + idx * 85},${getY(y.value)}`)
    .join(' ');

  return (
    <div className="space-y-10">
      
      {/* Editorial Header */}
      <div>
        <div className="flex items-center gap-2 text-xs text-blue-400 font-semibold mb-2">
          <span>THE ASCENT</span>
          <span aria-hidden="true">·</span>
          <span>5-YEAR STRENGTH TRAJECTORY</span>
          <span aria-hidden="true">·</span>
          <span>1,000 MONTE CARLO PATHS</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display text-balance">
          From First 1RM Baseline to Genetic Peak
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-400 max-w-3xl leading-relaxed">
          Tracking your SBD (Squat, Bench, Deadlift) progression through Bayesian Kalman updates. 
          Diminishing returns model your approach toward your natural genetic ceiling.
        </p>
      </div>

      {/* Primary Visualizer: Interactive Monte Carlo Projection Sandbox */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8">
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              <span>5-Year Monte Carlo Projection Engine</span>
            </div>
            <div className="text-3xl font-extrabold text-white mt-1 font-mono tabular-nums">
              {simulation.year5.toLocaleString()} lbs
              <span className="text-sm font-normal text-slate-400 ml-2">5-yr median total</span>
            </div>
            <div className="text-xs text-slate-400 mt-1">
              <span>Conservative P10: <strong className="text-slate-200 font-mono">{simulation.p10_year5.toLocaleString()} lbs</strong></span>
              <span className="mx-2">·</span>
              <span>Aggressive P90: <strong className="text-slate-200 font-mono">{simulation.p90_year5.toLocaleString()} lbs</strong></span>
            </div>
          </div>

          {/* Quick Projected Lifts at Year 5 */}
          <div className="grid grid-cols-3 gap-3 bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
            <div className="text-center px-2">
              <div className="text-xs text-slate-400">Bench</div>
              <div className="text-lg font-bold text-white font-mono tabular-nums">{simulation.bench5} lbs</div>
              <div className="text-[10px] text-blue-400">{(simulation.bench5 / bodyweight).toFixed(2)}x BW</div>
            </div>
            <div className="text-center px-2 border-x border-slate-800/80">
              <div className="text-xs text-slate-400">Squat</div>
              <div className="text-lg font-bold text-white font-mono tabular-nums">{simulation.squat5} lbs</div>
              <div className="text-[10px] text-emerald-400">{(simulation.squat5 / bodyweight).toFixed(2)}x BW</div>
            </div>
            <div className="text-center px-2">
              <div className="text-xs text-slate-400">Deadlift</div>
              <div className="text-lg font-bold text-white font-mono tabular-nums">{simulation.deadlift5} lbs</div>
              <div className="text-[10px] text-purple-400">{(simulation.deadlift5 / bodyweight).toFixed(2)}x BW</div>
            </div>
          </div>
        </div>

        {/* 3D Telemetry Toggle & Visualizer */}
        <div className="pt-4 pb-2 flex items-center justify-between border-b border-slate-800/80">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Box className="w-4 h-4 text-blue-400" />
            <span>3D Stepped Mountain Ridge Telemetry</span>
          </div>
          <button
            onClick={() => setShow3dTelemetry(!show3dTelemetry)}
            className="text-xs text-blue-400 hover:text-blue-300 font-medium cursor-pointer"
          >
            {show3dTelemetry ? 'Hide 3D Ridge' : 'Show 3D Ridge'}
          </button>
        </div>

        {show3dTelemetry && (
          <div className="pt-3 pb-2">
            <ThreeDistrictWidget districtId="ascent" heightPx={220} />
          </div>
        )}

        {/* Chart Viewport */}
        <div className="pt-6 pb-2">
          <div className="relative w-full overflow-x-auto">
            <svg viewBox="0 0 500 220" className="w-full h-56 sm:h-64 overflow-visible">
              <defs>
                <linearGradient id="curveGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#3b82f6" />
                  <stop offset="50%" stopColor="#6366f1" />
                  <stop offset="100%" stopColor="#8b5cf6" />
                </linearGradient>
                <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              {[400, 600, 800, 1000, 1200].map((v) => (
                <g key={v}>
                  <line
                    x1="30"
                    y1={getY(v)}
                    x2="480"
                    y2={getY(v)}
                    stroke="#1e293b"
                    strokeDasharray="3 3"
                  />
                  <text x="5" y={getY(v) + 3} fill="#64748b" fontSize="8" fontFamily="JetBrains Mono">
                    {v}
                  </text>
                </g>
              ))}

              {/* Shaded Area */}
              <polygon
                points={`40,${getY(years[0].value)} ${polylinePoints} ${40 + 5 * 85},200 40,200`}
                fill="url(#areaGradient)"
              />

              {/* Trajectory Polyline */}
              <polyline
                fill="none"
                stroke="url(#curveGradient)"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={polylinePoints}
              />

              {/* Data points */}
              {years.map((y, idx) => {
                const cx = 40 + idx * 85;
                const cy = getY(y.value);
                return (
                  <g key={y.label} className="cursor-pointer group">
                    <circle
                      cx={cx}
                      cy={cy}
                      r="5.5"
                      fill="#0f172a"
                      stroke="#3b82f6"
                      strokeWidth="2.5"
                      className="group-hover:r-7 transition-all"
                    />
                    <text
                      x={cx}
                      y={cy - 12}
                      textAnchor="middle"
                      fill="#e2e8f0"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="JetBrains Mono"
                    >
                      {y.value}
                    </text>
                    <text
                      x={cx}
                      y="212"
                      textAnchor="middle"
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="Plus Jakarta Sans"
                    >
                      {y.label}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Interactive Controls Bar */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Control 1: Bodyweight */}
          <div>
            <div className="flex justify-between text-xs text-slate-300 font-medium mb-1.5">
              <span>Athlete Bodyweight</span>
              <span className="font-mono text-blue-400 font-bold tabular-nums">{bodyweight} lbs</span>
            </div>
            <input
              type="range"
              min="130"
              max="240"
              step="1"
              value={bodyweight}
              onChange={(e) => setBodyweight(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>130 lbs</span>
              <span>240 lbs</span>
            </div>
          </div>

          {/* Control 2: Cadence */}
          <div>
            <div className="flex justify-between text-xs text-slate-300 font-medium mb-1.5">
              <span>Training Frequency</span>
              <span className="font-mono text-blue-400 font-bold tabular-nums">{cadenceDays} sessions / wk</span>
            </div>
            <input
              type="range"
              min="2"
              max="6"
              step="1"
              value={cadenceDays}
              onChange={(e) => setCadenceDays(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>2 days (Recovery)</span>
              <span>6 days (Volume)</span>
            </div>
          </div>

          {/* Control 3: Genetic Potential Ceiling */}
          <div>
            <div className="flex justify-between text-xs text-slate-300 font-medium mb-1.5">
              <span>Genetic Ceiling Factor</span>
              <span className="font-mono text-blue-400 font-bold tabular-nums">{geneticFactor}x BW</span>
            </div>
            <input
              type="range"
              min="2.8"
              max="4.0"
              step="0.1"
              value={geneticFactor}
              onChange={(e) => setGeneticFactor(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>2.8x (Natural Average)</span>
              <span>4.0x (Elite Phenotype)</span>
            </div>
          </div>
        </div>

      </div>

      {/* Ascent Milestones Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight font-display">
              Chronological Ascent Milestones
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Seven validated data points that calibrate your Kalman growth trajectory.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card, idx) => (
            <div
              key={card.id}
              onClick={() => onSelectCard(card)}
              className="group bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-xl p-5 transition-all duration-200 flex flex-col justify-between cursor-pointer hover:shadow-lg hover:shadow-blue-500/5"
            >
              <div>
                {/* Milestone Pill & Char */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-blue-400 tracking-wide uppercase">
                    {card.tag}
                  </span>
                  <span className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-xs font-mono font-bold text-slate-300">
                    {card.iconChar}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-blue-300 transition-colors font-display">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 mb-4 line-clamp-1">
                  {card.subtitle}
                </p>

                {/* Stat Grid */}
                <div className="grid grid-cols-3 gap-2 mb-4 bg-slate-950/60 border border-slate-800/80 rounded-lg p-2.5">
                  {card.stats.slice(0, 3).map((st, sIdx) => (
                    <div key={sIdx} className="text-center">
                      <div className="text-sm font-bold text-white font-mono tabular-nums">
                        {st.v}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-0.5 truncate">
                        {st.l}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Insight Teaser */}
                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {card.insight}
                </p>
              </div>

              {/* Card Footer Action */}
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-blue-400 font-semibold group-hover:text-blue-300">
                <span>View Full Analysis</span>
                <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
