import React, { useState } from 'react';
import { BuildingCard, WorkoutSession } from '../types';
import { CONSTELLATION_STARS } from '../data/mockData';
import { Sparkles, Calendar, Search, ChevronRight, Zap, Star, ShieldAlert, Award, Box } from 'lucide-react';
import { ThreeDistrictWidget } from './ThreeDistrictWidget';

interface ConstellationViewProps {
  cards: BuildingCard[];
  workouts: WorkoutSession[];
  onSelectCard: (card: BuildingCard) => void;
  onSelectWorkout: (workout: WorkoutSession) => void;
}

export const ConstellationView: React.FC<ConstellationViewProps> = ({
  cards,
  workouts,
  onSelectCard,
  onSelectWorkout,
}) => {
  const [show3dGalaxy, setShow3dGalaxy] = useState<boolean>(true);
  const [selectedCluster, setSelectedCluster] = useState<'all' | 'push' | 'pull' | 'legs' | 'longevity'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [inspectedStar, setInspectedStar] = useState<any>(CONSTELLATION_STARS[0]);

  // Filtered stars
  const filteredStars = CONSTELLATION_STARS.filter((s) => {
    return selectedCluster === 'all' || s.split === selectedCluster;
  });

  // Filtered workouts for ledger table
  const filteredWorkouts = workouts.filter((wo) => {
    const matchesCluster = selectedCluster === 'all' || wo.split === selectedCluster;
    const matchesSearch =
      wo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.date.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.exercises.some((e) => e.name.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCluster && matchesSearch;
  });

  const getSplitColor = (split: string) => {
    switch (split) {
      case 'push':
        return '#ef4444';
      case 'pull':
        return '#6366f1';
      case 'legs':
        return '#10b981';
      default:
        return '#06b6d4';
    }
  };

  return (
    <div className="space-y-10">
      
      {/* Editorial Header */}
      <div>
        <div className="flex items-center gap-2 text-xs text-purple-400 font-semibold mb-2">
          <span>THE CONSTELLATION</span>
          <span aria-hidden="true">·</span>
          <span>87 WORKOUT STARS</span>
          <span aria-hidden="true">·</span>
          <span>PERMANENT TRAINING GALAXY</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-display text-balance">
          Every Rep Leaves a Star in Your Sky
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-400 max-w-3xl leading-relaxed">
          Brightness corresponds to recency; magnitude reflects session tonnage. 
          Clusters expose volume imbalances (Push: 142k lbs vs Pull: 118k lbs).
        </p>
      </div>

      {/* Main Galaxy Explorer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 sm:p-8">
        
        {/* Galaxy Control Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>Interactive Star Map</span>
            </div>
            <div className="text-2xl font-bold text-white mt-1">
              87 Historical Sessions
            </div>
          </div>

          {/* Cluster filter tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-lg overflow-x-auto">
            {[
              { id: 'all', label: 'All 87 Stars' },
              { id: 'push', label: 'Push (30)' },
              { id: 'pull', label: 'Pull (25)' },
              { id: 'legs', label: 'Legs (22)' },
              { id: 'longevity', label: 'Longevity (10)' }
            ].map((cl) => (
              <button
                key={cl.id}
                onClick={() => setSelectedCluster(cl.id as any)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCluster === cl.id
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {cl.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3D Galaxy Sphere Telemetry */}
        <div className="pt-4 pb-2 flex items-center justify-between border-b border-slate-800/80">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
            <Box className="w-4 h-4 text-purple-400" />
            <span>3D Interactive Galaxy Sphere</span>
          </div>
          <button
            onClick={() => setShow3dGalaxy(!show3dGalaxy)}
            className="text-xs text-purple-400 hover:text-purple-300 font-medium cursor-pointer"
          >
            {show3dGalaxy ? 'Hide 3D Galaxy' : 'Show 3D Galaxy'}
          </button>
        </div>

        {show3dGalaxy && (
          <div className="pt-3 pb-2">
            <ThreeDistrictWidget districtId="constellation" heightPx={220} />
          </div>
        )}

        {/* 2D Constellation Canvas / SVG Viewport */}
        <div className="relative w-full h-[340px] sm:h-[400px] bg-slate-950/80 border border-slate-800/80 rounded-xl my-6 overflow-hidden flex items-center justify-center">
          
          {/* Distant background stars */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-950/20 via-slate-950/60 to-slate-950" />

          {/* Galaxy Coordinate Space */}
          <svg viewBox="-180 -120 360 240" className="w-full h-full">
            {/* Cluster bounding halos */}
            <circle cx="-110" cy="-60" r="50" fill="none" stroke="#ef4444" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.3" />
            <text x="-110" y="-115" fill="#ef4444" fontSize="6" textAnchor="middle" fontFamily="JetBrains Mono">PUSH CLUSTER (142K LBS)</text>

            <circle cx="95" cy="-60" r="45" fill="none" stroke="#6366f1" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.3" />
            <text x="95" y="-110" fill="#6366f1" fontSize="6" textAnchor="middle" fontFamily="JetBrains Mono">PULL CLUSTER (118K LBS)</text>

            <circle cx="-30" cy="75" r="48" fill="none" stroke="#10b981" strokeWidth="0.8" strokeDasharray="3 3" opacity="0.3" />
            <text x="-30" y="130" fill="#10b981" fontSize="6" textAnchor="middle" fontFamily="JetBrains Mono">LEGS CLUSTER (126K LBS)</text>

            {/* Shooting Star trajectory line (Tomorrow's workout) */}
            <g className="cursor-pointer">
              <line x1="30" y1="-30" x2="70" y2="-10" stroke="#f59e0b" strokeWidth="1.8" strokeDasharray="4 2" />
              <circle cx="70" cy="-10" r="5" fill="#f59e0b" />
              <text x="70" y="-18" fill="#f59e0b" fontSize="6" textAnchor="middle" fontWeight="bold">SHOOTING STAR (TOMORROW)</text>
            </g>

            {/* Missing Star marker (July 4th) */}
            <g className="cursor-pointer">
              <circle cx="-10" cy="-10" r="4" fill="#0f172a" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="2 2" />
              <text x="-10" y="-16" fill="#f87171" fontSize="6" textAnchor="middle">JUL 04 (SKIPPED)</text>
            </g>

            {/* Plotted Stars */}
            {filteredStars.map((star) => {
              const isSelected = inspectedStar?.id === star.id;
              const color = getSplitColor(star.split);

              return (
                <g
                  key={star.id}
                  onClick={() => setInspectedStar(star)}
                  className="cursor-pointer group"
                >
                  {/* Subtle Glow */}
                  {isSelected && (
                    <circle
                      cx={star.x}
                      cy={star.y}
                      r={star.size * 1.8}
                      fill={color}
                      opacity={0.35}
                    />
                  )}
                  {/* Core Star */}
                  <circle
                    cx={star.x}
                    cy={star.y}
                    r={isSelected ? star.size * 1.3 : star.size * 0.7}
                    fill={color}
                    opacity={star.opacity}
                    stroke={isSelected ? '#ffffff' : color}
                    strokeWidth={isSelected ? 1.5 : 0}
                    className="transition-all"
                  />
                </g>
              );
            })}
          </svg>

          {/* Legend Overlay */}
          <div className="absolute bottom-3 left-3 bg-slate-900/90 backdrop-blur-sm border border-slate-800 rounded-lg p-2.5 text-[10px] text-slate-300 flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span>Push (30)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
              <span>Pull (25)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span>Legs (22)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
              <span>Longevity (10)</span>
            </div>
          </div>
        </div>

        {/* Selected Star Summary Card */}
        {inspectedStar && (
          <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-purple-400 uppercase tracking-wider">
                Workout #{inspectedStar.workoutNumber} · {inspectedStar.date}
              </div>
              <div className="text-lg font-bold text-white capitalize mt-0.5">
                {inspectedStar.split} Session
              </div>
            </div>

            <div className="flex items-center gap-6 text-xs font-mono">
              <div>
                <span className="text-slate-500">Volume: </span>
                <strong className="text-white">{inspectedStar.volume.toLocaleString()} lbs</strong>
              </div>
              <div>
                <span className="text-slate-500">Recency: </span>
                <strong className="text-slate-300">{inspectedStar.daysAgo} days ago</strong>
              </div>
              <div>
                <span className="text-slate-500">Brightness: </span>
                <strong className="text-purple-400">{(inspectedStar.opacity * 100).toFixed(0)}%</strong>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Constellation Milestones Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight font-display">
              Galaxy Architecture & Audit Flags
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Explore cluster balances, streak gap analyses, and automated progressive overload forecasts.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {cards.map((card) => (
            <div
              key={card.id}
              onClick={() => onSelectCard(card)}
              className="group bg-slate-900 border border-slate-800 hover:border-purple-500/50 rounded-xl p-5 transition-all duration-200 flex flex-col justify-between cursor-pointer hover:shadow-lg hover:shadow-purple-500/5"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold text-purple-400 tracking-wide uppercase">
                    {card.tag}
                  </span>
                  <span className="w-6 h-6 rounded bg-slate-800 flex items-center justify-center text-xs font-mono font-bold text-slate-300">
                    {card.iconChar}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors font-display">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1 mb-4 line-clamp-1">
                  {card.subtitle}
                </p>

                <div className="grid grid-cols-3 gap-2 mb-4 bg-slate-950/60 border border-slate-800/80 rounded-lg p-2.5">
                  {card.stats.slice(0, 3).map((st, sIdx) => (
                    <div key={sIdx} className="text-center">
                      <div className="text-sm font-bold text-white font-mono tabular-nums">
                        {st.v}
                      </div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-0.5 truncate">
                        {st.l}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                  {card.insight}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-purple-400 font-semibold group-hover:text-purple-300">
                <span>View Full Analysis</span>
                <ChevronRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Workout Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="text-lg font-bold text-white font-display">
              Training Session Ledger
            </h3>
            <p className="text-xs text-slate-400">
              Audit log of completed volume, duration, and exercise selections.
            </p>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              placeholder="Search exercise, date..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold">
                <th className="py-2.5 pr-4">Date</th>
                <th className="py-2.5 px-4">Workout Session</th>
                <th className="py-2.5 px-4">Split</th>
                <th className="py-2.5 px-4 text-right">Volume</th>
                <th className="py-2.5 px-4 text-right">Density</th>
                <th className="py-2.5 pl-4 text-right">RPE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredWorkouts.map((wo) => (
                <tr
                  key={wo.id}
                  onClick={() => onSelectWorkout(wo)}
                  className="hover:bg-slate-800/50 transition-colors cursor-pointer group"
                >
                  <td className="py-3 pr-4 text-slate-400 whitespace-nowrap">
                    {wo.date}
                  </td>
                  <td className="py-3 px-4 text-white font-medium font-sans">
                    <div className="flex items-center gap-2">
                      <span>{wo.name}</span>
                      {wo.prHit && (
                        <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded font-mono">
                          PR
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4 uppercase text-[10px] font-sans font-semibold">
                    <span
                      className="px-2 py-0.5 rounded"
                      style={{
                        backgroundColor: `${getSplitColor(wo.split)}22`,
                        color: getSplitColor(wo.split)
                      }}
                    >
                      {wo.split}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right text-white font-bold tabular-nums">
                    {wo.volumeLbs.toLocaleString()} lbs
                  </td>
                  <td className="py-3 px-4 text-right text-slate-300 tabular-nums">
                    {wo.workDensity} lbs/min
                  </td>
                  <td className="py-3 pl-4 text-right text-purple-400 font-bold tabular-nums">
                    {wo.rpeAvg.toFixed(1)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
