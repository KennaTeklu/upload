import { BuildingCard, District, Muscle, WorkoutSession } from '../types';

export const DISTRICTS_DATA: District[] = [
  {
    id: 'ascent',
    label: 'The Ascent',
    shortName: 'Ascent',
    icon: 'Mountain',
    accentColor: '#3b82f6',
    accentSoft: 'rgba(59, 130, 246, 0.12)',
    tagline: 'Five years from your first 1RM test to your projected genetic peak.',
    buildings: [
      {
        id: 'ascent-hero',
        districtId: 'ascent',
        title: 'Hero · The Ascent',
        tag: 'Milestone 1 of 7 · Peak Projection',
        tagColor: 'primary',
        iconChar: 'A',
        subtitle: 'Monte-Carlo SBD projection · 1,000 paths × 260 weeks',
        stats: [
          { v: '385', l: 'Baseline (lbs)' },
          { v: '1,180', l: '5-Yr Median (lbs)' },
          { v: '3.07x', l: 'Net Trajectory' }
        ],
        insight: 'A 3.07x gain over 5 years. The trajectory flattens near your genetic ceiling (3.5x bodyweight per lift). By 2031 you project in the top 5% of lifters in your weight class.',
        comparison: 'Bodyweight 165 lbs — your baseline of 385 lbs is 2.33x BW (intermediate tier per StrengthLevel standards).',
        modalText: 'Five years from your first 1RM test to your projected peak. The summit is your projected SBD total (Squat + Bench + Deadlift) if you maintain disciplined consistency: 1,180 lbs by 2031, computed from 1,000 Monte Carlo paths with diminishing returns near your genetic ceiling (3.5x bodyweight per lift).',
        formulaNote: 'P4.Projections.fiveYearMonteCarlo() · N=1,000 · Weekly dt=7d'
      },
      {
        id: 'ascent-basecamp',
        districtId: 'ascent',
        title: 'Base Camp',
        tag: 'Milestone 2 of 7 · First Testing',
        tagColor: 'primary',
        iconChar: 'B',
        subtitle: 'Mar 14, 2026 · First 1RM testing protocol',
        stats: [
          { v: '95', l: 'Bench (lbs)' },
          { v: '135', l: 'Squat (lbs)' },
          { v: '155', l: 'Deadlift (lbs)' },
          { v: '385', l: 'Total (lbs)' }
        ],
        insight: 'The algorithm caps reasonable 1RMs at 9x bodyweight total (1,485 lbs for you). Your starting 385 is well below the cap — plenty of runway.',
        comparison: 'Beginner tier starts at 1x BW total (165 lbs). You started at 2.33x BW — already intermediate foundation.',
        modalText: 'You started here. On March 14, 2026 you tested your first 1RM on the big three. Total: 385 lbs. This is the baseline every projection in the app extrapolates from — the Bayesian prior (ex.mu) starts here, and every set you log updates it via Kalman filter. The corridor narrows above you because fatigue is real, but so is momentum.',
        formulaNote: 'Initial Kalman state vector x_0 = [95, 135, 155]^T, Sigma_0 = diag([15, 20, 25])'
      },
      {
        id: 'ascent-pr1',
        districtId: 'ascent',
        title: 'First PR',
        tag: 'Milestone 3 of 7 · Neural Surge',
        tagColor: 'success',
        iconChar: '1',
        subtitle: 'Apr 02, 2026 · 19 days in · Neural adaptation',
        stats: [
          { v: '135', l: 'Bench (lbs)' },
          { v: '+42%', l: 'Delta from Base' },
          { v: '19', l: 'Days to PR' }
        ],
        insight: 'Beginner gains are predominantly motor unit recruitment — your central nervous system learning to fire muscle fibers synchronously. The app tracks your user.neuralPhaseEnd date and adjusts projections.',
        comparison: 'Average first-month bench gain for intermediate starters: +18%. You hit +42% — top decile acceleration.',
        modalText: 'Nineteen days in, your bench jumped from 95 to 135 lbs — a +42% gain in under three weeks. This is where linear progression kicks in. The Kalman filter (ex.mu) just received its first high-confidence update; your posterior variance shrunk significantly.',
        formulaNote: 'Posterior variance sigma^2 decreased by 64% following RPE 8.5 verification.'
      },
      {
        id: 'ascent-streak',
        districtId: 'ascent',
        title: '30-Day Streak',
        tag: 'Milestone 4 of 7 · Habit Anchor',
        tagColor: 'warning',
        iconChar: '30',
        subtitle: 'Apr 14, 2026 · 14 workouts · 0 missed cadences',
        stats: [
          { v: '30', l: 'Streak Days' },
          { v: '14', l: 'Completed' },
          { v: 'L1', l: 'Momentum Tier' }
        ],
        insight: 'Streaks compound: a 30-day streak doubles your 5-year projected total vs. the same volume spread sporadically. Skip within the 48h rest window and the streak survives; skip beyond it and the count resets.',
        comparison: 'Median user hits their first 30-day streak at Day 47. You locked it at Day 30 — top 15% consistency.',
        modalText: 'Thirty days in, your streak hit 14 workouts — every other day, zero missed sessions. The momentum index expands. The calculateStreak() function tracks consecutive sessions staying within your recommended 48-hour recovery window.',
        formulaNote: 'Consistency factor K_c = 1.22 applied to 5-year growth trajectory.'
      },
      {
        id: 'ascent-projection',
        districtId: 'ascent',
        title: '3-Month Projection',
        tag: 'Milestone 5 of 7 · Short Horizon',
        tagColor: 'warning',
        iconChar: '90',
        subtitle: 'P4.Projections.threeMonth() · ±1.5σ volatility band',
        stats: [
          { v: '405', l: '80% Lower (lbs)' },
          { v: '415', l: 'Median (lbs)' },
          { v: '425', l: '80% Upper (lbs)' }
        ],
        insight: 'Rate = (lastV - firstV) / daySpan. If rate > 0.5 lbs/day the engine marks progress as optimal. Plateau signals automatically trigger proactive deload prescriptions.',
        comparison: 'Current baseline 385 lbs — projected gain of +30 lbs in 90 days (+7.8%). Sustainable rate for an intermediate.',
        modalText: 'Ninety days out, the platform projects your SBD total between 405-425 lbs. The range reflects weekly recovery variance. The algorithm takes your last 8 workouts, fits a robust linear trend, and computes residual variance with ±1.5σ volatility bands.',
        formulaNote: 'Band formula: mu ± 1.5 * sqrt(MSE * (1 + 1/n + (x_target - x_bar)^2 / S_xx))'
      },
      {
        id: 'ascent-plateau',
        districtId: 'ascent',
        title: 'Plateau Break',
        tag: 'Milestone 6 of 7 · Breakthrough',
        tagColor: 'danger',
        iconChar: 'P',
        subtitle: 'Aug 2026 · 5 months in · Deload wave to PR',
        stats: [
          { v: '225', l: 'Plateau Squat (lbs)' },
          { v: '245', l: 'Breakthrough (lbs)' },
          { v: '+9%', l: 'Post-Deload Surge' },
          { v: '30', l: 'Days Stalled' }
        ],
        insight: 'Plateaus typically last 3-6 weeks. Yours was 30 days. The breakthrough arrived after a planned deload week that shifted volume into tempo and unilateral work.',
        comparison: 'Squat-to-bodyweight ratio: 245 / 165 = 1.48x BW. Top 25% of intermediate lifters at your size.',
        modalText: 'Five months in, your squat stalled at 225 lbs for four consecutive sessions — a 30-day plateau. Then it jumped to 245 lbs. Most lifters quit during stalls; here, the deload allowed connective tissue supercompensation and restored CNS drive.',
        formulaNote: 'Deload volume reduction: -40% intensity, +15% velocity, followed by 1RM test.'
      },
      {
        id: 'ascent-summit',
        districtId: 'ascent',
        title: 'The Summit',
        tag: 'Milestone 7 of 7 · 5-Yr Horizon',
        tagColor: 'primary',
        iconChar: '★',
        subtitle: '5-Year Monte Carlo · 1,000 paths · Genetic ceiling 3.5x BW',
        stats: [
          { v: '1,180', l: 'Median Total (lbs)' },
          { v: '920', l: 'Conservative P10' },
          { v: '1,420', l: 'Aggressive P90' }
        ],
        insight: 'Equivalent to lifting 3 Vespa scooters or 2/3 of a Smart Car across three movements. By 2031, you will project into competitive powerlifting qualifying totals.',
        comparison: 'Today: 425 lbs. By 2031: 1,180 lbs (+780 lbs net). Sustained pace of ~13 lbs/month with logarithmic taper.',
        modalText: 'Computed via 1,000 paths stepped weekly (7 days × 260 weeks). Past 90% of your genetic ceiling (3.5x bodyweight = 577.5 lbs per lift × 3 = 1,732 lbs total), gains taper by 70% per hill-equation dynamics. The median 1,180 sits securely within natural genetic potential.',
        formulaNote: 'Asymptotic ceiling model: dW/dt = k * (W_max - W) / W_max * consistencyFactor'
      }
    ]
  },
  {
    id: 'bodymap',
    label: 'Body Map & Recovery',
    shortName: 'Body Map',
    icon: 'Activity',
    accentColor: '#ef4444',
    accentSoft: 'rgba(239, 68, 68, 0.12)',
    tagline: '47 muscles tracked across 4 categories — real-time fatigue decay and supercompensation.',
    buildings: [
      {
        id: 'bm-today',
        districtId: 'bodymap',
        title: 'Today’s Body Map',
        tag: 'Recovery Core · State Overview',
        tagColor: 'danger',
        iconChar: 'B',
        subtitle: '47 muscles · 4 categories (Major, Longevity, Hands, Feet)',
        stats: [
          { v: '47', l: 'Muscles Tracked' },
          { v: '3', l: 'Trained Today' },
          { v: '78%', l: 'Systemic Recovery' }
        ],
        insight: 'Overall recovery = 0.7 × muscleAvg + 0.3 × systemicPercent. At 78%, you are in the "Good" tier (≥70) — optimal for high-intensity training.',
        comparison: 'Today: Push session, 9,480 lbs volume. Yesterday: Legs session, 8,200 lbs volume.',
        modalText: 'Navigate through your physiological recovery state. Crimson fibers were just loaded today. Amber fibers are undergoing protein synthesis. Emerald fibers have reached full supercompensation and are ready to hit again. Slate fibers indicate neglected muscle groups at risk of deconditioning.',
        formulaNote: 'R_sys = 100 - (sum(V_i * fatigueCoeff_i) / WorkCapacity_max) * 100'
      },
      {
        id: 'bm-training',
        districtId: 'bodymap',
        title: 'Today’s Training Load',
        tag: 'Push Session · Acute Fatigue',
        tagColor: 'danger',
        iconChar: 'T',
        subtitle: 'Chest / Front Delts / Triceps · 2h ago · 9,480 lbs',
        stats: [
          { v: '9,480', l: 'Session Tonnage (lbs)' },
          { v: '3', l: 'Muscles Fatigued' },
          { v: '47', l: 'Duration (min)' }
        ],
        insight: 'Red state indicates daysSinceTrained ≤ 1. MUSCLE_DECAY for chest: fast 0.12, slow 0.008 — fast-twitch fibers recover in ~36h, myotendinous junctions in 4-5 days.',
        comparison: 'Yesterday: Legs day, 8,200 lbs. Today: Push day, 9,480 lbs (+15.6%). Total volume escalating.',
        modalText: 'You completed your push workout 2 hours ago. Chest: 4x8 @ 185 lbs (5,920 lbs). Front Delts: 4x10 @ 35 lbs (1,400 lbs). Triceps: 3x12 @ 60 lbs (2,160 lbs). Total session volume: 9,480 lbs. These muscle groups are in acute fatigue; avoid heavy pressing for 48 hours.',
        formulaNote: 'Two-compartment exponential recovery model: F(t) = 0.7 * e^(-0.12*t) + 0.3 * e^(-0.008*t)'
      },
      {
        id: 'bm-ripple',
        districtId: 'bodymap',
        title: 'Recovery Ripple',
        tag: 'Pull Muscles · Growth Window',
        tagColor: 'warning',
        iconChar: 'R',
        subtitle: 'Latissimus Dorsi · 36h elapsed · 65% recovered',
        stats: [
          { v: '65%', l: 'Lats Recovery' },
          { v: '36', l: 'Hours Elapsed' },
          { v: '24', l: 'Hours to Peak' }
        ],
        insight: 'Recovery % = min(100, (daysSince / restDays) × 100). Systemic factor adjusts this downward slightly when antagonist muscles are acutely fatigued.',
        comparison: 'Biceps (trained 36h ago): 71% recovery. Biceps fast-twitch fibers recover quicker than the latissimus complex.',
        modalText: 'Your back is at 65% recovery — trained 36 hours ago. The amber glow signifies the active supercompensation phase. In 12-24 hours, glycogen repletion will be complete and motor unit excitability will peak. Tomorrow will be your ideal pull day.',
        formulaNote: 'Coupling matrix C(chest, lats) = 0.05 crosstalk fatigue penalty.'
      },
      {
        id: 'bm-ready',
        districtId: 'bodymap',
        title: 'Ready to Train',
        tag: 'Legs · Supercompensation Peak',
        tagColor: 'success',
        iconChar: 'G',
        subtitle: 'Quads · 4 days elapsed · 100% recovered',
        stats: [
          { v: '100%', l: 'Quads Ready' },
          { v: '4', l: 'Days Rested' },
          { v: '225', l: 'Last Working Set (lbs)' }
        ],
        insight: 'For quadriceps, prescribed restDays = 3. At 4 days rested, you are in the supercompensation window. Past Day 6 without stimulus, initial detraining signals emerge.',
        comparison: 'Glutes (trained 4d ago, restDays = 2): 100% ready. Lower chain is primed for maximum loading.',
        modalText: 'Your legs are 100% recovered — 4 full days since your last heavy leg day. The emerald status is your strongest adaptation signal. The recommendation engine prioritizes muscles at peak recovery.',
        formulaNote: 'Supercompensation window: t in [restDays, restDays * 1.6]'
      },
      {
        id: 'bm-neglected',
        districtId: 'bodymap',
        title: 'Neglected & Longevity',
        tag: 'Calves & Posture · Atrophy Alert',
        tagColor: 'danger',
        iconChar: 'N',
        subtitle: 'Calves (Gastrocnemius) · 12d elapsed · Delinquent',
        stats: [
          { v: '12', l: 'Days Since Trained' },
          { v: '3', l: 'Overdue Muscles' },
          { v: '4', l: 'Sets to Reset' }
        ],
        insight: 'The algorithm flags muscles where daysSince ≥ restDays × 1.5. Calves, forearms, and rear delts are currently overdue. Adding 4 sets today resets their decay timers.',
        comparison: 'This week: 4 muscle groups trained. Last week: 6. Planned tomorrow: 5 muscle groups.',
        modalText: 'Your calves have not been stimulated in 12 days. For calves, rest cadence is 48 hours — you are 6x past full recovery. Connective tissue stiffness and soleus endurance begin declining after 7 days of inactivity.',
        formulaNote: 'Overdue flag triggered when t_elapsed > 1.5 * t_cadence.'
      },
      {
        id: 'bm-cns',
        districtId: 'bodymap',
        title: 'Systemic CNS Reserve',
        tag: 'Autonomic Readiness · 94% Primed',
        tagColor: 'primary',
        iconChar: 'S',
        subtitle: 'HRV Coefficient: 68ms · Sympathetic Balance Balanced',
        stats: [
          { v: '94%', l: 'CNS Capacity' },
          { v: '68ms', l: 'rMSSD Baseline' },
          { v: '0.96', l: 'Neural Drive' }
        ],
        insight: 'Systemic neuromuscular readiness tracks whole-body fatigue across compound spinal-loaded sessions. High readiness allows 90%+ 1RM neurological recruitment.',
        comparison: 'Yesterday: 88% readiness. Baseline 30-day average: 82%. Neurological recovery is at its peak 94th percentile.',
        modalText: 'Your central nervous system has fully restored synaptic acetylcholine and motor unit rate coding efficiency after 48 hours of low-strain rest. Autonomic balance indicates optimal sympathovagal tone for high-intensity neural drive.',
        formulaNote: 'Readiness R_cns = exp(-tau_cns * t) * (1 - spinalLoadPenalty).'
      }
    ]
  },
  {
    id: 'river',
    label: 'Strength River',
    shortName: 'River',
    icon: 'Waves',
    accentColor: '#06b6d4',
    accentSoft: 'rgba(6, 182, 212, 0.12)',
    tagline: 'Every pound lifted is a drop in the river. Watch your work capacity compound over 26 weeks.',
    buildings: [
      {
        id: 'river-hero',
        districtId: 'river',
        title: 'Strength River',
        tag: 'Capacity Stream · 26-Week Flow',
        tagColor: 'info',
        iconChar: 'C',
        subtitle: 'calculateTotalVolume() · 87 workouts · 425,000 lbs',
        stats: [
          { v: '425,000', l: 'Lifetime Volume (lbs)' },
          { v: '87', l: 'Workouts Logged' },
          { v: '26', l: 'Weeks Trained' },
          { v: '32,000', l: 'Peak Week (lbs)' }
        ],
        insight: 'Total volume = sum(weight × sets × reps) across all exercises. Stored on each session. 7-day rolling volume is tracked to prevent overtraining spikes.',
        comparison: '425,000 lbs is equivalent to lifting 125 grand pianos (~3,400 lbs each) or 125 commercial refrigerators.',
        modalText: 'Every drop is a pound you have lifted. The river started as a trickle — your first workout moved 1,200 lbs in 28 minutes. As you progress downstream, watch the river widen as tributaries feed in: each session adds permanent work capacity to the stream.',
        formulaNote: 'V_cumulative = sum_{i=1}^N (sets_i * reps_i * weight_i)'
      },
      {
        id: 'river-source',
        districtId: 'river',
        title: 'The Source',
        tag: 'Week 1 · Initial Flow',
        tagColor: 'info',
        iconChar: 'S',
        subtitle: 'Mar 14, 2026 · First workout · 1,200 lbs',
        stats: [
          { v: '45', l: 'Bar Weight (lbs)' },
          { v: '1,200', l: 'Day 1 Volume (lbs)' },
          { v: '28', l: 'Session Minutes' }
        ],
        insight: 'Day 1 volume of 1,200 lbs was the trickle. Six months later, your average workout is 4,800 lbs — 4x wider. Work capacity compounds faster than 1RM strength.',
        comparison: 'Median first workout volume across all users: 950 lbs. You began above median with good barbell familiarity.',
        modalText: 'March 14, 2026. The headwaters. An empty Olympic barbell plus 25-lb plates. You benched 4x8 @ 65 lbs, squatted 3x10 @ 95 lbs, and did bicep curls. Total volume: 1,200 lbs in 28 minutes (density 43 lbs/min). Everything downstream originates here.',
        formulaNote: 'Initial density: D_0 = 1,200 / 28 = 42.8 lbs/min'
      },
      {
        id: 'river-trib1',
        districtId: 'river',
        title: 'First Tributary',
        tag: 'Week 3 · Density Expansion',
        tagColor: 'success',
        iconChar: '1',
        subtitle: 'Apr 02, 2026 · Day 19 · 5,800 lbs in 38 min',
        stats: [
          { v: '5,800', l: 'Session Volume (lbs)' },
          { v: '38', l: 'Session Minutes' },
          { v: '153', l: 'Density (lbs/min)' }
        ],
        insight: 'Work density (lbs/min) measures cardiovascular and muscular conditioning. 153 lbs/min marks a 3.5x increase in training density over 19 days.',
        comparison: 'Day 1 density: 43 lbs/min. By Session 19 you tripled your pacing without compromising bar speed.',
        modalText: 'April 2, 2026. Nineteen days in, the stream doubled in width. Bench PR day: 5x5 @ 135 lbs, followed by back-off sets of 8/8/6 @ 115 lbs. Total volume: 5,800 lbs in 38 minutes.',
        formulaNote: 'Density growth: Delta D = +257% in 19 days'
      },
      {
        id: 'river-rapid',
        districtId: 'river',
        title: 'The Rapid',
        tag: 'Week 10 · PR High Tide',
        tagColor: 'warning',
        iconChar: 'R',
        subtitle: 'May Wk 3, 2026 · PR Week · 32,000 lbs week',
        stats: [
          { v: '32,000', l: 'Peak Week Volume' },
          { v: '4', l: 'Workouts' },
          { v: '9,800', l: 'Subsequent Deload' }
        ],
        insight: 'Auto-deload triggers when systemic fatigue exceeds 70%. May Week 3 hit 78% systemic fatigue; the engine scheduled a proactive deload to prevent soft-tissue strain.',
        comparison: 'Prior week: 24,500 lbs. Peak week: 32,000 lbs (+30.6%). Following deload dropped to 9,800 lbs (-69%). Healthy wave mechanics.',
        modalText: 'May Week 3, 2026. White-water. This was your first PR testing week — every working set pushed to RPE 9-10. Four workouts accumulated 32,000 lbs. Two days later you deloaded to 9,800 lbs, allowing full physiological adaptation.',
        formulaNote: 'Acute-to-Chronic Workload Ratio (ACWR): 1.38 (optimal adaptation zone)'
      },
      {
        id: 'river-bigtrib',
        districtId: 'river',
        title: 'Big Tributary',
        tag: 'Week 13 · Squat Surge',
        tagColor: 'success',
        iconChar: 'B',
        subtitle: 'Jun 08, 2026 · Day 86 · 11,400 lbs session',
        stats: [
          { v: '11,400', l: 'Session Volume (lbs)' },
          { v: '52', l: 'Session Minutes' },
          { v: '225', l: 'Squat Working Weight' }
        ],
        insight: 'This single session generated your largest positive momentum bias update. Your squat Kalman mu jumped from 215 to 232 lbs.',
        comparison: 'This single session moved 9.5x your entire Day 1 volume in under an hour.',
        modalText: 'June 8, 2026. Squat volume day: 5 singles @ 225 lbs, 5x5 @ 205 lbs, 3x8 @ 185 lbs plus lunges and calf raises. Total tonnage: 11,400 lbs in 52 minutes.',
        formulaNote: 'Single session density record: 219.2 lbs/min'
      },
      {
        id: 'river-ocean',
        districtId: 'river',
        title: 'The Ocean',
        tag: '5-Year Horizon · Infinite Sea',
        tagColor: 'info',
        iconChar: '∞',
        subtitle: '5-Year cumulative projection · 260 weeks · 1.8M lbs',
        stats: [
          { v: '1.8M', l: 'Projected Volume (lbs)' },
          { v: '500', l: 'Equivalent Sedans' },
          { v: '7,200', l: 'Grand Pianos' }
        ],
        insight: '5-year volume assumes +3% volume progression per quarter with scheduled deload cycles. Missing a single week represents a 0.4% loss in lifetime volume.',
        comparison: 'Current: 425,000 lbs. 5-year: 1,800,000 lbs (+1,375,000 lbs to go). An average of 5,300 lbs/week sustained.',
        modalText: 'Where the river reaches the open sea. By 2031, you will have moved over 1.8 million pounds of iron. The ocean does not care about any individual off-day; it rewards the relentless habit of showing up week after week.',
        formulaNote: 'V_ocean = sum_{w=1}^{260} (W_baseline * (1 + 0.007)^w * waveModulator(w))'
      }
    ]
  },
  {
    id: 'constellation',
    label: 'Constellation',
    shortName: 'Constellation',
    icon: 'Sparkles',
    accentColor: '#8b5cf6',
    accentSoft: 'rgba(139, 92, 246, 0.12)',
    tagline: 'Every workout is an enduring star in your training sky. Brightness = recency, size = tonnage.',
    buildings: [
      {
        id: 'const-hero',
        districtId: 'constellation',
        title: 'Constellation',
        tag: 'Galaxy Overview · 87 Stars',
        tagColor: 'secondary',
        iconChar: 'D',
        subtitle: '87 workouts · 4 clusters · 425K lbs cluster mass',
        stats: [
          { v: '87', l: 'Total Stars' },
          { v: '4', l: 'Muscle Clusters' },
          { v: '425,000', l: 'Total Tonnage (lbs)' },
          { v: 'Today', l: 'Brightest Star' }
        ],
        insight: 'Star brightness decays via opacity = max(0.3, 1.0 - daysSince/180). Even your oldest workout preserves a 30% baseline brightness — every rep counts permanently.',
        comparison: 'Next milestone: 100 stars (13 workouts away, approximately 6.5 weeks at current cadence).',
        modalText: 'Every workout you have ever completed is a star in your sky. Color indicates training split: Crimson for Push, Indigo for Pull, Emerald for Legs, Amber for Longevity/Full Body. Tap any star to inspect its exact exercise logs.',
        formulaNote: 'Star radius: r = 3 + 4 * (volume / 12,000); Opacity: alpha = max(0.3, 1 - t_days / 180)'
      },
      {
        id: 'const-nearest',
        districtId: 'constellation',
        title: 'Nearest Star',
        tag: 'Today · Acute Radiance',
        tagColor: 'success',
        iconChar: '★',
        subtitle: 'Today · Push session · 9,480 lbs · Opacity 1.0',
        stats: [
          { v: '9,480', l: 'Volume (lbs)' },
          { v: '47', l: 'Duration (min)' },
          { v: '8', l: 'Working Sets' }
        ],
        insight: 'Today’s session is the brightest beacon in your galaxy. As days elapse it gently dims, allowing fresh achievements to take center stage.',
        comparison: 'Yesterday’s leg star moved 8,200 lbs. Today’s push star outshined it with 9,480 lbs.',
        modalText: 'Today’s push session. 47 minutes, 9,480 lbs of iron moved across bench press, overhead dumbbell press, and tricep pressdowns.',
        formulaNote: 'Radiance: 100% luminance, active bloom shader applied.'
      },
      {
        id: 'const-push',
        districtId: 'constellation',
        title: 'Push Cluster',
        tag: 'Cluster 1 · 30 Stars',
        tagColor: 'danger',
        iconChar: 'P',
        subtitle: 'Chest / Shoulders / Triceps · 142,000 lbs mass',
        stats: [
          { v: '30', l: 'Push Stars' },
          { v: '142,000', l: 'Mass (lbs)' },
          { v: '215', l: 'Bench 1RM mu' }
        ],
        insight: 'Push cluster is your heaviest aggregate cluster, outweighing the pull cluster by 20%. Consider adding pull volume to maintain shoulder health.',
        comparison: 'Pull cluster: 25 stars, 118,000 lbs. Gap: 24,000 lbs (equivalent to ~5 pull workouts).',
        modalText: 'A cluster of 30 red and amber stars in your upper quadrant. Chest 1RM Bayesian mu sits at 215 lbs, overhead press at 145 lbs.',
        formulaNote: 'Push-to-Pull volume ratio: 1.20 (optimal balance is 1.00 - 1.10)'
      },
      {
        id: 'const-pull',
        districtId: 'constellation',
        title: 'Pull Cluster',
        tag: 'Cluster 2 · 25 Stars',
        tagColor: 'secondary',
        iconChar: 'L',
        subtitle: 'Back / Biceps / Rear Delts · 118,000 lbs mass',
        stats: [
          { v: '25', l: 'Pull Stars' },
          { v: '118,000', l: 'Mass (lbs)' },
          { v: '155', l: 'Row 1RM tested' }
        ],
        insight: 'The algorithm checks your row-to-bench ratio (155 lbs vs 215 lbs = 0.72). Standard ratio target is 0.77. Adding 1 set of rows per pull day balances the ledger.',
        comparison: 'Row/Bench ratio is 6% under optimal balance. Easily rectified with targeted back work.',
        modalText: '25 indigo stars. Back and biceps volume totaling 118,000 lbs. Lat pulldowns, barbell rows, and hammer curls have built a dense foundation.',
        formulaNote: 'Auditor flag: Row_1RM / Bench_1RM = 0.72 (< 0.77 threshold)'
      },
      {
        id: 'const-missing',
        districtId: 'constellation',
        title: 'Missing Star',
        tag: 'July 4th · Gap Analysis',
        tagColor: 'danger',
        iconChar: '—',
        subtitle: 'Jul 04, 2026 · Streak reset from 89 days',
        stats: [
          { v: '1', l: 'Skipped Session' },
          { v: '89', l: 'Prior Streak (Days)' },
          { v: '8', l: 'Days Gap' }
        ],
        insight: 'The gap from June 30 to July 8 was 8 days, exceeding the 48-hour rest window. The streak reset, creating a void in the star map.',
        comparison: 'Without that single skip, your active streak would now exceed 118 days. The visual record preserves the honest truth.',
        modalText: 'July 4th, 2026. A planned workout that was missed during holiday travel. A dark marker sits where a star should have ignited. Consistency is built on acknowledging gaps and restarting immediately.',
        formulaNote: 'Gap delta t = 8 days > t_max_rest (2.0 days)'
      },
      {
        id: 'const-shooting',
        districtId: 'constellation',
        title: 'Shooting Star',
        tag: 'Tomorrow · Prescribed Path',
        tagColor: 'warning',
        iconChar: '☆',
        subtitle: 'Planned for Tomorrow · Pull Day · ~7,800 lbs',
        stats: [
          { v: '7,800', l: 'Forecasted (lbs)' },
          { v: '50', l: 'Est. Minutes' },
          { v: '8', l: 'Planned Exercises' }
        ],
        insight: 'Algorithmically tailored to your 100% recovered back and biceps. Completing this session will bridge the gap toward the 100-star milestone.',
        comparison: 'Last pull workout: 7,400 lbs. Tomorrow’s prescribed workout includes a +5.4% progressive overload target.',
        modalText: 'A glowing trajectory streaking across tomorrow’s sky. Based on your current recovery state (Lats 65% -> 95% by tomorrow, Biceps 100%), the system has queued a high-yield pull workout.',
        formulaNote: 'Prescription engine: Target = median(last_8_pull) * 1.054'
      }
    ]
  }
];

// 47 Muscles data model with realistic coordinates and states
export const MUSCLES_47: Muscle[] = [
  // Major Movers - Anterior
  {
    id: 'chest-pectoralis-major',
    name: 'Pectoralis Major (Chest)',
    scientificName: 'Pectoralis major',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 2,
    restCadenceHours: 48,
    recoveryPercentage: 15,
    status: 'fatigued',
    fastDecay: 0.12,
    slowDecay: 0.008,
    lastLoadLbs: 5920,
    recommendedExercises: ['Barbell Bench Press', 'Incline Dumbbell Press', 'Cable Flyes'],
    notes: 'Trained 2 hours ago. Fast-twitch fibers heavily depleted; micro-damage in sternal head.',
    coordinates: { x: 50, y: 28, view: 'anterior' }
  },
  {
    id: 'front-deltoids',
    name: 'Anterior Deltoids',
    scientificName: 'Deltoideus anterior',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 2,
    restCadenceHours: 48,
    recoveryPercentage: 18,
    status: 'fatigued',
    fastDecay: 0.11,
    slowDecay: 0.009,
    lastLoadLbs: 1400,
    recommendedExercises: ['Overhead Press', 'Dumbbell Front Raise', 'Arnold Press'],
    notes: 'Compound fatigue from bench press and overhead pressing.',
    coordinates: { x: 38, y: 24, view: 'anterior' }
  },
  {
    id: 'lateral-deltoids',
    name: 'Lateral Deltoids',
    scientificName: 'Deltoideus lateralis',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 2,
    restCadenceHours: 36,
    recoveryPercentage: 25,
    status: 'fatigued',
    fastDecay: 0.14,
    slowDecay: 0.010,
    lastLoadLbs: 840,
    recommendedExercises: ['Dumbbell Lateral Raise', 'Cable Y-Raise'],
    notes: 'High tolerance for volume; recovers in ~36 hours.',
    coordinates: { x: 34, y: 25, view: 'anterior' }
  },
  {
    id: 'biceps-brachii',
    name: 'Biceps Brachii',
    scientificName: 'Biceps brachii',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 36,
    restCadenceHours: 48,
    recoveryPercentage: 72,
    status: 'recovering',
    fastDecay: 0.13,
    slowDecay: 0.007,
    lastLoadLbs: 1950,
    recommendedExercises: ['Incline Dumbbell Curl', 'Barbell Preacher Curl'],
    notes: '72% recovered. Glycogen repletion ongoing; ready for light pull or heavy tomorrow.',
    coordinates: { x: 32, y: 35, view: 'anterior' }
  },
  {
    id: 'rectus-abdominis',
    name: 'Rectus Abdominis',
    scientificName: 'Rectus abdominis',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 24,
    restCadenceHours: 36,
    recoveryPercentage: 80,
    status: 'primed',
    fastDecay: 0.15,
    slowDecay: 0.012,
    lastLoadLbs: 1200,
    recommendedExercises: ['Hanging Leg Raise', 'Cable Crunch', 'Ab Wheel Rollout'],
    notes: 'High endurance capacity; fast recovery.',
    coordinates: { x: 50, y: 40, view: 'anterior' }
  },
  {
    id: 'external-obliques',
    name: 'External Obliques',
    scientificName: 'Obliquus externus abdominis',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 24,
    restCadenceHours: 36,
    recoveryPercentage: 82,
    status: 'primed',
    fastDecay: 0.14,
    slowDecay: 0.011,
    lastLoadLbs: 900,
    recommendedExercises: ['Paloff Press', 'Side Planks', 'Woodchoppers'],
    notes: 'Stabilizer integrity high.',
    coordinates: { x: 42, y: 42, view: 'anterior' }
  },
  {
    id: 'quadriceps-femoris',
    name: 'Quadriceps Femoris',
    scientificName: 'Quadriceps femoris (Rectus & Vasti)',
    category: 'major',
    view: 'anterior',
    hoursSinceTrained: 96,
    restCadenceHours: 72,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.09,
    slowDecay: 0.006,
    lastLoadLbs: 8200,
    recommendedExercises: ['Barbell Back Squat', 'Front Squat', 'Leg Press', 'Bulgarian Split Squat'],
    notes: '100% recovered! 4 days since heavy leg day. Peak supercompensation window.',
    coordinates: { x: 45, y: 62, view: 'anterior' }
  },
  {
    id: 'tibialis-anterior',
    name: 'Tibialis Anterior (Shin)',
    scientificName: 'Tibialis anterior',
    category: 'longevity',
    view: 'anterior',
    hoursSinceTrained: 96,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.14,
    slowDecay: 0.010,
    lastLoadLbs: 450,
    recommendedExercises: ['Tibialis Bar Raises', 'Kettlebell Toe Lifts'],
    notes: 'Essential for knee deceleration and deceleration mechanics.',
    coordinates: { x: 44, y: 82, view: 'anterior' }
  },

  // Major Movers - Posterior
  {
    id: 'latissimus-dorsi',
    name: 'Latissimus Dorsi (Lats)',
    scientificName: 'Latissimus dorsi',
    category: 'major',
    view: 'posterior',
    hoursSinceTrained: 36,
    restCadenceHours: 48,
    recoveryPercentage: 65,
    status: 'recovering',
    fastDecay: 0.10,
    slowDecay: 0.007,
    lastLoadLbs: 4800,
    recommendedExercises: ['Weighted Pull-Up', 'Barbell Row', 'Neutral Grip Lat Pulldown'],
    notes: '65% recovered. 36 hours elapsed since last back day. Ready tomorrow.',
    coordinates: { x: 50, y: 35, view: 'posterior' }
  },
  {
    id: 'trapezius-upper',
    name: 'Upper Trapezius',
    scientificName: 'Trapezius pars descendens',
    category: 'major',
    view: 'posterior',
    hoursSinceTrained: 36,
    restCadenceHours: 48,
    recoveryPercentage: 70,
    status: 'recovering',
    fastDecay: 0.12,
    slowDecay: 0.009,
    lastLoadLbs: 2200,
    recommendedExercises: ['Barbell Shrugs', 'Farmer Carries'],
    notes: 'Resilient postural muscle.',
    coordinates: { x: 50, y: 22, view: 'posterior' }
  },
  {
    id: 'rhomboids',
    name: 'Rhomboid Major & Minor',
    scientificName: 'Rhomboideus major/minor',
    category: 'longevity',
    view: 'posterior',
    hoursSinceTrained: 36,
    restCadenceHours: 48,
    recoveryPercentage: 68,
    status: 'recovering',
    fastDecay: 0.11,
    slowDecay: 0.008,
    lastLoadLbs: 1800,
    recommendedExercises: ['Face Pulls', 'Chest Supported Row', 'Prone Y-Lifts'],
    notes: 'Crucial for scapular retraction under heavy bench press loads.',
    coordinates: { x: 50, y: 28, view: 'posterior' }
  },
  {
    id: 'rear-deltoids',
    name: 'Posterior Deltoids',
    scientificName: 'Deltoideus posterior',
    category: 'major',
    view: 'posterior',
    hoursSinceTrained: 168,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'overdue',
    fastDecay: 0.13,
    slowDecay: 0.010,
    lastLoadLbs: 600,
    recommendedExercises: ['Reverse Pec Deck', 'Cable Face Pulls', 'Incline Dumbbell Rear Fly'],
    notes: 'Overdue! 7 days since isolated rear delt stimulus. High risk of anterior posture bias.',
    coordinates: { x: 36, y: 25, view: 'posterior' }
  },
  {
    id: 'triceps-brachii',
    name: 'Triceps Brachii',
    scientificName: 'Triceps brachii (Lateral, Long, Medial)',
    category: 'major',
    view: 'posterior',
    hoursSinceTrained: 2,
    restCadenceHours: 48,
    recoveryPercentage: 15,
    status: 'fatigued',
    fastDecay: 0.12,
    slowDecay: 0.008,
    lastLoadLbs: 2160,
    recommendedExercises: ['Overhead Cable Triceps Extension', 'Close-Grip Bench', 'Dips'],
    notes: 'Loaded heavily today during push session (3x12 @ 60 lbs).',
    coordinates: { x: 30, y: 35, view: 'posterior' }
  },
  {
    id: 'erector-spinae',
    name: 'Erector Spinae (Lower Back)',
    scientificName: 'Erector spinae (Iliocostalis, Longissimus)',
    category: 'longevity',
    view: 'posterior',
    hoursSinceTrained: 96,
    restCadenceHours: 72,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.08,
    slowDecay: 0.005,
    lastLoadLbs: 4500,
    recommendedExercises: ['Barbell Deadlift', 'Back Extensions', 'Good Mornings'],
    notes: 'Fully recovered and structural core is solid.',
    coordinates: { x: 50, y: 44, view: 'posterior' }
  },
  {
    id: 'gluteus-maximus',
    name: 'Gluteus Maximus',
    scientificName: 'Gluteus maximus',
    category: 'major',
    view: 'posterior',
    hoursSinceTrained: 96,
    restCadenceHours: 60,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.09,
    slowDecay: 0.006,
    lastLoadLbs: 6500,
    recommendedExercises: ['Barbell Hip Thrust', 'Romanian Deadlift', 'Low Bar Squat'],
    notes: 'Prime mover for hip extension. 100% ready.',
    coordinates: { x: 50, y: 52, view: 'posterior' }
  },
  {
    id: 'gluteus-medius',
    name: 'Gluteus Medius & Minimus',
    scientificName: 'Gluteus medius/minimus',
    category: 'longevity',
    view: 'posterior',
    hoursSinceTrained: 96,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.12,
    slowDecay: 0.009,
    lastLoadLbs: 1200,
    recommendedExercises: ['Cable Hip Abduction', 'Single-Leg RDL', 'Copenhagen Plank'],
    notes: 'Knee valgus prevention anchor.',
    coordinates: { x: 40, y: 50, view: 'posterior' }
  },
  {
    id: 'hamstrings',
    name: 'Hamstrings (Biceps Femoris, ST, SM)',
    scientificName: 'Hamstrings complex',
    category: 'major',
    view: 'posterior',
    hoursSinceTrained: 96,
    restCadenceHours: 72,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.09,
    slowDecay: 0.006,
    lastLoadLbs: 5200,
    recommendedExercises: ['Romanian Deadlift', 'Lying Leg Curl', 'Nordic Curls'],
    notes: 'Fully recovered. Supercompensation peak reached.',
    coordinates: { x: 45, y: 65, view: 'posterior' }
  },
  {
    id: 'gastrocnemius',
    name: 'Calves (Gastrocnemius & Soleus)',
    scientificName: 'Gastrocnemius / Soleus',
    category: 'feet',
    view: 'posterior',
    hoursSinceTrained: 288, // 12 days
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'overdue',
    fastDecay: 0.15,
    slowDecay: 0.012,
    lastLoadLbs: 800,
    recommendedExercises: ['Standing Calf Raise', 'Seated Calf Raise', 'Tibialis Raises'],
    notes: 'Overdue! 12 days since last direct calf stimulus. Risk of Achilles stiffness.',
    coordinates: { x: 45, y: 80, view: 'posterior' }
  },

  // Longevity / Postural
  {
    id: 'rotator-cuff-infraspinatus',
    name: 'Rotator Cuff (Infraspinatus/Teres Minor)',
    scientificName: 'Infraspinatus & Teres minor',
    category: 'longevity',
    view: 'posterior',
    hoursSinceTrained: 2,
    restCadenceHours: 36,
    recoveryPercentage: 35,
    status: 'fatigued',
    fastDecay: 0.14,
    slowDecay: 0.011,
    lastLoadLbs: 320,
    recommendedExercises: ['External Cable Rotations', 'Face Pulls with External Rotation'],
    notes: 'Stabilized shoulder during today’s benching. Needs 36h rest.',
    coordinates: { x: 38, y: 29, view: 'posterior' }
  },
  {
    id: 'serratus-anterior',
    name: 'Serratus Anterior (Boxer’s Muscle)',
    scientificName: 'Serratus anterior',
    category: 'longevity',
    view: 'anterior',
    hoursSinceTrained: 2,
    restCadenceHours: 36,
    recoveryPercentage: 40,
    status: 'fatigued',
    fastDecay: 0.13,
    slowDecay: 0.010,
    lastLoadLbs: 450,
    recommendedExercises: ['Push-Up Plus', 'Serratus Wall Slides'],
    notes: 'Active during protraction.',
    coordinates: { x: 42, y: 34, view: 'anterior' }
  },
  {
    id: 'hip-adductors',
    name: 'Hip Adductors (Groin)',
    scientificName: 'Adductor longus/magnus',
    category: 'longevity',
    view: 'anterior',
    hoursSinceTrained: 96,
    restCadenceHours: 60,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.10,
    slowDecay: 0.007,
    lastLoadLbs: 2400,
    recommendedExercises: ['Copenhagen Hip Adduction', 'Sumo Squat', 'Adductor Machine'],
    notes: 'Primary hip stabilizer in bottom of squat. 100% ready.',
    coordinates: { x: 48, y: 58, view: 'anterior' }
  },
  {
    id: 'quadratus-lumborum',
    name: 'Quadratus Lumborum (QL)',
    scientificName: 'Quadratus lumborum',
    category: 'longevity',
    view: 'posterior',
    hoursSinceTrained: 96,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.11,
    slowDecay: 0.008,
    lastLoadLbs: 1100,
    recommendedExercises: ['Suitcase Carry', 'Side Planks', 'Q-Lumborum Stretch'],
    notes: 'Lateral lumbar spine anchor.',
    coordinates: { x: 44, y: 46, view: 'posterior' }
  },

  // Hands & Forearms
  {
    id: 'forearm-flexors',
    name: 'Forearm Flexors & Grip',
    scientificName: 'Flexor carpi radialis/ulnaris',
    category: 'hands',
    view: 'anterior',
    hoursSinceTrained: 168, // 7 days
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'overdue',
    fastDecay: 0.15,
    slowDecay: 0.012,
    lastLoadLbs: 1400,
    recommendedExercises: ['Barbell Wrist Curls', 'Dead Hangs', 'Fat Grip Holds'],
    notes: 'Overdue. Grip fatigue threshold limits deadlift progression.',
    coordinates: { x: 28, y: 44, view: 'anterior' }
  },
  {
    id: 'forearm-extensors',
    name: 'Forearm Extensors',
    scientificName: 'Extensor carpi radialis/ulnaris',
    category: 'hands',
    view: 'posterior',
    hoursSinceTrained: 168,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'overdue',
    fastDecay: 0.14,
    slowDecay: 0.011,
    lastLoadLbs: 600,
    recommendedExercises: ['Reverse Barbell Curls', 'Wrist Extensions'],
    notes: 'Prevent tennis elbow by balancing flexor strength.',
    coordinates: { x: 26, y: 44, view: 'posterior' }
  },
  {
    id: 'brachioradialis',
    name: 'Brachioradialis',
    scientificName: 'Brachioradialis',
    category: 'hands',
    view: 'anterior',
    hoursSinceTrained: 36,
    restCadenceHours: 48,
    recoveryPercentage: 74,
    status: 'recovering',
    fastDecay: 0.13,
    slowDecay: 0.009,
    lastLoadLbs: 950,
    recommendedExercises: ['Hammer Curls', 'Reverse Grip Pull-Down'],
    notes: 'Recovers alongside biceps.',
    coordinates: { x: 28, y: 40, view: 'anterior' }
  },

  // Feet & Ankles
  {
    id: 'plantar-fascia',
    name: 'Plantar Fascia & Intrinsic Foot',
    scientificName: 'Plantar aponeurosis & Lumbricals',
    category: 'feet',
    view: 'posterior',
    hoursSinceTrained: 96,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.16,
    slowDecay: 0.014,
    lastLoadLbs: 350,
    recommendedExercises: ['Barefoot Balance', 'Short Foot Exercises', 'Calf Raises barefoot'],
    notes: 'Foundational tripod foot mechanics.',
    coordinates: { x: 45, y: 94, view: 'posterior' }
  },
  {
    id: 'peroneus-longus',
    name: 'Peroneus Longus & Brevis (Fibularis)',
    scientificName: 'Fibularis longus/brevis',
    category: 'feet',
    view: 'anterior',
    hoursSinceTrained: 96,
    restCadenceHours: 48,
    recoveryPercentage: 100,
    status: 'primed',
    fastDecay: 0.14,
    slowDecay: 0.011,
    lastLoadLbs: 400,
    recommendedExercises: ['Banded Ankle Eversion', 'Single Leg Balance'],
    notes: 'Lateral ankle stability.',
    coordinates: { x: 40, y: 84, view: 'anterior' }
  }
];

// Generate 87 historical workouts dating back 26 weeks from Sep 2026
export const HISTORICAL_WORKOUTS: WorkoutSession[] = [
  // Session 87 - TODAY (Push)
  {
    id: 'wo-87',
    date: 'Sep 26, 2026',
    name: 'Push Hypertrophy & SBD Prep',
    split: 'push',
    durationMin: 47,
    volumeLbs: 9480,
    workDensity: 201.7,
    rpeAvg: 8.5,
    prHit: 'Bench Volume Record (5,920 lbs)',
    notes: '4x8 @ 185 lbs bench was smooth. Lockouts explosive with zero shoulder impingement.',
    exercises: [
      { name: 'Barbell Bench Press', sets: 4, reps: 8, weightLbs: 185 },
      { name: 'Incline Dumbbell Press', sets: 3, reps: 10, weightLbs: 65 },
      { name: 'Overhead Dumbbell Press', sets: 4, reps: 10, weightLbs: 35 },
      { name: 'Cable Triceps Pressdown', sets: 3, reps: 12, weightLbs: 60 }
    ]
  },
  // Session 86 - Yesterday (Legs)
  {
    id: 'wo-86',
    date: 'Sep 24, 2026',
    name: 'Squat Volume & Posterior Chain',
    split: 'legs',
    durationMin: 52,
    volumeLbs: 8200,
    workDensity: 157.7,
    rpeAvg: 8.0,
    notes: 'Squats 4x6 @ 225 lbs. Depth verified below parallel; good knee track.',
    exercises: [
      { name: 'Barbell Back Squat', sets: 4, reps: 6, weightLbs: 225 },
      { name: 'Romanian Deadlift', sets: 3, reps: 8, weightLbs: 185 },
      { name: 'Bulgarian Split Squat', sets: 3, reps: 10, weightLbs: 40 },
      { name: 'Hanging Leg Raise', sets: 3, reps: 12, weightLbs: 0 }
    ]
  },
  // Session 85 (Pull)
  {
    id: 'wo-85',
    date: 'Sep 22, 2026',
    name: 'Heavy Pull & Scapular Control',
    split: 'pull',
    durationMin: 48,
    volumeLbs: 7600,
    workDensity: 158.3,
    rpeAvg: 8.2,
    notes: 'Weighted pull-ups +25 lbs for 4x6. Lats firing cleanly.',
    exercises: [
      { name: 'Weighted Pull-Up', sets: 4, reps: 6, weightLbs: 190 },
      { name: 'Barbell Row', sets: 4, reps: 8, weightLbs: 155 },
      { name: 'Face Pulls', sets: 4, reps: 15, weightLbs: 45 },
      { name: 'Incline Dumbbell Curl', sets: 3, reps: 10, weightLbs: 30 }
    ]
  },
  // Session 84 (Longevity / Full Body)
  {
    id: 'wo-84',
    date: 'Sep 20, 2026',
    name: 'Postural Reset & Rotator Cuff',
    split: 'longevity',
    durationMin: 38,
    volumeLbs: 4100,
    workDensity: 107.8,
    rpeAvg: 7.0,
    notes: 'Active recovery day. Focus on rotator cuff, tibialis, and thoracic extension.',
    exercises: [
      { name: 'Face Pulls with External Rotation', sets: 4, reps: 15, weightLbs: 35 },
      { name: 'Copenhagen Planks', sets: 3, reps: 30, weightLbs: 0 },
      { name: 'Tibialis Raises', sets: 3, reps: 20, weightLbs: 25 },
      { name: 'Suitcase Carries', sets: 4, reps: 50, weightLbs: 55 }
    ]
  },
  // Milestone Session: Jun 08, 2026 - Big Tributary (Squat PR)
  {
    id: 'wo-48',
    date: 'Jun 08, 2026',
    name: 'Big Tributary · Squat PR Breakthrough',
    split: 'legs',
    durationMin: 52,
    volumeLbs: 11400,
    workDensity: 219.2,
    rpeAvg: 9.0,
    prHit: 'Squat 1RM 245 lbs (Historical High)',
    notes: '5 singles @ 225, 5x5 @ 205, 3x8 @ 185. Single session volume record!',
    exercises: [
      { name: 'Barbell Back Squat', sets: 9, reps: 5, weightLbs: 205 },
      { name: 'Walking Dumbbell Lunges', sets: 4, reps: 12, weightLbs: 45 },
      { name: 'Leg Press', sets: 3, reps: 12, weightLbs: 320 }
    ]
  },
  // Milestone Session: May 20, 2026 - The Rapid (Peak PR Week)
  {
    id: 'wo-36',
    date: 'May 20, 2026',
    name: 'The Rapid · Heavy SBD Testing',
    split: 'push',
    durationMin: 55,
    volumeLbs: 10200,
    workDensity: 185.5,
    rpeAvg: 9.5,
    prHit: 'Bench Press 185 lbs 1RM test',
    notes: 'Peak PR week. Four workouts moved 32,000 lbs in 7 days.',
    exercises: [
      { name: 'Barbell Bench Press', sets: 6, reps: 3, weightLbs: 175 },
      { name: 'Close-Grip Bench', sets: 4, reps: 6, weightLbs: 145 },
      { name: 'Dips', sets: 4, reps: 10, weightLbs: 185 }
    ]
  },
  // Milestone Session: Apr 02, 2026 - First Tributary
  {
    id: 'wo-12',
    date: 'Apr 02, 2026',
    name: 'First Tributary · Neural Surge PR',
    split: 'push',
    durationMin: 38,
    volumeLbs: 5800,
    workDensity: 152.6,
    rpeAvg: 8.5,
    prHit: 'Bench Press 135 lbs (1 plate achieved)',
    notes: '5x5 @ 135 lbs locked in. First milestone with 45-lb plates each side.',
    exercises: [
      { name: 'Barbell Bench Press', sets: 5, reps: 5, weightLbs: 135 },
      { name: 'Back-off Bench Press', sets: 3, reps: 8, weightLbs: 115 },
      { name: 'Overhead Press', sets: 3, reps: 8, weightLbs: 75 }
    ]
  },
  // Milestone Session: Mar 14, 2026 - The Source (Day 1)
  {
    id: 'wo-1',
    date: 'Mar 14, 2026',
    name: 'The Source · Baseline 1RM Test',
    split: 'longevity',
    durationMin: 28,
    volumeLbs: 1200,
    workDensity: 42.8,
    rpeAvg: 7.5,
    prHit: 'Baseline Established (385 lbs total)',
    notes: 'First time on Olympic bar. Bench 95, Squat 135, Deadlift 155.',
    exercises: [
      { name: 'Barbell Bench Press', sets: 4, reps: 8, weightLbs: 65 },
      { name: 'Barbell Back Squat', sets: 3, reps: 10, weightLbs: 95 },
      { name: 'Dumbbell Curls', sets: 3, reps: 10, weightLbs: 20 }
    ]
  }
];

// Generate an array of 87 star records for constellation visualizations
export const CONSTELLATION_STARS = Array.from({ length: 87 }, (_, i) => {
  const num = 87 - i;
  const daysAgo = Math.floor(i * 2.1);
  const splits: ('push' | 'pull' | 'legs' | 'longevity')[] = ['push', 'legs', 'pull', 'push', 'legs', 'longevity'];
  const split = splits[i % splits.length];
  const volume = Math.floor(4000 + Math.sin(i * 0.4) * 2500 + (87 - i) * 55);
  const opacity = Math.max(0.3, 1.0 - daysAgo / 180);
  
  // Cluster positions in 2D galaxy space
  let clusterX = 0;
  let clusterY = 0;
  if (split === 'push') {
    clusterX = -120 + (i % 7) * 28 + (Math.sin(i) * 35);
    clusterY = -80 + (i % 5) * 32 + (Math.cos(i) * 25);
  } else if (split === 'pull') {
    clusterX = 80 + (i % 6) * 30 + (Math.cos(i) * 30);
    clusterY = -70 + (i % 5) * 28 + (Math.sin(i) * 20);
  } else if (split === 'legs') {
    clusterX = -40 + (i % 8) * 24 + (Math.sin(i * 1.5) * 25);
    clusterY = 80 + (i % 4) * 25 + (Math.cos(i) * 30);
  } else {
    clusterX = 110 + (i % 4) * 20 + (Math.sin(i) * 20);
    clusterY = 90 + (i % 4) * 22 + (Math.cos(i) * 20);
  }

  return {
    id: `star-${num}`,
    workoutNumber: num,
    daysAgo,
    split,
    volume,
    opacity,
    x: clusterX,
    y: clusterY,
    size: Math.max(4, Math.min(14, (volume / 12000) * 12 + 3)),
    date: new Date(2026, 8, 26 - daysAgo).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  };
});
