import React, { useState } from 'react';
import { DistrictId, BuildingCard, WorkoutSession, Muscle } from './types';
import { DISTRICTS_DATA, MUSCLES_47, HISTORICAL_WORKOUTS } from './data/mockData';
import { Navbar } from './components/Navbar';
import { ProminentCityViewer } from './components/ProminentCityViewer';
import { AscentView } from './components/AscentView';
import { BodyMapView } from './components/BodyMapView';
import { StrengthRiverView } from './components/StrengthRiverView';
import { ConstellationView } from './components/ConstellationView';
import { CardDetailModal } from './components/CardDetailModal';
import { WorkoutLoggerModal } from './components/WorkoutLoggerModal';
import { WorkoutDetailModal } from './components/WorkoutDetailModal';
import { CheckCircle2, Flame, Award, Dumbbell, Compass, Box, LayoutGrid, ChevronRight } from 'lucide-react';

export default function App() {
  const [viewMode, setViewMode] = useState<'3d' | 'studio'>('3d');
  const [isHeaderCollapsed, setIsHeaderCollapsed] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<DistrictId>('ascent');
  const [streakDays, setStreakDays] = useState<number>(14);
  const [totalVolume, setTotalVolume] = useState<number>(425000);
  const [muscles, setMuscles] = useState<Muscle[]>(MUSCLES_47);
  const [workouts, setWorkouts] = useState<WorkoutSession[]>(HISTORICAL_WORKOUTS);

  // Modals state
  const [selectedCard, setSelectedCard] = useState<BuildingCard | null>(null);
  const [selectedWorkout, setSelectedWorkout] = useState<WorkoutSession | null>(null);
  const [isLoggerOpen, setIsLoggerOpen] = useState<boolean>(false);

  // Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Quick stimulate handler from Body Map
  const handleQuickStimulateMuscle = (muscleId: string) => {
    setMuscles((prev) =>
      prev.map((m) => {
        if (m.id === muscleId) {
          return {
            ...m,
            hoursSinceTrained: 0,
            recoveryPercentage: 15,
            status: 'fatigued' as const,
          };
        }
        return m;
      })
    );
    const target = muscles.find((m) => m.id === muscleId);
    showToast(`Loaded ${target?.name || 'muscle'}! Acute fatigue reset, decay running.`);
  };

  // Save new workout from logger
  const handleSaveWorkout = (newWo: Omit<WorkoutSession, 'id'>) => {
    const id = `wo-${workouts.length + 1}`;
    const fullSession: WorkoutSession = { ...newWo, id };

    // Update workouts
    setWorkouts([fullSession, ...workouts]);

    // Update streak and volume
    setStreakDays((prev) => prev + 1);
    setTotalVolume((prev) => prev + newWo.volumeLbs);

    // Update muscle fatigue based on split
    setMuscles((prev) =>
      prev.map((m) => {
        if (newWo.split === 'push') {
          if (['chest-pectoralis-major', 'front-deltoids', 'lateral-deltoids', 'triceps-brachii', 'serratus-anterior'].includes(m.id)) {
            return { ...m, hoursSinceTrained: 0, recoveryPercentage: 12, status: 'fatigued' };
          }
        } else if (newWo.split === 'pull') {
          if (['latissimus-dorsi', 'biceps-brachii', 'rhomboids', 'rear-deltoids', 'trapezius-upper', 'brachioradialis'].includes(m.id)) {
            return { ...m, hoursSinceTrained: 0, recoveryPercentage: 15, status: 'fatigued' };
          }
        } else if (newWo.split === 'legs') {
          if (['quadriceps-femoris', 'hamstrings', 'gluteus-maximus', 'gluteus-medius', 'gastrocnemius', 'hip-adductors'].includes(m.id)) {
            return { ...m, hoursSinceTrained: 0, recoveryPercentage: 10, status: 'fatigued' };
          }
        }
        return m;
      })
    );

    showToast(`Logged "${newWo.name}"! +${newWo.volumeLbs.toLocaleString()} lbs added to river.`);
  };

  // Find cards for each district
  const ascentCards = DISTRICTS_DATA.find((d) => d.id === 'ascent')?.buildings || [];
  const bodyMapCards = DISTRICTS_DATA.find((d) => d.id === 'bodymap')?.buildings || [];
  const riverCards = DISTRICTS_DATA.find((d) => d.id === 'river')?.buildings || [];
  const constellationCards = DISTRICTS_DATA.find((d) => d.id === 'constellation')?.buildings || [];

  return (
    <div className={
      viewMode === '3d'
        ? "fixed inset-0 w-screen h-screen overflow-hidden bg-slate-950 text-slate-100 flex flex-col overscroll-none select-none"
        : "min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white"
    }>
      
      {/* Ultra-compact Top Bar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        streakDays={streakDays}
        onOpenLogger={() => setIsLoggerOpen(true)}
        viewMode={viewMode}
        onToggleViewMode={setViewMode}
        isHeaderCollapsed={isHeaderCollapsed}
        onToggleHeaderCollapsed={() => setIsHeaderCollapsed(!isHeaderCollapsed)}
      />

      {/* Main Content Viewport */}
      <main className={
        viewMode === '3d'
          ? "flex-1 w-full h-full flex flex-col overflow-hidden min-h-0 p-0"
          : "flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5"
      }>
        
        {viewMode === '3d' ? (
          <div className="w-full h-full flex flex-col min-h-0 flex-1 relative">
            <ProminentCityViewer
              activeDistrictId={activeTab}
              onSelectDistrict={setActiveTab}
              onOpenCardModal={setSelectedCard}
              muscles={muscles}
              onStimulateMuscle={handleQuickStimulateMuscle}
            />
          </div>
        ) : (
          <div>
            {activeTab === 'ascent' && (
              <AscentView
                cards={ascentCards}
                onSelectCard={setSelectedCard}
              />
            )}

            {activeTab === 'bodymap' && (
              <BodyMapView
                muscles={muscles}
                cards={bodyMapCards}
                onSelectCard={setSelectedCard}
                onQuickStimulateMuscle={handleQuickStimulateMuscle}
              />
            )}

            {activeTab === 'river' && (
              <StrengthRiverView
                cards={riverCards}
                onSelectCard={setSelectedCard}
                totalVolume={totalVolume}
              />
            )}

            {activeTab === 'constellation' && (
              <ConstellationView
                cards={constellationCards}
                workouts={workouts}
                onSelectCard={setSelectedCard}
                onSelectWorkout={setSelectedWorkout}
              />
            )}
          </div>
        )}

      </main>

      {/* Slim, Minimal Footer - Only displayed in Studio mode, never in 3D Spatial mode */}
      {viewMode === 'studio' && (
        <footer className="border-t border-slate-900 bg-slate-950 py-2.5 px-4 text-[11px] text-slate-500">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-400 font-display">PeakForm</span>
              <span>·</span>
              <span>Algorithmic Strength & Recovery</span>
            </div>
            <div className="flex items-center gap-4 text-slate-400 font-mono">
              <span>SBD: 385 lbs</span>
              <span>·</span>
              <span>Tested: 775 lbs</span>
              <span>·</span>
              <span>Ceiling: 1,180 lbs</span>
            </div>
          </div>
        </footer>
      )}

      {/* Card Detail Modal */}
      <CardDetailModal
        card={selectedCard}
        onClose={() => setSelectedCard(null)}
      />

      {/* Workout Detail Modal */}
      <WorkoutDetailModal
        workout={selectedWorkout}
        onClose={() => setSelectedWorkout(null)}
      />

      {/* Active Workout Logger Modal */}
      <WorkoutLoggerModal
        isOpen={isLoggerOpen}
        onClose={() => setIsLoggerOpen(false)}
        onSaveWorkout={handleSaveWorkout}
      />

      {/* Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-slate-900 border border-blue-500/40 text-white px-4 py-3 rounded-xl shadow-2xl shadow-blue-500/20 text-xs font-semibold animate-in fade-in slide-in-from-bottom-2 duration-200">
          <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
